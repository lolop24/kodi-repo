# -*- coding: utf-8 -*-
"""
ČSFD Rebríček – Kodi addon (v12.5.0)

Flow:
- Menu: Filmy / Seriály / Série
- List: 20 items per page
  1. Fetch ČSFD details (plot + reviews, parallel, cached 3 days)
  2. Click → SC search by title (série search as seriál)
"""

import os
import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import urlencode, parse_qs

ADDON = xbmcaddon.Addon()
ADDON_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
ADDON_ARGS = sys.argv[2].lstrip('?') if len(sys.argv) > 2 else ''

LIB_PATH = os.path.join(
    xbmcvfs.translatePath(ADDON.getAddonInfo('path')),
    'resources', 'lib'
)
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

from csfd import (
    TYPE_FILM, TYPE_SERIES, TYPE_SERIE, ITEMS_PER_PAGE,
    fetch_ranking, fetch_details_for_page, fetch_single_reviews,
)
from sc_bridge import build_sc_search_url, get_search_title

STAR_FULL = '★'
STAR_EMPTY = '☆'


def L(string_id):
    return ADDON.getLocalizedString(string_id)


def log(msg):
    xbmc.log('[CSFD Rebricek] %s' % msg, xbmc.LOGINFO)


def get_year_from():
    try:
        val = ADDON.getSetting('year_from')
        if val:
            val = val.strip()
            if val.isdigit():
                y = int(val)
                if 1900 < y <= 2030:
                    return str(y)
    except Exception as e:
        log('getSetting error: %s' % e)
    return '2025'


def build_url(**params):
    return '%s?%s' % (ADDON_URL, urlencode(params))


def stars_str(n):
    n = max(0, min(5, n))
    return STAR_FULL * n + STAR_EMPTY * (5 - n)


# ═══════════════════════════════════════════════════════════════

def main_menu():
    xbmcplugin.setPluginCategory(ADDON_HANDLE, L(30001))
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')

    year = get_year_from()

    li = xbmcgui.ListItem(label='🎬 %s (%s)' % (L(30002), year))
    li.setInfo('video', {'title': L(30002)})
    xbmcplugin.addDirectoryItem(
        ADDON_HANDLE, build_url(action='ranking', mtype=TYPE_FILM, page='1', year=year),
        li, isFolder=True)

    li = xbmcgui.ListItem(label='📺 %s (%s)' % (L(30003), year))
    li.setInfo('video', {'title': L(30003)})
    xbmcplugin.addDirectoryItem(
        ADDON_HANDLE, build_url(action='ranking', mtype=TYPE_SERIES, page='1', year=year),
        li, isFolder=True)

    li = xbmcgui.ListItem(label='📺 %s (%s)' % (L(30004), year))
    li.setInfo('video', {'title': L(30004)})
    xbmcplugin.addDirectoryItem(
        ADDON_HANDLE, build_url(action='ranking', mtype=TYPE_SERIE, page='1', year=year),
        li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)


def show_ranking(media_type, page, year_param=''):
    year_from = year_param if year_param else get_year_from()
    is_film = (media_type == TYPE_FILM)
    if media_type == TYPE_SERIE:
        category = L(30004)
    elif media_type == TYPE_SERIES:
        category = L(30003)
    else:
        category = L(30002)

    log('show_ranking: type=%s year=%s page=%d' % (media_type, year_from, page))

    xbmcplugin.setPluginCategory(ADDON_HANDLE, '%s (%s)' % (category, year_from))
    xbmcplugin.setContent(ADDON_HANDLE, 'movies' if is_film else 'tvshows')

    # 1. Full ranking (cached 2h)
    all_items = fetch_ranking(media_type, year_from)

    if not all_items:
        xbmcgui.Dialog().notification(
            L(30001), L(30005),
            xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False, cacheToDisc=False)
        return

    # 2. Paginate
    total = len(all_items)
    start = (page - 1) * ITEMS_PER_PAGE
    end = min(start + ITEMS_PER_PAGE, total)
    page_items = all_items[start:end]

    if not page_items:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=False, cacheToDisc=False)
        return

    log('Page %d: items %d-%d of %d' % (page, start + 1, end, total))

    # 3. Fetch ČSFD details (plot + reviews, parallel, cached 3 days)
    page_items = fetch_details_for_page(page_items)

    # 4. Build list — no SC API calls, search on click only
    for film in page_items:
        title = film['title']
        year = film.get('year', '')
        rating = film.get('rating', '')
        votes = film.get('votes', '')
        poster = film.get('poster_url', '')
        position = film.get('position', '')
        plot = film.get('plot', '')
        reviews = film.get('reviews', [])

        # For SC search: série → search as seriál ('S')
        if is_film:
            mt = 'F'
        else:
            mt = 'S'

        # Label
        parts = []
        if position:
            parts.append('%s.' % position)
        parts.append(title)
        if year:
            parts.append('(%s)' % year)
        if rating:
            parts.append('[COLOR orange]%s[/COLOR]' % rating)
        if votes:
            parts.append('[COLOR grey][%s][/COLOR]' % votes)

        label = ' '.join(parts)

        li = xbmcgui.ListItem(label=label)

        info = {
            'title': title,
            'mediatype': 'movie' if is_film else 'tvshow',
        }
        if year:
            try:
                info['year'] = int(year)
            except ValueError:
                pass
        if rating:
            try:
                info['rating'] = float(rating.rstrip('%').replace(',', '.')) / 10.0
            except (ValueError, TypeError):
                pass
        if votes:
            try:
                info['votes'] = int(votes.replace(' ', '').replace('\xa0', ''))
            except (ValueError, TypeError):
                pass
        if film.get('genres'):
            info['genre'] = film['genres']
        if film.get('country'):
            info['country'] = film['country']
        if plot:
            info['plot'] = plot
            info['plotoutline'] = plot[:200]
        elif film.get('origins_genres'):
            info['plot'] = film['origins_genres']

        li.setInfo('video', info)

        if poster:
            li.setArt({'poster': poster, 'thumb': poster,
                       'icon': poster, 'fanart': poster})

        # Context menu: reviews
        rev_url = build_url(action='reviews',
                            csfd_url=film.get('csfd_url', ''),
                            title=title)
        ctx_label = L(30007) % len(reviews) if reviews else L(30008)
        li.addContextMenuItems([(ctx_label, 'RunPlugin(%s)' % rev_url)])

        # Click → SC search (English title for foreign, Czech for CZ/SK)
        search_title = get_search_title(film)
        item_url = build_sc_search_url(search_title, mt)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, item_url, li, isFolder=True)

    # 5. "Next" button
    if end < total:
        li = xbmcgui.ListItem(
            label='[COLOR blue]%s[/COLOR]' % (L(30010) % (total - end)))
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_url(action='ranking', mtype=media_type, page=str(page + 1), year=year_from),
            li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)


def show_widget_plain(media_type):
    """Home screen widget: top 20 items, no SC check."""
    is_film = (media_type == TYPE_FILM)
    year_from = get_year_from()

    xbmcplugin.setContent(ADDON_HANDLE, 'movies' if is_film else 'tvshows')

    all_items = fetch_ranking(media_type, year_from)
    if not all_items:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)
        return

    items = fetch_details_for_page(all_items[:ITEMS_PER_PAGE])

    for film in items:
        title = film['title']
        year = film.get('year', '')
        poster = film.get('poster_url', '')
        mt = 'F' if is_film else 'S'

        li = xbmcgui.ListItem(label=title)
        info = {
            'title': title,
            'mediatype': 'movie' if is_film else 'tvshow',
        }
        if year:
            try:
                info['year'] = int(year)
            except ValueError:
                pass
        if film.get('rating'):
            try:
                info['rating'] = float(film['rating'].rstrip('%').replace(',', '.')) / 10.0
            except (ValueError, TypeError):
                pass
        if film.get('plot'):
            info['plot'] = film['plot']
            info['plotoutline'] = film['plot'][:200]
        elif film.get('origins_genres'):
            info['plot'] = film['origins_genres']
        if film.get('genres'):
            info['genre'] = film['genres']
        li.setInfo('video', info)
        if poster:
            li.setArt({'poster': poster, 'thumb': poster, 'icon': poster, 'fanart': poster})

        search_title = get_search_title(film)
        item_url = build_sc_search_url(search_title, mt)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, item_url, li, isFolder=True)

    xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)


def show_reviews(csfd_url, title):
    if not csfd_url:
        return
    reviews = fetch_single_reviews(csfd_url)
    if not reviews:
        xbmcgui.Dialog().notification('ČSFD', L(30006), xbmcgui.NOTIFICATION_INFO)
        return
    lines = []
    for r in reviews:
        lines.append('─' * 50)
        lines.append('%s  %s' % (stars_str(r.get('stars', 0)), r.get('user', '?')))
        lines.append('')
        lines.append(r.get('text', ''))
        lines.append('')
    xbmcgui.Dialog().textviewer(
        L(30009) % (title, len(reviews)),
        '\n'.join(lines))


# ═══════════════════════════════════════════════════════════════

def router():
    params = parse_qs(ADDON_ARGS)
    args = {k: v[0] if v else '' for k, v in params.items()}
    action = args.get('action', '')

    if action == 'ranking':
        show_ranking(args.get('mtype', TYPE_FILM), int(args.get('page', '1')), args.get('year', ''))
    elif action in ('widget', 'widget_film'):
        show_widget_plain(TYPE_FILM)
    elif action == 'widget_serial':
        show_widget_plain(TYPE_SERIES)
    elif action == 'widget_serie':
        show_widget_plain(TYPE_SERIE)
    elif action == 'reviews':
        show_reviews(args.get('csfd_url', ''), args.get('title', ''))
    else:
        main_menu()


if __name__ == '__main__':
    router()
