# -*- coding: utf-8 -*-
"""
Stream Cinema bridge v13 – SC search URL builder only.

No automatic SC API calls. Click on item → opens SC search.
"""

from urllib.parse import urlencode

SC_ADDON_ID = 'plugin.video.stream-cinema'

CZ_SK = {'česko', 'slovensko', 'československo', 'čssr'}


def _hexlify(value):
    return str(value).encode('utf-8').hex()


def build_sc_search_url(title, media_type='F'):
    """Build Kodi plugin URL that opens SC search for given title."""
    search_id = 'search-series' if media_type == 'S' else 'search-movies'
    params = {
        'action': _hexlify('search_from_history'),
        'id': _hexlify(search_id),
        'search': _hexlify(title),
    }
    sorted_params = sorted(params.items(), key=lambda x: x[0])
    return 'plugin://%s/?%s' % (SC_ADDON_ID, urlencode(sorted_params))


def get_search_title(item):
    """
    Best search title for SC.
    English title for foreign films, Czech title for CZ/SK.
    Priority: english_title > original_title > title
    """
    country = item.get('country', '').lower().strip()
    is_czsk = any(c in country for c in CZ_SK)
    if is_czsk:
        return item['title']

    eng = item.get('english_title', '')
    if eng:
        return eng

    orig = item.get('original_title', '')
    return orig if orig else item['title']
