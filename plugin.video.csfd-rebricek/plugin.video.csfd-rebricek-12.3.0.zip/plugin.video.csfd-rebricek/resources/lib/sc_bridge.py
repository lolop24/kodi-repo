# -*- coding: utf-8 -*-
"""
Stream Cinema bridge v12 – direct SC search with correct API parsing.

Flow:
1. Search SC /Search/{search-id} by title (English for foreign, Czech for CZ/SK)
2. Check if any result in "menu" matches year (±1 film, ±2 serial tolerance)
3. Fallback: retry with Czech title if English title search fails
4. green = found, gray = not found
"""

import os
import json
import time
import hashlib
import requests
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor, as_completed

SC_ADDON_ID = 'plugin.video.stream-cinema'
SC_API_BASE = 'https://stream-cinema.online/kodi'

SC_CACHE_TTL = 604800       # 7 days (found)
NO_MATCH_TTL = 86400        # 1 day (not found)
SC_CACHE_VERSION = 13
MAX_WORKERS = 4


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[CSFD-SC] %s' % msg, level)


def is_sc_installed():
    return xbmc.getCondVisibility('System.HasAddon(%s)' % SC_ADDON_ID)


def _hexlify(value):
    return str(value).encode('utf-8').hex()


def build_sc_search_url(title, media_type='F'):
    search_id = 'search-series' if media_type == 'S' else 'search-movies'
    params = {
        'action': _hexlify('search_from_history'),
        'id': _hexlify(search_id),
        'search': _hexlify(title),
    }
    sorted_params = sorted(params.items(), key=lambda x: x[0])
    return 'plugin://%s/?%s' % (SC_ADDON_ID, urlencode(sorted_params))


# ═══════════════════════════════════════════════════════════════
# SC API
# ═══════════════════════════════════════════════════════════════

def _get_sc_auth():
    try:
        sc_addon = xbmcaddon.Addon(SC_ADDON_ID)
        uuid = sc_addon.getSetting('system.uuid') or ''
        auth_token = sc_addon.getSetting('system.auth_token') or ''
        return uuid, auth_token
    except:
        return '', ''


def _sc_headers(uuid, auth_token):
    headers = {
        'User-Agent': xbmc.getUserAgent() if hasattr(xbmc, 'getUserAgent') else 'Kodi',
        'X-Uuid': uuid,
    }
    if auth_token:
        headers['X-AUTH-TOKEN'] = auth_token
    return headers


def _sc_params(uuid):
    return {'ver': '2.0', 'uid': uuid, 'lang': 'cs'}


# ═══════════════════════════════════════════════════════════════
# CACHE
# ═══════════════════════════════════════════════════════════════

def _cache_dir():
    addon = xbmcaddon.Addon()
    d = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    if not xbmcvfs.exists(d):
        xbmcvfs.mkdirs(d)
    return d


def _md5(s):
    return hashlib.md5(s.encode('utf-8')).hexdigest()


def _load_cache():
    path = os.path.join(_cache_dir(), 'sc_match_cache.json')
    try:
        if xbmcvfs.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return {}


def _save_cache(cache):
    path = os.path.join(_cache_dir(), 'sc_match_cache.json')
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=1)
    except:
        pass


# ═══════════════════════════════════════════════════════════════
# SC SEARCH
# ═══════════════════════════════════════════════════════════════

def _sc_api_search(title, media_type, uuid, auth_token):
    """Call SC /Search/{search-id} API. Returns list of result items."""
    headers = _sc_headers(uuid, auth_token)
    p = dict(_sc_params(uuid))
    p['search'] = title

    # Use type-specific endpoint: /Search/search-series or /Search/search-movies
    search_id = 'search-series' if media_type == 'S' else 'search-movies'

    try:
        resp = requests.get(
            '%s/Search/%s' % (SC_API_BASE, search_id),
            params=p, headers=headers, timeout=10,
        )

        # Fallback to bare /Search if type-specific endpoint fails
        if resp.status_code in (404, 405):
            log('SC /%s not found, fallback to /Search' % search_id)
            resp = requests.get(
                SC_API_BASE + '/Search',
                params=p, headers=headers, timeout=10,
            )

        if resp.status_code != 200:
            log('SC HTTP %d for "%s"' % (resp.status_code, title[:30]))
            return []

        data = resp.json()
        if isinstance(data, dict):
            return data.get('menu', [])
        elif isinstance(data, list):
            return data
        return []

    except Exception as e:
        log('SC err "%s": %s' % (title[:25], e), xbmc.LOGWARNING)
        return []


def _match_year(items, year, tolerance):
    """Check if any SC result matches year within tolerance. Returns True + logs match."""
    for it in items:
        if not isinstance(it, dict):
            continue
        info = it.get('info', {})
        iy = info.get('year', 0) if isinstance(info, dict) else 0
        try:
            iy = int(iy) if iy else 0
        except (ValueError, TypeError):
            iy = 0

        if year and iy and abs(year - iy) <= tolerance:
            label = it.get('title', it.get('label', it.get('name', '')))
            if not label:
                if isinstance(info, dict):
                    label = info.get('title', info.get('originaltitle', ''))
            if not label:
                il = it.get('info_labels', {})
                if isinstance(il, dict):
                    label = il.get('title', il.get('originaltitle', ''))
            label = label or '(id:%s)' % it.get('id', '?')
            log('SC MATCH "%s" (%d) -> "%s" (%d) tol=%d' % (
                str(label)[:25], year, str(label)[:25], iy, tolerance))
            return True
    return False


def _sc_search(title, year, media_type, uuid, auth_token):
    """
    Search SC API. Returns True if any result matches year.
    Films: ±1 year tolerance. Serials: ±2 year tolerance.
    """
    year = int(year) if year else 0
    tolerance = 2 if media_type == 'S' else 1

    items = _sc_api_search(title, media_type, uuid, auth_token)

    if items:
        # Log first result keys for debugging
        if isinstance(items[0], dict):
            keys = sorted(items[0].keys())
            log('SC "%s": %d results, keys=%s' % (title[:20], len(items), keys[:10]))

        if _match_year(items, year, tolerance):
            return True

        # Log misses for debug
        for it in items[:2]:
            if isinstance(it, dict):
                info = it.get('info', {})
                iy = info.get('year', '?') if isinstance(info, dict) else '?'
                label = it.get('title', it.get('label', '?'))
                log('SC miss: "%s" (%s) vs %d' % (str(label)[:30], iy, year))

    return False


# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

CZ_SK = {'česko', 'slovensko', 'československo', 'čssr'}


def _get_search_title(item):
    """
    English title for foreign films, Czech title for CZ/SK.
    Priority: english_title > original_title > title
    """
    country = item.get('country', '').lower().strip()
    is_czsk = any(c in country for c in CZ_SK)
    if is_czsk:
        return item['title']

    # For foreign films: prefer English title from CSFD
    eng = item.get('english_title', '')
    if eng:
        return eng

    # Fallback to original_title (may be non-English), then Czech title
    orig = item.get('original_title', '')
    return orig if orig else item['title']


def resolve_sc_urls(items, silent=False):
    """
    Check which CSFD items are available on SC.
    Sets 'sc_url' and 'on_sc' on each item.
    silent=True: no progress dialog (for home screen widgets).
    """
    if not is_sc_installed():
        for item in items:
            item['sc_url'] = ''
            item['on_sc'] = False
        return items

    cache = _load_cache()
    now = time.time()

    uncached = []
    for i, item in enumerate(items):
        key = _md5('%s_%s_%s' % (item['title'], item.get('year', ''), item.get('media_type', 'F')))
        item['_ck'] = key
        entry = cache.get(key)
        if entry and entry.get('v') == SC_CACHE_VERSION and (now - entry.get('ts', 0)) < SC_CACHE_TTL:
            item['sc_url'] = entry.get('sc_url', '')
            item['on_sc'] = entry.get('on_sc', False)
        else:
            item['sc_url'] = ''
            item['on_sc'] = False
            uncached.append((i, item))

    if not uncached:
        log('All %d cached' % len(items))
        return items

    log('Resolving %d/%d' % (len(uncached), len(items)))

    uuid, auth_token = _get_sc_auth()
    if not uuid:
        log('SC not configured', xbmc.LOGWARNING)
        for idx, item in uncached:
            item['sc_url'] = build_sc_search_url(item['title'], item.get('media_type', 'F'))
        return items

    if not silent:
        addon = xbmcaddon.Addon()
        progress = xbmcgui.DialogProgress()
        progress.create(addon.getLocalizedString(30012), addon.getLocalizedString(30013))

    def search_one(idx_item):
        idx, item = idx_item
        mt = item.get('media_type', 'F')
        year = item.get('year', '')
        search_title = _get_search_title(item)
        found = _sc_search(search_title, year, mt, uuid, auth_token)

        # Fallback: try Czech title if English/original title didn't match
        if not found and search_title != item['title']:
            log('SC retry with CZ title: "%s"' % item['title'][:30])
            found = _sc_search(item['title'], year, mt, uuid, auth_token)
            if found:
                search_title = item['title']

        return idx, search_title, found

    search_titles = {}  # idx -> search_title used in _sc_search
    results = {}
    step = 0
    try:
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
            futures = {pool.submit(search_one, (idx, item)): idx
                       for idx, item in uncached}

            for future in as_completed(futures):
                if not silent and progress.iscanceled():
                    break
                step += 1
                try:
                    idx, st, found = future.result()
                    results[idx] = found
                    search_titles[idx] = st
                except Exception as e:
                    log('Thread err: %s' % e, xbmc.LOGWARNING)
                    results[futures[future]] = False

                if not silent:
                    pct = int(95 * step / len(uncached))
                    progress.update(pct, addon.getLocalizedString(30014) % (step, len(uncached)))
    finally:
        if not silent:
            progress.close()

    # Apply + cache
    for idx, item in uncached:
        key = item.get('_ck', '')
        mt = item.get('media_type', 'F')
        search_title = search_titles.get(idx) or _get_search_title(item)
        item['sc_url'] = build_sc_search_url(search_title, mt)

        if results.get(idx, False):
            item['on_sc'] = True
            cache[key] = {'sc_url': item['sc_url'], 'on_sc': True,
                          'ts': now, 'v': SC_CACHE_VERSION}
        else:
            item['on_sc'] = False
            cache[key] = {'sc_url': item['sc_url'], 'on_sc': False,
                          'ts': now - SC_CACHE_TTL + NO_MATCH_TTL, 'v': SC_CACHE_VERSION}

    _save_cache(cache)

    for item in items:
        item.pop('_ck', None)

    on = sum(1 for it in items if it.get('on_sc'))
    log('FINAL: %d/%d on SC' % (on, len(items)))
    return items
