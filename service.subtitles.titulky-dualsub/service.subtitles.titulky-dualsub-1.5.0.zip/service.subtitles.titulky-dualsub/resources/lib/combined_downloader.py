# -*- coding: utf-8 -*-
"""
Combined subtitle downloader for OpenSubtitles.com + Titulky.com + TVsubtitles.net.
Searches all sources in parallel, presents unified results,
and merges two selected subtitles into a dual-position ASS file.
"""
import os
import re
import sys
import json
import shutil
import zipfile
import uuid
import concurrent.futures

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from urllib.parse import unquote, quote

from resources.lib.data_collector import (
    get_language_data, get_media_data, get_file_path, get_3let_languages,
    convert_language, clean_feature_release_name, get_flag,
)
from resources.lib.exceptions import (
    AuthenticationError, ConfigurationError, DownloadLimitExceeded,
    ProviderError, ServiceUnavailable, TooManyRequests, BadUsernameError,
)
from resources.lib.file_operations import get_file_data
from resources.lib.os.provider import OpenSubtitlesProvider
from resources.lib.utilities import get_params, log, error
from resources.lib.titulky_client import TitulkyClient
from resources.lib.tvsubtitles_client import TVSubtitlesClient
from resources.lib.dualsubs import mergesubs
from resources.lib.phonetic_ua import generate_phonetic_subtitle

__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo("id")
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo("profile"))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, "temp", ""))
__msg_box__ = xbmcgui.Dialog()
__language__ = __addon__.getLocalizedString

if xbmcvfs.exists(__temp__):
    shutil.rmtree(__temp__)
xbmcvfs.mkdirs(__temp__)

# Temp dir for downloaded subtitle files
_SUBDIR = xbmcvfs.translatePath('special://temp/tds/')
_PHONETIC_SUPPORTED_LANGS = {"cs", "sk"}


def _ensure_subdir():
    if not xbmcvfs.exists(_SUBDIR):
        xbmcvfs.mkdir(_SUBDIR)


def _clean_subdir():
    if xbmcvfs.exists(_SUBDIR):
        try:
            dirs, files = xbmcvfs.listdir(_SUBDIR)
            for f in files:
                xbmcvfs.delete(os.path.join(_SUBDIR, f))
        except Exception as e:
            log(__name__, "Clean subdir error: %s" % e)


class CombinedSubtitleDownloader:

    def __init__(self):
        self.api_key = __addon__.getSetting("APIKey")
        self.os_username = __addon__.getSetting("OSuser")
        self.os_password = __addon__.getSetting("OSpass")
        self.tk_username = __addon__.getSetting("TKuser")
        self.tk_password = __addon__.getSetting("TKpass")

        log(__name__, "argv: %s" % sys.argv)

        self.sub_format = "srt"
        self.handle = int(sys.argv[1])
        self.params = get_params()
        self.query = {}
        self.subtitles = []  # unified list of subtitle dicts

        # Init OS provider
        self.open_subtitles = None
        try:
            self.open_subtitles = OpenSubtitlesProvider(
                self.api_key, self.os_username, self.os_password
            )
        except ConfigurationError as e:
            log(__name__, "OS provider config error: %s" % e)

        # Init TK client
        self.titulky = TitulkyClient(__addon__)

        # Init TVsubtitles client
        self.tvsubtitles = TVSubtitlesClient(__addon__)

    # ── Entry point ───────────────────────────────────────────────────────────

    def handle_action(self):
        action = self.params.get("action", "")
        log(__name__, "action '%s' called" % action)

        if action == "manualsearch":
            self.search(self.params.get("searchstring", ""))
        elif action == "search":
            self.search()
        elif action in ("download", "downloadstd", "downloadswap", "downloadphonetic"):
            self.download()
        elif action == "settings":
            __addon__.openSettings()
            __msg_box__.ok("", "Restart subtitle search to apply new settings.")

    # ── Search ────────────────────────────────────────────────────────────────

    def search(self, query=""):
        file_data = get_file_data(get_file_path())
        language_data = get_language_data(self.params)

        if query:
            media_data = {"query": query}
        else:
            media_data = get_media_data()
            if "basename" in file_data and not media_data.get("query"):
                media_data["query"] = file_data.get("basename", "")

        self.query = {**media_data, **file_data, **language_data}
        log(__name__, "Combined query: %s" % self.query)

        # Determine which sources to search
        def _src_flags(setting_id):
            """Return (use_os, use_tk). Handles both index ('0'/'1'/'2') and legacy string values."""
            val = __addon__.getSetting(setting_id) or "2"
            if val.startswith("OS"):
                return True, False
            if val.startswith("TK"):
                return False, True
            if val == "Both":
                return True, True
            try:
                idx = int(val)
                return idx in (0, 2), idx in (1, 2)
            except (ValueError, TypeError):
                return True, True

        os_top, tk_top = _src_flags("top_source")
        os_bot, tk_bot = _src_flags("bottom_source")
        use_os = os_top or os_bot
        use_tk = tk_top or tk_bot

        os_results = []
        tk_results = []
        tvs_results = []

        # Check if this is a TV show (TVsubtitles.net only has TV shows)
        is_tv = bool(self.query.get("tvshow")) or self.query.get("type") == "episode"
        tvs_enabled = __addon__.getSetting("tvs_enable") != "false"

        # Parallel search
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
            futures = {}
            if use_os and self.open_subtitles:
                futures["os"] = executor.submit(self._search_os)
            if use_tk:
                futures["tk"] = executor.submit(self._search_tk)
            if is_tv and tvs_enabled:
                futures["tvs"] = executor.submit(self._search_tvs)

            for source, future in futures.items():
                try:
                    result = future.result(timeout=30)
                    if source == "os":
                        os_results = result or []
                    elif source == "tk":
                        tk_results = result or []
                    elif source == "tvs":
                        tvs_results = result or []
                except Exception as e:
                    log(__name__, "Search error [%s]: %s" % (source, e))

        # Build unified subtitle list — TK first, TVS second, then OS results
        self.subtitles = []

        # Titulky.com results appear first
        for sub in tk_results:
            lang = sub.get("lang", "")
            sub_id = sub.get("id", "")
            link_file = sub.get("link_file", "")
            # Encoded ID: "tk:<sub_id>:<link_file>"
            self.subtitles.append({
                "source": "TK",
                "id": "tk:%s:%s" % (sub_id, link_file),
                "label": lang,
                "lang_code": self._normalize_lang_code(lang),
                "label2": "[TK] " + sub.get("filename", ""),
                "icon": str(sub.get("rating", 0)),
                "flag": sub.get("lang_flag", ""),
                "sync": bool(sub.get("sync")),
                "hearing_imp": False,
            })

        # TVsubtitles.net results second
        for sub in tvs_results:
            lang = sub.get("lang", "")
            sub_id = sub.get("id", "")
            self.subtitles.append({
                "source": "TVS",
                "id": "tvs:%s" % sub_id,
                "label": lang,
                "lang_code": self._normalize_lang_code(lang),
                "label2": "[TVS] " + sub.get("filename", ""),
                "icon": str(sub.get("rating", 0)),
                "flag": sub.get("lang_flag", ""),
                "sync": False,
                "hearing_imp": False,
            })

        # Get preferred languages for sorting (Ukrainian first)
        pref_langs = set(l.strip() for l in self.query.get("languages", "").split(",") if l.strip())

        # OS results sorted: moviehash first, then Ukrainian, then other preferred langs, then rest
        def _os_sort_key(s):
            attrs = s.get("attributes", {})
            lang = attrs.get("language", "")
            return (
                not attrs.get("moviehash_match"),      # moviehash matches first
                lang != "uk",                           # Ukrainian first
                lang not in pref_langs,                 # preferred languages next
                -(attrs.get("ratings", 0) or 0),        # higher rating first
            )

        os_sorted = sorted(os_results, key=_os_sort_key)
        for sub in os_sorted:
            attrs = sub.get("attributes", {})
            files = attrs.get("files", [{}])
            file_id = files[0].get("file_id", 0) if files else 0
            lang = attrs.get("language", "")
            rating = attrs.get("ratings", 0) or 0
            self.subtitles.append({
                "source": "OS",
                # Encoded ID: "os:<file_id>"
                "id": "os:%d" % file_id,
                "label": convert_language(lang, True),
                "lang_code": self._normalize_lang_code(lang),
                "label2": "[OS] " + clean_feature_release_name(
                    attrs.get("feature_details", {}).get("title", ""),
                    attrs.get("release", ""),
                    attrs.get("feature_details", {}).get("movie_name", ""),
                ) + (" [HASH]" if attrs.get("moviehash_match") else ""),
                "icon": str(int(round(float(rating) / 2))),
                "flag": get_flag(lang),
                "sync": bool(attrs.get("moviehash_match")),
                "hearing_imp": bool(attrs.get("hearing_impaired")),
            })

        log(__name__, "Combined results: %d OS + %d TK + %d TVS = %d total" % (
            len(os_results), len(tk_results), len(tvs_results), len(self.subtitles)))

        if self.subtitles:
            self.list_subtitles()
        else:
            log(__name__, "No subtitles found from any source")

    def _search_os(self):
        """Sequential OS search: moviehash -> IMDB ID -> text query variants, deduplicated."""
        all_results = []
        seen_file_ids = set()

        def _add_results(results):
            for sub in (results or []):
                attrs = sub.get("attributes", {})
                files = attrs.get("files", [{}])
                fid = files[0].get("file_id", 0) if files else 0
                if fid and fid not in seen_file_ids:
                    seen_file_ids.add(fid)
                    all_results.append(sub)

        q = self.query
        requested_langs = set(
            lang.strip() for lang in (q.get("languages") or "").split(",") if lang.strip()
        )
        uk_requested = "uk" in requested_langs

        base_params = {
            "languages": q.get("languages", ""),
            "hearing_impaired": q.get("hearing_impaired", "include"),
            "foreign_parts_only": q.get("foreign_parts_only", "include"),
            "machine_translated": q.get("machine_translated", "exclude"),
            "ai_translated": q.get("ai_translated", "include"),
        }
        if q.get("type") in ("movie", "episode"):
            base_params["type"] = q.get("type")
        if q.get("type") == "episode":
            base_params["season_number"] = q.get("season_number")
            base_params["episode_number"] = q.get("episode_number")

        def _has_language(lang_code):
            return any(
                sub.get("attributes", {}).get("language") == lang_code
                for sub in all_results
            )

        def _search_with_params(params, label):
            try:
                log(__name__, "OS search: %s" % label)
                _add_results(self.open_subtitles.search_subtitles(params))
            except Exception as e:
                log(__name__, "OS %s search error: %s" % (label, e))

        if q.get("moviehash"):
            params = dict(base_params, moviehash=q["moviehash"], moviehash_match="only")
            _search_with_params(params, "moviehash")

        if q.get("imdb_id"):
            params = dict(base_params, imdb_id=q["imdb_id"])
            if q.get("type") == "episode" and q.get("parent_imdb_id"):
                params["parent_imdb_id"] = q["parent_imdb_id"]
            _search_with_params(params, "imdb_id=%s" % q["imdb_id"])

        text_queries = self._build_os_text_queries()
        need_text_fallback = not all_results or (
            q.get("type") == "movie" and (
                not q.get("moviehash") or (uk_requested and not _has_language("uk"))
            )
        )

        if text_queries and need_text_fallback:
            for query_text in text_queries:
                params = dict(base_params, query=query_text)
                if q.get("year"):
                    params["year"] = q["year"]
                _search_with_params(params, "query='%s'" % query_text)
                if all_results and (not uk_requested or _has_language("uk")):
                    break

        if q.get("type") == "movie" and uk_requested and not _has_language("uk"):
            uk_params = dict(base_params, languages="uk")

            if q.get("imdb_id"):
                params = dict(uk_params, imdb_id=q["imdb_id"])
                _search_with_params(params, "uk-imdb_id=%s" % q["imdb_id"])

            if not _has_language("uk"):
                for query_text in text_queries:
                    params = dict(uk_params, query=query_text)
                    if q.get("year"):
                        params["year"] = q["year"]
                    _search_with_params(params, "uk-query='%s'" % query_text)
                    if _has_language("uk"):
                        break

        log(__name__, "OS total unique results: %d" % len(all_results))
        return all_results

    def _build_os_text_queries(self):
        queries = []
        seen = set()

        def _add(raw_value, include_raw=True):
            raw_value = (raw_value or "").strip()
            if not raw_value:
                return

            variants = []
            if include_raw:
                variants.append(raw_value)
            variants.extend(self._clean_os_query_variants(raw_value))

            for variant in variants:
                key = variant.lower()
                if key not in seen:
                    seen.add(key)
                    queries.append(variant)

        _add(self.query.get("query"), include_raw=True)
        _add(self.query.get("title"), include_raw=True)
        _add(self.query.get("basename"), include_raw=False)
        return queries[:4]

    def _clean_os_query_variants(self, raw_value):
        value = os.path.splitext(os.path.basename(raw_value))[0]
        value = re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", value)
        value = re.sub(r"[._]+", " ", value)
        value = re.sub(
            r"\b(?:s\d{1,2}e\d{1,2}|\d{1,2}x\d{1,2})\b.*$",
            " ",
            value,
            flags=re.IGNORECASE,
        )

        year_prefix = None
        year_match = re.search(r"\b(?:19|20)\d{2}\b", value)
        if year_match:
            year_prefix = value[:year_match.end()]

        cleaned = year_prefix or value
        cleaned = re.sub(
            r"\b(?:2160p|1080p|720p|480p|x264|x265|h264|h265|hevc|hdr10plus|hdr10|hdr|dv|"
            r"bdrip|bluray|blu ray|webrip|web dl|web-dl|web|remux|dvdrip|proper|repack|"
            r"internal|atmos|truehd|dts|multi|subs?|dubbed|imax|yts|rarbg|amzn|nf|dsnp|"
            r"hmax|hulu|itunes)\b.*$",
            " ",
            cleaned,
            flags=re.IGNORECASE,
        )
        cleaned = re.sub(r"\s+", " ", cleaned).strip(" -._")

        title_only = re.sub(r"\b(?:19|20)\d{2}\b", " ", cleaned)
        title_only = re.sub(r"\s+", " ", title_only).strip(" -._")

        variants = []
        if cleaned:
            variants.append(cleaned)
        if title_only and title_only.lower() != cleaned.lower():
            variants.append(title_only)
        return [variant for variant in variants if len(variant) >= 2]

    def _search_tk(self):
        try:
            item = self._build_tk_item()
            return self.titulky.search(item) or []
        except Exception as e:
            log(__name__, "TK search error: %s" % e)
            return []

    # ISO 639-2 codes for Czech and Slovak — TVsubtitles.net doesn't have these
    _TVS_SKIP_3LET = {"ces", "cze", "slk", "slo", "csy", "sky"}

    def _search_tvs(self):
        """Search TVsubtitles.net for TV show subtitles (skips Czech/Slovak)."""
        try:
            q = self.query
            # Filter out Czech and Slovak — not available on TVsubtitles.net
            three_let = [l for l in get_3let_languages(self.params)
                         if l not in self._TVS_SKIP_3LET]
            item = {
                "type": q.get("type", ""),
                "tvshow": q.get("tvshow", ""),
                "season": int(q.get("season_number") or 0),
                "episode": int(q.get("episode_number") or 0),
                "title": q.get("title", "") or q.get("query", ""),
                "query": q.get("query", ""),
                "year": q.get("year"),
                "3let_language": three_let,
            }
            return self.tvsubtitles.search(item) or []
        except Exception as e:
            log(__name__, "TVS search error: %s" % e)
            return []

    def _build_tk_item(self):
        q = self.query
        # Decide if this is a manual search (no structured title/show info)
        is_manual = bool(q.get("query")) and not q.get("title") and not q.get("tvshow")
        three_let = get_3let_languages(self.params)
        return {
            "mansearch": is_manual,
            "mansearchstr": q.get("query", ""),
            "tvshow": q.get("tvshow", ""),
            "season": int(q.get("season_number") or 0),
            "episode": int(q.get("episode_number") or 0),
            "title": q.get("title", "") or q.get("query", ""),
            "year": q.get("year", ""),
            "3let_language": three_let,
            "file_original_path": q.get("file_original_path", ""),
            "rar": bool(q.get("rar", False)),
        }

    # ── List results ──────────────────────────────────────────────────────────

    def list_subtitles(self):
        if not self.subtitles:
            xbmcplugin.endOfDirectory(self.handle)
            return

        listitems = []
        for sub in self.subtitles:
            li = xbmcgui.ListItem(label=sub["label"], label2=sub["label2"])
            li.setArt({"icon": sub["icon"], "thumb": sub["flag"]})
            li.setProperty("sync", "true" if sub["sync"] else "false")
            li.setProperty("hearing_imp", "true" if sub["hearing_imp"] else "false")
            listitems.append(li)

        if __addon__.getSetting("dualsub_enable") == "true":
            # Multiselect: select 1 or 2 subtitles
            # Convention: 1st selected → TOP,  2nd selected → BOTTOM
            ret = None
            while True:
                ret = __msg_box__.multiselect(
                    "Select subtitles  (1st = Top,  2nd = Bottom)", listitems, useDetails=True
                )
                if ret is None:
                    break
                if len(ret) > 2:
                    __msg_box__.ok("", "Please select at most 2 subtitles.")
                else:
                    break

            if ret and len(ret) > 0:
                sel = ret[:2]

                if len(sel) == 1:
                    url, li = self._build_single_selection_item(self.subtitles[sel[0]])
                    xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=False)
                else:
                    # Two subtitles: 1st selected=TOP, 2nd selected=BOTTOM
                    # mergesubs(subs): subs[0]=bottom, subs[1]=top
                    ids_ordered = [
                        self.subtitles[sel[1]]["id"],  # bottom (2nd selected)
                        self.subtitles[sel[0]]["id"],  # top    (1st selected)
                    ]
                    url = "plugin://%s/?action=download&ids=%s" % (
                        __scriptid__, quote(json.dumps(ids_ordered))
                    )
                    label = "[TOP] %s  +  [BOT] %s" % (
                        self.subtitles[sel[0]]["label2"],
                        self.subtitles[sel[1]]["label2"],
                    )
                    li = xbmcgui.ListItem(label2=label)
                    xbmcplugin.addDirectoryItem(handle=self.handle, url=url, listitem=li, isFolder=False)
        else:
            # Non-dual mode — add all subtitles directly to list
            for i, sub in enumerate(self.subtitles):
                url, li = self._build_single_selection_item(sub, listitems[i])
                xbmcplugin.addDirectoryItem(
                    handle=self.handle, url=url, listitem=li, isFolder=False
                )

        xbmcplugin.endOfDirectory(self.handle)

    # ── Download ──────────────────────────────────────────────────────────────

    def download(self):
        action = self.params.get("action", "download")

        if action == "downloadphonetic":
            single_id = unquote(self.params.get("id", ""))
            source_lang = self._normalize_lang_code(unquote(self.params.get("lang", "")))
            _clean_subdir()
            _ensure_subdir()
            original_path = self._download_by_id(single_id)
            if not original_path:
                return

            generated_path = self._generate_phonetic_variant(original_path, source_lang)
            finalfile = mergesubs([original_path, generated_path]) if generated_path else original_path

            li = xbmcgui.ListItem(label=finalfile)
            xbmcplugin.addDirectoryItem(
                handle=self.handle, url=finalfile, listitem=li, isFolder=False
            )
            return

        # Single subtitle (non-dual or single selection)
        if action == "downloadstd" or "ids" not in self.params:
            single_id = unquote(self.params.get("id", ""))
            _clean_subdir()
            _ensure_subdir()
            path = self._download_by_id(single_id)
            if path:
                li = xbmcgui.ListItem(label=path)
                xbmcplugin.addDirectoryItem(
                    handle=self.handle, url=path, listitem=li, isFolder=False
                )
            return

        # Dual subtitles
        ids = json.loads(unquote(self.params.get("ids", "[]")))
        _clean_subdir()
        _ensure_subdir()

        subs = []
        for encoded_id in ids:
            path = self._download_by_id(encoded_id)
            if path:
                subs.append(path)

        # Apply swap
        if action == "downloadswap":
            subs.reverse()
        if __addon__.getSetting("dualsub_swap") == "true":
            subs.reverse()

        if len(subs) >= 2:
            finalfile = mergesubs(subs)
        elif subs:
            finalfile = subs[0]
        else:
            log(__name__, "No subtitle files downloaded")
            return

        li = xbmcgui.ListItem(label=finalfile)
        xbmcplugin.addDirectoryItem(
            handle=self.handle, url=finalfile, listitem=li, isFolder=False
        )

    def _build_single_selection_item(self, subtitle, list_item=None):
        single_id = quote(subtitle["id"])
        lang_code = self._normalize_lang_code(subtitle.get("lang_code", ""))

        if self._should_generate_phonetic(subtitle):
            url = "plugin://%s/?action=downloadphonetic&id=%s&lang=%s" % (
                __scriptid__, single_id, quote(lang_code)
            )
            label = "[TOP] Ukrainian phonetic  +  [BOT] %s" % subtitle["label2"]
            li = list_item or xbmcgui.ListItem(label=subtitle["label"], label2=label)
            li.setLabel2(label)
            return url, li

        url = "plugin://%s/?action=downloadstd&id=%s" % (__scriptid__, single_id)
        li = list_item or xbmcgui.ListItem(label=subtitle["label"], label2=subtitle["label2"])
        return url, li

    def _should_generate_phonetic(self, subtitle):
        if __addon__.getSetting("phonetic_ua_enable") != "true":
            return False
        return self._normalize_lang_code(subtitle.get("lang_code", "")) in _PHONETIC_SUPPORTED_LANGS

    def _normalize_lang_code(self, language):
        value = (language or "").strip().lower()
        mapping = {
            "czech": "cs",
            "ces": "cs",
            "cze": "cs",
            "cs": "cs",
            "cz": "cs",
            "slovak": "sk",
            "slk": "sk",
            "slo": "sk",
            "sk": "sk",
            "sky": "sk",
            "ukrainian": "uk",
            "uk": "uk",
            "ua": "uk",
            "english": "en",
            "en": "en",
        }
        return mapping.get(value, value)

    def _phonetic_source_language(self, fallback_lang):
        value = __addon__.getSetting("phonetic_ua_source_lang") or "0"
        try:
            idx = int(value)
        except (TypeError, ValueError):
            idx = 0
        mapping = {0: "auto", 1: "cs", 2: "sk"}
        configured = mapping.get(idx, "auto")
        if configured != "auto":
            return configured
        fallback = self._normalize_lang_code(fallback_lang)
        return fallback if fallback in _PHONETIC_SUPPORTED_LANGS else "auto"

    def _generate_phonetic_variant(self, subtitle_path, source_lang):
        try:
            generated = generate_phonetic_subtitle(
                subtitle_path,
                _SUBDIR,
                self._phonetic_source_language(source_lang),
            )
            log(__name__, "Generated phonetic subtitle: %s" % generated)
            return generated
        except Exception as e:
            log(__name__, "Phonetic subtitle generation failed: %s" % e)
            return None

    def _download_by_id(self, encoded_id):
        """Route download to OS, TK, or TVS based on the encoded ID prefix."""
        if not encoded_id:
            return None
        if encoded_id.startswith("os:"):
            return self._download_os(encoded_id[3:])
        elif encoded_id.startswith("tk:"):
            # Format: "tk:<sub_id>:<link_file>"
            rest = encoded_id[3:]
            parts = rest.split(":", 1)
            if len(parts) == 2:
                sub_id, link_file = parts
                return self._download_tk(sub_id, link_file)
            log(__name__, "Invalid TK id format: %s" % encoded_id)
        elif encoded_id.startswith("tvs:"):
            return self._download_tvs(encoded_id[4:])
        return None

    def _download_os(self, file_id_str):
        """Download subtitle from OpenSubtitles.com. Returns local file path."""
        try:
            file_id = int(file_id_str)
        except (ValueError, TypeError):
            log(__name__, "Invalid OS file_id: %s" % file_id_str)
            return None

        try:
            file_data = self.open_subtitles.download_subtitle(
                {"file_id": file_id, "sub_format": self.sub_format}
            )
            content = file_data.get("content")
        except AuthenticationError as e:
            error(__name__, "Authentication error: %s" % e)
            return None
        except BadUsernameError as e:
            error(__name__, "Bad username (use username, not email): %s" % e)
            return None
        except DownloadLimitExceeded as e:
            msg = "Download limit exceeded. Create a free account at opensubtitles.com for more downloads." \
                if not self.os_username else "Daily download limit reached for your account."
            error(__name__, msg)
            return None
        except (TooManyRequests, ServiceUnavailable, ProviderError, ValueError) as e:
            error(__name__, "OpenSubtitles error: %s" % e)
            return None

        if not content:
            log(__name__, "OS returned empty content for file_id %s" % file_id)
            return None

        subtitle_path = os.path.join(_SUBDIR, "OS_%s.%s" % (file_id, self.sub_format))
        with open(subtitle_path, "wb") as f:
            f.write(content)
        log(__name__, "OS subtitle saved to %s" % subtitle_path)
        return subtitle_path

    def _download_tk(self, sub_id, link_file):
        """Download subtitle from Titulky.com. Returns local file path."""
        # Login required for download
        if not self.titulky.login(self.tk_username, self.tk_password):
            __msg_box__.ok("Titulky.com", "Login failed. Check your Titulky.com username and password in addon settings.")
            return None

        zip_path = self.titulky.download(sub_id, link_file)
        if not zip_path:
            log(__name__, "TK download returned no zip")
            return None

        # Extract subtitle from zip
        subtitle_exts = {".srt", ".sub", ".ass", ".ssa", ".txt"}
        subtitle_path = None
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                for name in zf.namelist():
                    if os.path.splitext(name)[1].lower() in subtitle_exts:
                        basename = os.path.basename(name) or ("TK_%s.srt" % sub_id)
                        extract_path = os.path.join(_SUBDIR, basename)
                        with open(extract_path, "wb") as f:
                            f.write(zf.read(name))
                        subtitle_path = extract_path
                        log(__name__, "TK subtitle extracted to %s" % subtitle_path)
                        break
        except zipfile.BadZipFile as e:
            log(__name__, "TK zip extraction error: %s" % e)
            # Maybe it's a direct subtitle file, not a zip
            if os.path.exists(zip_path):
                subtitle_path = zip_path
        except Exception as e:
            log(__name__, "TK extraction error: %s" % e)

        return subtitle_path

    def _download_tvs(self, sub_id):
        """Download subtitle from TVsubtitles.net. Returns local file path."""
        zip_path = self.tvsubtitles.download(sub_id)
        if not zip_path:
            log(__name__, "TVS download returned no file")
            return None

        # Extract subtitle from zip
        subtitle_exts = {".srt", ".sub", ".ass", ".ssa", ".txt"}
        subtitle_path = None
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                for name in zf.namelist():
                    if os.path.splitext(name)[1].lower() in subtitle_exts:
                        basename = os.path.basename(name) or ("TVS_%s.srt" % sub_id)
                        extract_path = os.path.join(_SUBDIR, basename)
                        with open(extract_path, "wb") as f:
                            f.write(zf.read(name))
                        subtitle_path = extract_path
                        log(__name__, "TVS subtitle extracted to %s" % subtitle_path)
                        break
        except zipfile.BadZipFile:
            log(__name__, "TVS: not a zip, treating as direct subtitle file")
            if os.path.exists(zip_path):
                subtitle_path = zip_path
        except Exception as e:
            log(__name__, "TVS extraction error: %s" % e)

        return subtitle_path
