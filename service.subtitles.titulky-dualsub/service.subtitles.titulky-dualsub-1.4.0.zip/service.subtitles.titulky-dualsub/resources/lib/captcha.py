# -*- coding: utf-8 -*-
"""Captcha solver for Titulky.com downloads (falls back to keyboard dialog)."""
import xbmc
import xbmcgui
import xbmcvfs
import os


class CaptchaWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        self.img = kwargs.get('captcha')
        title_text = kwargs.get('title_text', 'Enter captcha')
        self.kbd = xbmc.Keyboard('', title_text, False)

    def onInit(self):
        try:
            self.getControl(101).setImage(self.img)
        except Exception:
            pass

    def get(self):
        self.show()
        xbmc.sleep(500)
        self.kbd.doModal()
        if self.kbd.isConfirmed():
            text = self.kbd.getText()
            self.close()
            return text
        self.close()
        return False


def ask_for_captcha(addon, img, title):
    """Display captcha image and ask for solution. Falls back to plain keyboard."""
    addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
    current_skin = xbmc.getSkinDir()
    skin_xml = os.path.join(addon_path, 'resources', 'skins', current_skin, '720p', 'captcha-image.xml')
    default_xml = os.path.join(addon_path, 'resources', 'skins', 'default', '720p', 'captcha-image.xml')

    if xbmcvfs.exists(skin_xml):
        solver = CaptchaWindow('captcha-image.xml', addon_path, current_skin, '720p',
                               captcha=img, title_text=title)
        return solver.get()
    elif xbmcvfs.exists(default_xml):
        solver = CaptchaWindow('captcha-image.xml', addon_path, 'default', '720p',
                               captcha=img, title_text=title)
        return solver.get()
    else:
        # Fallback: plain keyboard (no image preview)
        kbd = xbmc.Keyboard('', title, False)
        kbd.doModal()
        if kbd.isConfirmed():
            return kbd.getText()
        return False
