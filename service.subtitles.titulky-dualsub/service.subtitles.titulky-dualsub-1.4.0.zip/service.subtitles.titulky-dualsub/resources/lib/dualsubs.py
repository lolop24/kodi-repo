# -*- coding: utf-8 -*-
"""
Merges two subtitle files into a single ASS file with dual-position display.
Based on peno64/service.subtitles.opensubtitles-com-dualsub (GPL-2.0).
"""
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import os
import uuid
from json import loads, dumps

try:
    translatePath = xbmcvfs.translatePath
except AttributeError:
    translatePath = xbmc.translatePath

pysubs2 = None  # lazy import in mergesubs()

__addon__ = xbmcaddon.Addon()
__profile__ = translatePath(__addon__.getAddonInfo('profile'))
__temp__ = translatePath(os.path.join(__profile__, 'temp'))
__msg_box__ = xbmcgui.Dialog()

# ── Settings lookup tables (settings.xml uses type="select" → stores index) ──

_FONTS = ["Arial", "Verdana", "DejaVu Sans"]
_COLORS = ["White", "Yellow"]
_CHARSETS_NAMES = [
    "Auto Chardet", "UTF8",
    "Central Europe (Windows)", "Central Europe (ISO)",
    "Cyrillic (Windows)", "Cyrillic (ISO)",
    "Western Europe (Windows)",
]
_LAYOUTS = ["Bottom-Top", "Bottom Left-Right", "Bottom-Bottom"]


def _idx(setting_id, default=0):
    """Read a type='select' setting as int index. Handles legacy string values gracefully."""
    val = __addon__.getSetting(setting_id)
    try:
        return int(val)
    except (ValueError, TypeError):
        return default


def _lookup(setting_id, options, default=0):
    """Read a select setting, handling both index and legacy string values."""
    val = __addon__.getSetting(setting_id)
    # Try as index first
    try:
        idx = int(val)
        return options[min(idx, len(options) - 1)]
    except (ValueError, TypeError):
        pass
    # Try as string match
    if val in options:
        return val
    return options[default]


def _font(setting_id):
    return _lookup(setting_id, _FONTS)


def _color(setting_id):
    return _lookup(setting_id, _COLORS)


def _charset(setting_id):
    return _lookup(setting_id, _CHARSETS_NAMES)


def mergesubs(file):
    """
    Merge subtitle files into a dual-subtitle ASS file.
    file[0] → bottom position, file[1] → top position.
    Returns path to the merged .ass file.
    """
    global pysubs2
    if pysubs2 is None:
        try:
            import pysubs2 as _p
        except ImportError:
            import sys
            addon_lib = os.path.dirname(__file__)
            if addon_lib not in sys.path:
                sys.path.insert(0, addon_lib)
            import pysubs2 as _p
        pysubs2 = _p

    loc = _lookup('subtitle_locations', _LAYOUTS)
    bottom_top   = (loc == 'Bottom-Top')
    bottom_bottom = (loc == 'Bottom-Bottom')
    left_right   = (loc == 'Bottom Left-Right')

    # Load subtitle files into pysubs2
    subs = [pysubs2.SSAFile()]   # subs[0] = output container
    bottom = True
    for sub_path in file:
        encoding = _charset_detect(sub_path, bottom)
        try:
            result = pysubs2.load(sub_path, encoding=encoding)
        except Exception as e:
            __msg_box__.ok("DualSub Error", "Cannot load subtitle:\n%s\n%s" % (sub_path, e))
            raise
        subs.append(result)
        bottom = not bottom

    # Ensure temp dir exists
    os.makedirs(__temp__, exist_ok=True)
    ass_path = os.path.join(__temp__, "%s.ass" % str(uuid.uuid4()))

    # ── Build styles ──────────────────────────────────────────────────────────
    top_style    = pysubs2.SSAStyle()
    bottom_style = pysubs2.SSAStyle()

    # Alignment
    top_style.alignment    = 8 if bottom_top else 2   # 8=top-center, 2=bottom-center
    bottom_style.alignment = 2

    if left_right:
        top_style.marginl    = 200
        bottom_style.marginr = 200

    # Top style
    top_style.fontsize   = int(__addon__.getSetting('top_fontsize'))
    top_style.bold       = (__addon__.getSetting('top_bold') == 'true')
    top_style.fontname   = _resolve_font(_font('top_font'))
    top_style.primarycolor = pysubs2.Color(255, 255, 255, 0)  # always white
    if __addon__.getSetting('top_background') == 'true':
        top_style.backcolor    = pysubs2.Color(0, 0, 0, 128)
        top_style.outlinecolor = pysubs2.Color(0, 0, 0, 128)
        top_style.borderstyle  = 4
    top_style.shadow   = int(__addon__.getSetting('top_shadow'))
    top_style.outline  = int(__addon__.getSetting('top_outline'))
    top_style.marginv  = int(__addon__.getSetting('top_verticalmargin'))

    if bottom_bottom:
        delta = max(int(__addon__.getSetting('top_fontsize')),
                    int(__addon__.getSetting('bottom_fontsize')))
        delta = 0 if delta <= 17 else (delta - 17) * 2
        top_style.marginv += 40 + delta

    # Bottom style
    bottom_style.fontsize   = int(__addon__.getSetting('bottom_fontsize'))
    bottom_style.bold       = (__addon__.getSetting('bottom_bold') == 'true')
    bottom_style.fontname   = _resolve_font(_font('bottom_font'))
    bottom_style.primarycolor = pysubs2.Color(255, 255, 0, 0)  # always yellow
    if __addon__.getSetting('bottom_background') == 'true':
        bottom_style.backcolor    = pysubs2.Color(0, 0, 0, 128)
        bottom_style.outlinecolor = pysubs2.Color(0, 0, 0, 128)
        bottom_style.borderstyle  = 4
    bottom_style.shadow  = int(__addon__.getSetting('bottom_shadow'))
    bottom_style.outline = int(__addon__.getSetting('bottom_outline'))
    bottom_style.marginv = int(__addon__.getSetting('bottom_verticalmargin'))

    if __addon__.getSetting('dualsub_swap') == 'true':
        subs[0].styles['top-style']    = bottom_style
        subs[0].styles['bottom-style'] = top_style
    else:
        subs[0].styles['top-style']    = top_style
        subs[0].styles['bottom-style'] = bottom_style

    # Inline ASS color override tags (format: \1c&HBBGGRR& — BGR order, no alpha)
    # These force colors even if Kodi's system subtitle color setting overrides styles.
    def _ass_color_tag(color):
        return '{\\1c&H%02X%02X%02X&}' % (color.b, color.g, color.r)

    _bottom_ctag = _ass_color_tag(subs[0].styles['bottom-style'].primarycolor)
    _top_ctag    = _ass_color_tag(subs[0].styles['top-style'].primarycolor)

    # ── Merge events ──────────────────────────────────────────────────────────
    if __addon__.getSetting('autoShft') == 'true':
        timeThresh = int(__addon__.getSetting('autoShftAmt'))
    else:
        timeThresh = -1

    minTime = int(__addon__.getSetting('minTime'))
    l1 = len(subs[1])
    l2 = len(subs[2]) if len(subs) >= 3 else 0

    i = j = 0
    prevStart1    = -1
    prevEnd1      = 999999
    prevIndex2    = -1
    prevIndexBot  = -1
    prevIndexTop  = -1

    while i < l1 or j < l2:
        if i < l1:
            line1 = subs[1][i].copy()
            line1.style = 'bottom-style'
            line1.text  = _bottom_ctag + line1.text
            prevIndexBot = _setminTime(minTime, prevIndexBot, subs[0], line1)
            subs[0].append(line1)

        if timeThresh < 0:
            j = i
            if j < l2:
                line2 = subs[2][j].copy()
                line2.style = 'top-style'
                line2.text  = _top_ctag + line2.text
                prevIndexTop = _setminTime(minTime, prevIndexTop, subs[0], line2)
                subs[0].append(line2)
        else:
            while j < l2:
                line2 = subs[2][j].copy()
                if i < l1 and line2.start > line1.start + timeThresh:
                    break
                line2.style = 'top-style'
                line2.text  = _top_ctag + line2.text
                if i < l1:
                    if abs(line2.start - line1.start) <= timeThresh:
                        if prevIndex2 < 0 or line1.start > subs[0][prevIndex2].end:
                            line2.start = line1.start
                        else:
                            line2.start = subs[0][prevIndex2].end + 10
                    if abs(line2.end - line1.end) <= timeThresh:
                        line2.end = line1.end
                if prevIndex2 >= 0 and subs[0][prevIndex2].start == prevStart1:
                    if line2.start > prevEnd1:
                        subs[0][prevIndex2].end = prevEnd1
                    elif line2.start <= prevEnd1:
                        subs[0][prevIndex2].end = line2.start - 10
                prevIndex2   = len(subs[0])
                prevIndexTop = _setminTime(minTime, prevIndexTop, subs[0], line2)
                subs[0].append(line2)
                j += 1

            if i < l1:
                prevStart1 = line1.start
                prevEnd1   = line1.end
            else:
                prevStart1 = -1
                prevEnd1   = 999999
        i += 1

    _setminTime(minTime, prevIndexBot, subs[0], None)
    _setminTime(minTime, prevIndexTop, subs[0], None)

    subs[0].save(ass_path, format_='ass')
    return ass_path


def _resolve_font(name):
    if name == '<Kodi Subtitles Font>':
        try:
            result = xbmc.executeJSONRPC(dumps({
                'jsonrpc': '2.0', 'id': 1,
                'method': 'Settings.GetSettingValue',
                'params': {'setting': 'subtitles.fontname'}
            }))
            name = loads(result).get('result', {}).get('value', '') or 'Arial'
        except Exception:
            name = 'Arial'
    return name


def _charset_detect(filename, bottom):
    label = _charset('bottom_characterset' if bottom else 'top_characterset')
    if label == 'Auto Chardet':
        try:
            import chardet
            with open(filename, 'rb') as fi:
                raw = fi.read()
            enc = chardet.detect(raw).get('encoding') or 'utf-8'
            return 'gbk' if enc.lower() == 'gb2312' else enc
        except Exception:
            return 'utf-8'
    _map = {
        'UTF8': 'utf-8', 'UTF16': 'utf-16',
        'Central Europe (Windows)': 'windows-1250',
        'Central Europe (ISO)':     'iso-8859-2',
        'Cyrillic (Windows)':       'windows-1251',
        'Cyrillic (ISO)':           'iso-8859-5',
        'Western Europe (Windows)': 'windows-1252',
    }
    return _map.get(label, 'utf-8')


def _setminTime(minTime, prevIndex, events, line1):
    if minTime > 0 and prevIndex >= 0:
        line0 = events[prevIndex]
        dur = line0.end - line0.start
        if dur < minTime:
            dur = minTime
            if line1 is not None and line0.start + dur > line1.start:
                dur = line1.start - line0.start - 50
            line0.end = line0.start + dur
    return len(events)
