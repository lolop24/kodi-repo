# -*- coding: utf-8 -*-
"""
HTTP client for TVsubtitles.net subtitle service.
Searches TV show subtitles by show name, season, and episode.
"""
import urllib.parse
import urllib.request
import re
import os
import time

import xbmc
import xbmcvfs
import xbmcgui

from resources.lib.utilities import log


# Language name → TVsubtitles.net 2-letter code
# NOTE: TVS uses non-standard codes for some languages (ua, gr, cn, jp, cz, br)
_LANG_TO_TVSCODE = {
    "English": "en", "Spanish": "es", "French": "fr", "German": "de",
    "Portuguese": "pt", "Russian": "ru", "Ukrainian": "ua", "Italian": "it",
    "Greek": "gr", "Arabic": "ar", "Hungarian": "hu", "Polish": "pl",
    "Turkish": "tr", "Dutch": "nl", "Swedish": "sv", "Danish": "da",
    "Finnish": "fi", "Korean": "ko", "Chinese": "cn", "Japanese": "jp",
    "Bulgarian": "bg", "Czech": "cz", "Romanian": "ro", "Croatian": "hr",
    "Slovak": "sk", "Serbian": "sr", "Portuguese(BR)": "br",
}

# Reverse: TVS flag code → language name
_TVSCODE_TO_LANG = {v: k for k, v in _LANG_TO_TVSCODE.items()}

# TVsubtitles language label → Kodi language name
_TVS_LANG_TO_KODI = {
    "English": "English", "Spanish": "Spanish", "French": "French",
    "German": "German", "Portuguese": "Portuguese", "Portuguese(BR)": "Portuguese",
    "Russian": "Russian", "Ukrainian": "Ukrainian", "Italian": "Italian",
    "Greek": "Greek", "Arabic": "Arabic", "Hungarian": "Hungarian",
    "Polish": "Polish", "Turkish": "Turkish", "Dutch": "Dutch",
    "Swedish": "Swedish", "Danish": "Danish", "Finnish": "Finnish",
    "Korean": "Korean", "Chinese": "Chinese", "Japanese": "Japanese",
    "Bulgarian": "Bulgarian", "Czech": "Czech", "Romanian": "Romanian",
    "Croatian": "Croatian", "Slovak": "Slovak", "Serbian": "Serbian",
}

SERVER_URL = "https://www.tvsubtitles.net"
REQUEST_TIMEOUT = 8


class TVSubtitlesClient(object):

    def __init__(self, addon):
        self.addon = addon
        self._opener = urllib.request.build_opener()
        self._opener.addheaders = [
            ("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi"),
            ("Accept-Language", "en-US,en;q=0.9"),
        ]

    def search(self, item):
        """
        Search for TV show subtitles.
        item keys: tvshow, season, episode, title, 3let_language
        Returns list of dicts: {filename, id, lang, rating, sync, lang_flag}
        """
        tvshow = item.get("tvshow", "") or item.get("title", "")
        season = int(item.get("season") or 0)
        episode = int(item.get("episode") or 0)

        if not tvshow:
            return []

        # 1) Search for the show
        show_id = self._search_show(tvshow)
        if not show_id:
            log(__name__, "TVS: show not found: %s" % tvshow)
            return []

        # 2) Get episode list for the season
        episodes = self._get_season_episodes(show_id, season)
        if not episodes:
            log(__name__, "TVS: no episodes for %s S%02d" % (tvshow, season))
            return []

        # 3) Find matching episode
        episode_id = None
        ep_lang_flags = set()
        for ep in episodes:
            if ep.get("num") == episode:
                episode_id = ep.get("id")
                ep_lang_flags = ep.get("lang_flags", set())
                break

        if not episode_id:
            log(__name__, "TVS: episode %d not found in season %d" % (episode, season))
            return []

        # 3b) Quick check: does the episode have any of our requested languages?
        # Convert requested 3-letter codes to TVS codes for fast comparison
        languages_3 = item.get("3let_language", [])
        wanted_tvs_codes = set()
        for lang3 in languages_3:
            kodi_name = xbmc.convertLanguage(lang3, xbmc.ENGLISH_NAME)
            tvs_code = _LANG_TO_TVSCODE.get(kodi_name)
            if tvs_code:
                wanted_tvs_codes.add(tvs_code)

        if ep_lang_flags and wanted_tvs_codes and not (ep_lang_flags & wanted_tvs_codes):
            log(__name__, "TVS: episode %d has flags %s, none match wanted %s — skipping" % (
                episode, ep_lang_flags, wanted_tvs_codes))
            return []

        # 4) Get subtitles for the episode
        subtitles = self._get_episode_subtitles(episode_id)
        log(__name__, "TVS: found %d subtitles for ep %s" % (len(subtitles), episode_id))

        # 5) Filter by language
        if not languages_3:
            languages_3 = item.get("3let_language", [])
        if languages_3:
            filtered = []
            for sub in subtitles:
                lang_name = sub.get("lang", "")
                kodi_name = _TVS_LANG_TO_KODI.get(lang_name, lang_name)
                lang_3 = xbmc.convertLanguage(kodi_name, xbmc.ISO_639_2)
                if lang_3 in languages_3:
                    filtered.append(sub)
            if filtered:
                subtitles = filtered

        # Build results — Ukrainian subtitles sorted first, then by downloads
        subtitles.sort(key=lambda s: (s.get("lang") != "Ukrainian", -s.get("downloads", 0)))

        max_dl = max((s.get("downloads", 0) for s in subtitles), default=1) or 1
        results = []
        for sub in subtitles:
            lang_name = sub.get("lang", "")
            kodi_name = _TVS_LANG_TO_KODI.get(lang_name, lang_name)
            results.append({
                "filename": sub.get("release", lang_name),
                "id": str(sub.get("sub_id", "")),
                "lang": kodi_name,
                "rating": int(sub.get("downloads", 0) * 5 / max_dl),
                "sync": False,
                "lang_flag": xbmc.convertLanguage(kodi_name, xbmc.ISO_639_1),
            })

        return results

    def download(self, sub_id):
        """Download subtitle by ID. Returns local file path or None."""
        dest_dir = os.path.join(
            xbmcvfs.translatePath(self.addon.getAddonInfo("profile")), "temp"
        )
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, "tvs_download.zip")

        url = "%s/download-%s.html" % (SERVER_URL, sub_id)
        log(__name__, "TVS: downloading %s" % url)

        try:
            req = urllib.request.Request(url)
            req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi")
            req.add_header("Referer", "%s/subtitle-%s.html" % (SERVER_URL, sub_id))
            response = self._opener.open(req, timeout=REQUEST_TIMEOUT)
            data = response.read()
        except Exception as e:
            log(__name__, "TVS download error: %s" % e)
            return None

        if not data or len(data) < 100:
            log(__name__, "TVS: download returned too little data")
            return None

        with open(dest, "wb") as f:
            f.write(data)

        log(__name__, "TVS: saved to %s (%d bytes)" % (dest, len(data)))
        return dest

    # ── Private helpers ───────────────────────────────────────────────────────

    def _fetch(self, url, data=None):
        """Fetch URL and return decoded text content."""
        try:
            if data:
                if isinstance(data, str):
                    data = data.encode("utf-8")
                req = urllib.request.Request(url, data)
            else:
                req = urllib.request.Request(url)
            req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi")
            response = self._opener.open(req, timeout=REQUEST_TIMEOUT)
            raw = response.read()
            # Try to decode
            for enc in ("utf-8", "latin-1", "windows-1252"):
                try:
                    return raw.decode(enc)
                except (UnicodeDecodeError, AttributeError):
                    continue
            return raw.decode("utf-8", errors="replace")
        except Exception as e:
            log(__name__, "TVS fetch error for %s: %s" % (url, e))
            return ""

    def _search_show(self, name):
        """Search for a show by name. Returns show ID (int) or None."""
        post_data = urllib.parse.urlencode({"q": name})
        content = self._fetch(SERVER_URL + "/search.php", post_data)
        if not content:
            return None

        # Parse search results: links like tvshow-ID-SEASONS.html
        matches = re.findall(
            r'<a[^>]+href="/tvshow-(\d+)-\d+\.html"[^>]*>([^<]+)</a>',
            content, re.IGNORECASE
        )
        if not matches:
            log(__name__, "TVS: no search results for '%s'" % name)
            return None

        # Find best match using simple case-insensitive comparison
        name_lower = name.lower().strip()
        best_id = None
        best_score = 0
        for show_id, show_name in matches:
            show_name_clean = show_name.strip().lower()
            if show_name_clean == name_lower:
                return int(show_id)  # exact match
            # Simple similarity: count matching words
            name_words = set(name_lower.split())
            show_words = set(show_name_clean.split())
            if name_words and show_words:
                score = len(name_words & show_words) / max(len(name_words), len(show_words))
                if score > best_score:
                    best_score = score
                    best_id = int(show_id)

        if best_id and best_score > 0.3:
            log(__name__, "TVS: matched show ID %d (score=%.2f)" % (best_id, best_score))
            return best_id

        # Fallback: return first result
        log(__name__, "TVS: using first result, ID %s" % matches[0][0])
        return int(matches[0][0])

    def _get_season_episodes(self, show_id, season):
        """Get list of episodes for a show season.
        Returns list of {num, id, name, lang_flags} where lang_flags is a set of
        TVS language codes available for that episode (e.g. {'en', 'ua', 'ru'}).
        """
        url = "%s/tvshow-%d-%d.html" % (SERVER_URL, show_id, season)
        content = self._fetch(url)
        if not content:
            return []

        episodes = []
        # Each episode row: <td>3x08</td><td ...><a href="episode-73502.html"><b>Name</b></a></td>
        #   <td>COUNT</td><td><nobr><a href="subtitle-..."><img src="flags/en.gif"></a>...</nobr></td>
        for m in re.finditer(
            r'<td>\s*(\d+)x(\d+)\s*</td>\s*'
            r'<td[^>]*>\s*<a[^>]+href="[/]?episode-(\d+)\.html"[^>]*>'
            r'(?:<b>)?([^<]*)(?:</b>)?</a>\s*</td>\s*'
            r'<td[^>]*>[^<]*</td>\s*'       # Amount column
            r'<td[^>]*>(.*?)</td>',          # Subtitles column with flags
            content, re.IGNORECASE | re.DOTALL
        ):
            ep_season = int(m.group(1))
            ep_num = int(m.group(2))
            ep_id = m.group(3)
            ep_name = m.group(4).strip()
            flags_html = m.group(5)

            # Extract available language codes from flag images
            lang_flags = set()
            for flag_m in re.finditer(r'flags/([^"]+)"', flags_html):
                code = os.path.splitext(flag_m.group(1))[0]
                lang_flags.add(code)

            if ep_season == season:
                episodes.append({
                    "num": ep_num, "id": ep_id,
                    "name": ep_name, "lang_flags": lang_flags,
                })

        log(__name__, "TVS: season %d has %d episodes" % (season, len(episodes)))
        return episodes

    def _get_episode_subtitles(self, episode_id):
        """Get all subtitles for an episode. Returns list of {sub_id, lang, release, downloads}."""
        url = "%s/episode-%s.html" % (SERVER_URL, episode_id)
        content = self._fetch(url)
        if not content:
            return []

        subtitles = []
        # Each subtitle is: <a href="/subtitle-ID.html"><div class="subtitlen">
        #   <h5><img src="images/flags/xx.gif">TITLE (RIP.RELEASE)</h5>
        #   <p ...>RIP</p> <p ...>RELEASE</p> ... <p ...>DOWNLOADS</p>
        # </div></a>
        for m in re.finditer(
            r'<a[^>]+href="[/]?subtitle-(\d+)\.html"[^>]*>\s*<div[^>]*class="subtitle[^"]*"[^>]*>(.*?)</div>\s*</a>',
            content, re.IGNORECASE | re.DOTALL
        ):
            sub_id = m.group(1)
            block = m.group(2)

            # Language from flag image: <img src="images/flags/ua.gif" ...>
            lang = ""
            flag_match = re.search(r'<img[^>]+src="[^"]*flags/([^"]+)"', block, re.IGNORECASE)
            if flag_match:
                lang_code = os.path.splitext(flag_match.group(1))[0]
                lang = _TVSCODE_TO_LANG.get(lang_code, lang_code)

            # Release name from <h5>: "Show SxEE (RIP.RELEASE)"
            release = ""
            h5_match = re.search(r'<h5[^>]*>(.*?)</h5>', block, re.IGNORECASE | re.DOTALL)
            if h5_match:
                release = re.sub(r'<[^>]+>', '', h5_match.group(1)).strip()

            # Download count from <p> with title="downloaded": ...NUMBER</p>
            downloads = 0
            dl_match = re.search(
                r'title="downloaded"[^>]*>.*?(\d[\d,]*)\s*</p>',
                block, re.IGNORECASE | re.DOTALL
            )
            if dl_match:
                downloads = int(dl_match.group(1).replace(",", ""))

            subtitles.append({
                "sub_id": sub_id,
                "lang": lang,
                "release": release or ("Subtitle %s" % sub_id),
                "downloads": downloads,
            })

        # Deduplicate by sub_id
        seen = set()
        unique = []
        for s in subtitles:
            if s["sub_id"] not in seen:
                seen.add(s["sub_id"])
                unique.append(s)

        return unique
