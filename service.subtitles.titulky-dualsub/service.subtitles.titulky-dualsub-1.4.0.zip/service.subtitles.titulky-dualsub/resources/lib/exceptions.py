# -*- coding: utf-8 -*-


class ProviderError(Exception):
    """Exception raised by providers."""
    pass


class ConfigurationError(ProviderError):
    """Raised when provider is misconfigured."""
    pass


class AuthenticationError(ProviderError):
    """Raised when login credentials fail."""
    pass


class ServiceUnavailable(ProviderError):
    """Raised on HTTP 503."""
    pass


class DownloadLimitExceeded(ProviderError):
    """Raised when download quota is exceeded."""
    pass


class TooManyRequests(ProviderError):
    """Raised on HTTP 429 rate limiting."""
    pass


class BadUsernameError(ProviderError):
    """Raised when user enters email instead of username."""
    pass
