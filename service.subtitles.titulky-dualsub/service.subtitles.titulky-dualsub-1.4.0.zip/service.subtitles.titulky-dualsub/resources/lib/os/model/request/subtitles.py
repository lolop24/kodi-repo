# -*- coding: utf-8 -*-
from datetime import date
from resources.lib.os.model.request.abstract import OpenSubtitlesRequest

TYPE_LIST = ["movie", "episode", "all"]
INCLUDE_LIST = ["include", "exclude", "only"]
INCLUDE_ONLY_LIST = ["include", "only"]
INCLUDE_EXCLUDE_LIST = ["include", "exclude"]


class OpenSubtitlesSubtitlesRequest(OpenSubtitlesRequest):
    def __init__(self, id_: int = None, imdb_id: int = None, tmdb_id: int = None,
                 type_="all", query="", languages="", moviehash="",
                 hearing_impaired="include", foreign_parts_only="include",
                 machine_translated="exclude", ai_translated="include",
                 order_by="", order_direction="",
                 parent_feature_id: int = None, parent_imdb_id: int = None,
                 parent_tmdb_id: int = None,
                 season_number: int = None, episode_number: int = None,
                 year: int = None, moviehash_match="include",
                 page: int = None, **catch_overflow):
        self._id = id_
        self._imdb_id = imdb_id
        self._tmdb_id = tmdb_id
        self._type = type_
        self._query = query
        self._languages = languages
        self._moviehash = moviehash
        self._hearing_impaired = hearing_impaired
        self._foreign_parts_only = foreign_parts_only
        self._machine_translated = machine_translated
        self._ai_translated = ai_translated
        self._order_by = order_by
        self._order_direction = order_direction
        self._parent_feature_id = parent_feature_id
        self._parent_imdb_id = parent_imdb_id
        self._parent_tmdb_id = parent_tmdb_id
        self._season_number = season_number
        self._episode_number = episode_number
        self._year = year
        self._moviehash_match = moviehash_match
        self._page = page
        super().__init__()
        self.DEFAULT_LIST = dict(
            ai_translated="include", episode_number=None, foreign_parts_only="include",
            hearing_impaired="include", id=None, imdb_id=None, languages="",
            machine_translated="exclude", moviehash="", moviehash_match="include",
            order_by="", order_direction="desc", page=None,
            parent_feature_id=None, parent_imdb_id=None, parent_tmdb_id=None,
            query="", season_number=None, tmdb_id=None, trusted_sources="include",
            type="all", year=None
        )

    @property
    def id(self): return self._id
    @property
    def imdb_id(self): return self._imdb_id
    @property
    def tmdb_id(self): return self._tmdb_id
    @property
    def type(self): return self._type
    @property
    def query(self): return self._query
    @property
    def languages(self): return self._languages
    @property
    def moviehash(self): return self._moviehash
    @property
    def hearing_impaired(self): return self._hearing_impaired
    @property
    def foreign_parts_only(self): return self._foreign_parts_only
    @property
    def machine_translated(self): return self._machine_translated
    @property
    def ai_translated(self): return self._ai_translated
    @property
    def order_by(self): return self._order_by
    @property
    def order_direction(self): return self._order_direction
    @property
    def parent_feature_id(self): return self._parent_feature_id
    @property
    def parent_imdb_id(self): return self._parent_imdb_id
    @property
    def parent_tmdb_id(self): return self._parent_tmdb_id
    @property
    def season_number(self): return self._season_number
    @property
    def episode_number(self): return self._episode_number
    @property
    def year(self): return self._year
    @property
    def moviehash_match(self): return self._moviehash_match
    @property
    def page(self): return self._page
