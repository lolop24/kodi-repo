# -*- coding: utf-8 -*-
from resources.lib.os.model.request.abstract import OpenSubtitlesRequest

SUB_FORMAT_LIST = ["srt", "sub", "mpl", "webvtt", "dfxp", "txt"]


class OpenSubtitlesDownloadRequest(OpenSubtitlesRequest):
    def __init__(self, file_id: int, sub_format="srt", file_name="",
                 in_fps: float = None, out_fps: float = None,
                 timeshift: float = None, force_download: bool = None,
                 **catch_overflow):
        self._file_id = file_id
        self._sub_format = sub_format
        self._file_name = file_name
        self._in_fps = in_fps
        self._out_fps = out_fps
        self._timeshift = timeshift
        self._force_download = force_download
        super().__init__()
        self.DEFAULT_LIST = dict(
            file_id=None, file_name="", force_download=None,
            in_fps=None, out_fps=None, sub_format="srt", timeshift=None
        )

    @property
    def file_id(self): return self._file_id
    @property
    def sub_format(self): return self._sub_format
    @property
    def file_name(self): return self._file_name
    @property
    def in_fps(self): return self._in_fps
    @property
    def out_fps(self): return self._out_fps
    @property
    def timeshift(self): return self._timeshift
    @property
    def force_download(self): return self._force_download
