# -*- coding: utf-8 -*-
"""
Collects media metadata from Kodi for subtitle searching.
Provides helpers for language conversion and display formatting.
"""
import os
import xbmc
import xbmcaddon
import xbmcvfs

from resources.lib.utilities import log

__addon__ = xbmcaddon.Addon()

# Fallback map for languages xbmc.convertLanguage might not know
_LANG_NAME_TO_ISO1 = {
    "Ukrainian": "uk", "Czech": "cs", "Slovak": "sk", "English": "en",
    "Russian": "ru", "Polish": "pl", "Hungarian": "hu", "Romanian": "ro",
    "Bulgarian": "bg", "Serbian": "sr", "Croatian": "hr", "Slovenian": "sl",
    "German": "de", "French": "fr", "Spanish": "es", "Italian": "it",
    "Portuguese": "pt", "Dutch": "nl", "Swedish": "sv", "Norwegian": "no",
    "Danish": "da", "Finnish": "fi", "Greek": "el", "Turkish": "tr",
    "Arabic": "ar", "Hebrew": "he", "Chinese": "zh", "Japanese": "ja",
    "Korean": "ko",
}

_FILTER_OPTS = ["include", "exclude", "only"]


def _filter_setting(setting_id, default_idx=1):
    """Read a filter setting. Handles both index ('0'/'1'/'2') and legacy string values."""
    val = __addon__.getSetting(setting_id) or ""
    if val in _FILTER_OPTS:
        return val
    try:
        return _FILTER_OPTS[int(val)]
    except (ValueError, TypeError, IndexError):
        return _FILTER_OPTS[default_idx]


def get_file_path():
    """Return path of the currently playing file."""
    return xbmc.Player().getPlayingFile()


def get_media_data():
    """
    Return dict with media metadata from the currently playing video.
    Keys: title, year, season, episode, tvshow, query, type,
          season_number, episode_number, imdb_id, tmdb_id, parent_imdb_id
    """
    item = {
        "title": "",
        "year": "",
        "season": "",
        "episode": "",
        "tvshow": "",
        "query": "",
        "type": "movie",
        "season_number": None,
        "episode_number": None,
        "imdb_id": None,
        "tmdb_id": None,
        "parent_imdb_id": None,
        "parent_tmdb_id": None,
    }

    title = xbmc.getInfoLabel("VideoPlayer.Title")
    year = xbmc.getInfoLabel("VideoPlayer.Year")
    season = xbmc.getInfoLabel("VideoPlayer.Season")
    episode = xbmc.getInfoLabel("VideoPlayer.Episode")
    tvshow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
    imdb_id = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")

    item["title"] = title
    item["year"] = year
    item["tvshow"] = tvshow

    if tvshow and season and episode:
        item["type"] = "episode"
        item["season"] = season
        item["episode"] = episode
        try:
            item["season_number"] = int(season)
            item["episode_number"] = int(episode)
        except (ValueError, TypeError):
            pass
        item["query"] = "%s S%02dE%02d" % (tvshow, item["season_number"] or 0,
                                            item["episode_number"] or 0)
    elif title:
        item["query"] = title

    if imdb_id:
        raw = imdb_id.lstrip("t")
        try:
            item["imdb_id"] = int(raw)
        except (ValueError, TypeError):
            pass

    if item.get("year"):
        try:
            item["year"] = int(item["year"])
        except (ValueError, TypeError):
            item["year"] = None

    log(__name__, "media_data: %s" % item)
    return item


def get_language_data(params):
    """
    Convert Kodi language params to a dict suitable for OS API queries.
    Kodi passes languages as pipe/comma-separated names, e.g. 'Czech,Slovak,Ukrainian'.
    """
    iso1_languages = []
    lang_param = params.get("languages", "")
    if lang_param:
        for lang in lang_param.replace("|", ",").split(","):
            lang = lang.strip()
            if not lang:
                continue
            converted = xbmc.convertLanguage(lang, xbmc.ISO_639_1)
            if not converted:
                # Fallback dict for languages Kodi might not know
                converted = _LANG_NAME_TO_ISO1.get(lang, "")
            if converted:
                iso1_languages.append(converted)
                log(__name__, "lang '%s' → '%s'" % (lang, converted))
            else:
                log(__name__, "lang '%s' → UNKNOWN, skipping" % lang)

    return {
        "languages": ",".join(iso1_languages),
        "hearing_impaired":  _filter_setting("hearing_impaired"),
        "foreign_parts_only": _filter_setting("foreign_parts_only"),
        "machine_translated": _filter_setting("machine_translated"),
        "ai_translated":      _filter_setting("ai_translated"),
    }


def get_3let_languages(params):
    """Return list of ISO 639-2 (3-letter) language codes for TitulkyClient."""
    result = []
    lang_param = params.get("languages", "")
    if lang_param:
        for lang in lang_param.replace("|", ",").split(","):
            lang = lang.strip()
            if lang:
                converted = xbmc.convertLanguage(lang, xbmc.ISO_639_2)
                if converted:
                    result.append(converted)
    return result


def convert_language(lang_code, to_name=False):
    """
    Convert a language code.
    If to_name=True, returns the English language name.
    Otherwise returns ISO 639-1 code.
    """
    if to_name:
        name = xbmc.convertLanguage(lang_code, xbmc.ENGLISH_NAME)
        return name if name else lang_code
    return xbmc.convertLanguage(lang_code, xbmc.ISO_639_1)


def clean_feature_release_name(title, release, movie_name):
    """Return the best display name for a subtitle entry."""
    name = release or movie_name or title or ""
    return name.strip()


def get_flag(language):
    """
    Return URL to flag image for a given language code (ISO 639-1 or OS code).
    Falls back to OpenSubtitles CDN.
    """
    lang_2 = xbmc.convertLanguage(language, xbmc.ISO_639_1)
    if not lang_2:
        lang_2 = language
    return "https://a.opensubtitles.com/static/flags/%s.png" % lang_2
