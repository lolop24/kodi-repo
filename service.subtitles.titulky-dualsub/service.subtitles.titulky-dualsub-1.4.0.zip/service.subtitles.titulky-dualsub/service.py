# -*- coding: utf-8 -*-
import sys
import xbmcplugin

from resources.lib.combined_downloader import CombinedSubtitleDownloader

CombinedSubtitleDownloader().handle_action()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
