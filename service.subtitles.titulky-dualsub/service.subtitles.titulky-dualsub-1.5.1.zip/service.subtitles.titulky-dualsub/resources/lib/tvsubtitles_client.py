# -*- coding: utf-8 -*-
"""
HTTP client for TVsubtitles.net subtitle service.
Searches TV show subtitles by show name, season, and episode.
"""
import html
import os
import re
import unicodedata
import urllib.parse
import urllib.request
from difflib import SequenceMatcher

import xbmc
import xbmcvfs

from resources.lib.utilities import log


# Language name -> TVsubtitles.net 2-letter code
# NOTE: TVS uses non-standard codes for some languages (ua, gr, cn, jp, cz, br)
_LANG_TO_TVSCODE = {
    "English": "en", "Spanish": "es", "French": "fr", "German": "de",
    "Portuguese": "pt", "Russian": "ru", "Ukrainian": "ua", "Italian": "it",
    "Greek": "gr", "Arabic": "ar", "Hungarian": "hu", "Polish": "pl",
    "Turkish": "tr", "Dutch": "nl", "Swedish": "sv", "Danish": "da",
    "Finnish": "fi", "Korean": "ko", "Chinese": "cn", "Japanese": "jp",
    "Bulgarian": "bg", "Czech": "cz", "Romanian": "ro", "Croatian": "hr",
    "Slovak": "sk", "Serbian": "sr", "Portuguese(BR)": "br",
}

# Reverse: TVS flag code -> language name
_TVSCODE_TO_LANG = {v: k for k, v in _LANG_TO_TVSCODE.items()}

# TVsubtitles language label -> Kodi language name
_TVS_LANG_TO_KODI = {
    "English": "English", "Spanish": "Spanish", "French": "French",
    "German": "German", "Portuguese": "Portuguese", "Portuguese(BR)": "Portuguese",
    "Russian": "Russian", "Ukrainian": "Ukrainian", "Italian": "Italian",
    "Greek": "Greek", "Arabic": "Arabic", "Hungarian": "Hungarian",
    "Polish": "Polish", "Turkish": "Turkish", "Dutch": "Dutch",
    "Swedish": "Swedish", "Danish": "Danish", "Finnish": "Finnish",
    "Korean": "Korean", "Chinese": "Chinese", "Japanese": "Japanese",
    "Bulgarian": "Bulgarian", "Czech": "Czech", "Romanian": "Romanian",
    "Croatian": "Croatian", "Slovak": "Slovak", "Serbian": "Serbian",
}

SERVER_URL = "https://www.tvsubtitles.net"
REQUEST_TIMEOUT = 8
_MAX_SHOW_CANDIDATES = 6


def _strip_accents(text):
    normalized = unicodedata.normalize("NFKD", text or "")
    return "".join(ch for ch in normalized if not unicodedata.combining(ch))


def _normalize_title(text):
    text = html.unescape(text or "")
    text = _strip_accents(text).lower()
    text = text.replace("&", " and ")
    text = re.sub(
        r"\b(?:s\d{1,2}e\d{1,2}|\d{1,2}x\d{1,2}|season\s+\d+|episode\s+\d+)\b",
        " ",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(r"\(\s*\d{4}\s*\)", " ", text)
    text = re.sub(r"[’'`]", "", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _strip_articles(text):
    return re.sub(r"^(the|a|an)\s+", "", text or "", flags=re.IGNORECASE).strip()


def _safe_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class TVSubtitlesClient(object):

    def __init__(self, addon):
        self.addon = addon
        self._opener = urllib.request.build_opener()
        self._opener.addheaders = [
            ("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi"),
            ("Accept-Language", "en-US,en;q=0.9"),
        ]

    def search(self, item):
        """
        Search for TV show subtitles.
        item keys: tvshow, season, episode, title, query, year, 3let_language
        Returns list of dicts: {filename, id, lang, rating, sync, lang_flag}
        """
        tvshow = item.get("tvshow", "") or item.get("title", "")
        season = int(item.get("season") or 0)
        episode = int(item.get("episode") or 0)

        if not tvshow:
            return []

        if not season or not episode:
            log(__name__, "TVS: skipping non-episode item '%s'" % tvshow)
            return []

        languages_3 = item.get("3let_language", [])
        wanted_tvs_codes = self._get_wanted_tvs_codes(languages_3)
        year = _safe_int(item.get("year"))

        # 1) Search for candidate shows using multiple title variants.
        show_candidates = self._search_show_candidates(item, wanted_tvs_codes, year)
        if not show_candidates:
            log(__name__, "TVS: show not found: %s" % tvshow)
            return []

        # 2) Pick the best candidate based on target episode availability and language flags.
        picked = self._pick_episode_candidate(
            show_candidates, season, episode, wanted_tvs_codes
        )
        if not picked:
            log(__name__, "TVS: episode %d not found in season %d for '%s'" % (
                episode, season, tvshow))
            return []

        episode_id = picked["episode_id"]
        ep_lang_flags = picked["lang_flags"]
        log(__name__, "TVS: selected show %s (id=%s, score=%.2f)" % (
            picked.get("name", ""), picked.get("id", ""), picked.get("score", 0.0)))

        if ep_lang_flags and wanted_tvs_codes and not (ep_lang_flags & wanted_tvs_codes):
            log(__name__, "TVS: episode %d has flags %s, none match wanted %s - skipping" % (
                episode, ep_lang_flags, wanted_tvs_codes))
            return []

        # 3) Get subtitles for the episode
        subtitles = self._get_episode_subtitles(episode_id)
        log(__name__, "TVS: found %d subtitles for ep %s" % (len(subtitles), episode_id))

        # 4) Filter by language
        if languages_3:
            filtered = []
            for sub in subtitles:
                lang_name = sub.get("lang", "")
                kodi_name = _TVS_LANG_TO_KODI.get(lang_name, lang_name)
                lang_3 = xbmc.convertLanguage(kodi_name, xbmc.ISO_639_2)
                if lang_3 in languages_3:
                    filtered.append(sub)
            if filtered:
                subtitles = filtered

        # Build results - Ukrainian subtitles sorted first, then by downloads
        subtitles.sort(key=lambda s: (s.get("lang") != "Ukrainian", -s.get("downloads", 0)))

        max_dl = max((s.get("downloads", 0) for s in subtitles), default=1) or 1
        results = []
        for sub in subtitles:
            lang_name = sub.get("lang", "")
            kodi_name = _TVS_LANG_TO_KODI.get(lang_name, lang_name)
            results.append({
                "filename": sub.get("release", lang_name),
                "id": str(sub.get("sub_id", "")),
                "lang": kodi_name,
                "rating": int(sub.get("downloads", 0) * 5 / max_dl),
                "sync": False,
                "lang_flag": xbmc.convertLanguage(kodi_name, xbmc.ISO_639_1),
            })

        return results

    def download(self, sub_id):
        """Download subtitle by ID. Returns local file path or None."""
        dest_dir = os.path.join(
            xbmcvfs.translatePath(self.addon.getAddonInfo("profile")), "temp"
        )
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, "tvs_download.zip")

        url = "%s/download-%s.html" % (SERVER_URL, sub_id)
        log(__name__, "TVS: downloading %s" % url)

        try:
            req = urllib.request.Request(url)
            req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi")
            req.add_header("Referer", "%s/subtitle-%s.html" % (SERVER_URL, sub_id))
            response = self._opener.open(req, timeout=REQUEST_TIMEOUT)
            data = response.read()
        except Exception as e:
            log(__name__, "TVS download error: %s" % e)
            return None

        if not data or len(data) < 100:
            log(__name__, "TVS: download returned too little data")
            return None

        with open(dest, "wb") as f:
            f.write(data)

        log(__name__, "TVS: saved to %s (%d bytes)" % (dest, len(data)))
        return dest

    # Private helpers

    def _fetch(self, url, data=None):
        """Fetch URL and return decoded text content."""
        try:
            if data:
                if isinstance(data, str):
                    data = data.encode("utf-8")
                req = urllib.request.Request(url, data)
            else:
                req = urllib.request.Request(url)
            req.add_header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi")
            response = self._opener.open(req, timeout=REQUEST_TIMEOUT)
            raw = response.read()
            for enc in ("utf-8", "latin-1", "windows-1252"):
                try:
                    return raw.decode(enc)
                except (UnicodeDecodeError, AttributeError):
                    continue
            return raw.decode("utf-8", errors="replace")
        except Exception as e:
            log(__name__, "TVS fetch error for %s: %s" % (url, e))
            return ""

    def _get_wanted_tvs_codes(self, languages_3):
        wanted = set()
        for lang3 in languages_3 or []:
            kodi_name = xbmc.convertLanguage(lang3, xbmc.ENGLISH_NAME)
            tvs_code = _LANG_TO_TVSCODE.get(kodi_name)
            if tvs_code:
                wanted.add(tvs_code)
        return wanted

    def _build_title_queries(self, item):
        seen = set()
        queries = []

        def _add(value):
            value = (value or "").strip()
            if not value:
                return
            variants = [value]
            cleaned = re.sub(r"\bS\d{1,2}E\d{1,2}\b", " ", value, flags=re.IGNORECASE)
            cleaned = re.sub(r"\b\d{1,2}x\d{1,2}\b", " ", cleaned, flags=re.IGNORECASE)
            cleaned = re.sub(r"\(\s*\d{4}\s*\)", " ", cleaned)
            cleaned = re.sub(r"\s+", " ", cleaned).strip(" -:_")
            if cleaned and cleaned != value:
                variants.append(cleaned)
            article_match = re.search(r"^(.*),\s*(The|A|An)$", cleaned, re.IGNORECASE)
            if article_match:
                variants.append("%s %s" % (article_match.group(2), article_match.group(1).strip()))
            if ":" in cleaned:
                left = cleaned.split(":", 1)[0].strip()
                if left:
                    variants.append(left)

            for variant in variants:
                key = variant.lower()
                if key not in seen:
                    seen.add(key)
                    queries.append(variant)

        _add(item.get("tvshow"))
        _add(item.get("title"))
        _add(item.get("query"))
        return queries

    def _score_show_candidate(self, query_name, show_name, year, show_flags, wanted_tvs_codes,
                              start_year, end_year):
        query_norm = _normalize_title(query_name)
        show_norm = _normalize_title(show_name)
        if not query_norm or not show_norm:
            return -1.0

        query_no_articles = _strip_articles(query_norm)
        show_no_articles = _strip_articles(show_norm)
        query_tokens = set(query_no_articles.split())
        show_tokens = set(show_no_articles.split())
        common_tokens = query_tokens & show_tokens

        score = 0.0
        if query_norm == show_norm:
            score += 100.0
        elif query_no_articles == show_no_articles:
            score += 92.0
        else:
            if common_tokens:
                score += 35.0 * len(common_tokens) / max(len(query_tokens), len(show_tokens))
                score += 12.0 * len(common_tokens)
            if query_no_articles in show_no_articles or show_no_articles in query_no_articles:
                score += 10.0 if common_tokens else -15.0

            ratio = SequenceMatcher(None, query_no_articles, show_no_articles).ratio()
            score += ratio * (18.0 if common_tokens else 6.0)

            if len(query_tokens) == 1 and not common_tokens:
                score -= 25.0

        if year and start_year:
            if end_year and start_year <= year <= end_year:
                score += 18.0
            elif abs(start_year - year) <= 1:
                score += 10.0
            else:
                compare_year = end_year if end_year and year > end_year else start_year
                score -= min(abs(compare_year - year), 10) * 3.0

        if wanted_tvs_codes and show_flags:
            if wanted_tvs_codes & show_flags:
                score += 6.0
            else:
                score -= 4.0

        return score

    def _search_show_candidates(self, item, wanted_tvs_codes, year):
        merged = {}

        for query_name in self._build_title_queries(item):
            content = self._fetch(
                SERVER_URL + "/search.php",
                urllib.parse.urlencode({"qs": query_name})
            )
            if not content:
                continue

            matches = re.finditer(
                r'<li[^>]*>.*?<a[^>]+href="[/]?tvshow-(\d+)(?:-\d+)?\.html"[^>]*>'
                r'([^<(]+?)\s*(?:\((\d{4})(?:-(\d{4}))?\))?</a>(.*?)</li>',
                content, re.IGNORECASE | re.DOTALL
            )

            found_any = False
            for match in matches:
                found_any = True
                show_id = int(match.group(1))
                show_name = match.group(2).strip()
                start_year = _safe_int(match.group(3))
                end_year = _safe_int(match.group(4)) or start_year
                flags_html = match.group(5)
                show_flags = set(
                    flag.group(1).lower()
                    for flag in re.finditer(r'flags/([a-z]{2})\.gif', flags_html, re.IGNORECASE)
                )
                score = self._score_show_candidate(
                    query_name, show_name, year, show_flags, wanted_tvs_codes, start_year, end_year
                )
                current = merged.get(show_id)
                if current is None or score > current["score"]:
                    merged[show_id] = {
                        "id": show_id,
                        "name": show_name,
                        "start_year": start_year,
                        "end_year": end_year,
                        "flags": show_flags,
                        "score": score,
                        "query": query_name,
                    }

            if not found_any:
                log(__name__, "TVS: no search results for '%s'" % query_name)

        results = sorted(merged.values(), key=lambda c: c["score"], reverse=True)
        if results:
            log(__name__, "TVS: candidate shows: %s" % [
                "%s#%s=%.2f" % (c["name"], c["id"], c["score"])
                for c in results[:_MAX_SHOW_CANDIDATES]
            ])
        return results[:_MAX_SHOW_CANDIDATES]

    def _pick_episode_candidate(self, show_candidates, season, episode, wanted_tvs_codes):
        best = None

        for candidate in show_candidates:
            episodes = self._get_season_episodes(candidate["id"], season)
            if not episodes:
                continue

            for ep in episodes:
                if ep.get("num") != episode:
                    continue

                score = float(candidate.get("score", 0.0))
                lang_flags = ep.get("lang_flags", set())
                if wanted_tvs_codes:
                    if lang_flags & wanted_tvs_codes:
                        score += 25.0
                    elif lang_flags:
                        score -= 8.0

                picked = {
                    "id": candidate["id"],
                    "name": candidate.get("name", ""),
                    "episode_id": ep.get("id"),
                    "lang_flags": lang_flags,
                    "score": score,
                }
                if best is None or score > best["score"]:
                    best = picked
                break

        return best

    def _get_season_episodes(self, show_id, season):
        """Get list of episodes for a show season.
        Returns list of {num, id, name, lang_flags} where lang_flags is a set of
        TVS language codes available for that episode (e.g. {'en', 'ua', 'ru'}).
        """
        url = "%s/tvshow-%d-%d.html" % (SERVER_URL, show_id, season)
        content = self._fetch(url)
        if not content:
            return []

        episodes = []
        for m in re.finditer(
            r'<td>\s*(\d+)x(\d+)\s*</td>\s*'
            r'<td[^>]*>\s*<a[^>]+href="[/]?episode-(\d+)\.html"[^>]*>'
            r'(?:<b>)?([^<]*)(?:</b>)?</a>\s*</td>\s*'
            r'<td[^>]*>[^<]*</td>\s*'
            r'<td[^>]*>(.*?)</td>',
            content, re.IGNORECASE | re.DOTALL
        ):
            ep_season = int(m.group(1))
            ep_num = int(m.group(2))
            ep_id = m.group(3)
            ep_name = m.group(4).strip()
            flags_html = m.group(5)

            lang_flags = set()
            for flag_m in re.finditer(r'flags/([^"]+)"', flags_html):
                code = os.path.splitext(flag_m.group(1))[0]
                lang_flags.add(code)

            if ep_season == season:
                episodes.append({
                    "num": ep_num,
                    "id": ep_id,
                    "name": ep_name,
                    "lang_flags": lang_flags,
                })

        log(__name__, "TVS: season %d has %d episodes" % (season, len(episodes)))
        return episodes

    def _get_episode_subtitles(self, episode_id):
        """Get all subtitles for an episode. Returns list of {sub_id, lang, release, downloads}."""
        url = "%s/episode-%s.html" % (SERVER_URL, episode_id)
        content = self._fetch(url)
        if not content:
            return []

        subtitles = []
        for m in re.finditer(
            r'<a[^>]+href="[/]?subtitle-(\d+)\.html"[^>]*>\s*<div[^>]*class="subtitle[^"]*"[^>]*>(.*?)</div>\s*</a>',
            content, re.IGNORECASE | re.DOTALL
        ):
            sub_id = m.group(1)
            block = m.group(2)

            lang = ""
            flag_match = re.search(r'<img[^>]+src="[^"]*flags/([^"]+)"', block, re.IGNORECASE)
            if flag_match:
                lang_code = os.path.splitext(flag_match.group(1))[0]
                lang = _TVSCODE_TO_LANG.get(lang_code, lang_code)

            release = ""
            h5_match = re.search(r'<h5[^>]*>(.*?)</h5>', block, re.IGNORECASE | re.DOTALL)
            if h5_match:
                release = re.sub(r'<[^>]+>', '', h5_match.group(1)).strip()

            downloads = 0
            dl_match = re.search(
                r'title="downloaded"[^>]*>.*?(\d[\d,]*)\s*</p>',
                block, re.IGNORECASE | re.DOTALL
            )
            if dl_match:
                downloads = int(dl_match.group(1).replace(",", ""))

            subtitles.append({
                "sub_id": sub_id,
                "lang": lang,
                "release": release or ("Subtitle %s" % sub_id),
                "downloads": downloads,
            })

        seen = set()
        unique = []
        for subtitle in subtitles:
            if subtitle["sub_id"] not in seen:
                seen.add(subtitle["sub_id"])
                unique.append(subtitle)

        return unique
