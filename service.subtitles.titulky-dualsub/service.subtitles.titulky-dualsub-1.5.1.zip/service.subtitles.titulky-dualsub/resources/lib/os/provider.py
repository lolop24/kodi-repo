# -*- coding: utf-8 -*-
"""
OpenSubtitles.com REST API provider.
Adapted from peno64/service.subtitles.opensubtitles-com-dualsub (GPL-2.0).
"""
import json
from typing import Union

from requests import Session, ConnectionError, HTTPError, ReadTimeout, Timeout, RequestException

from resources.lib.os.model.request.subtitles import OpenSubtitlesSubtitlesRequest
from resources.lib.os.model.request.download import OpenSubtitlesDownloadRequest
from resources.lib.exceptions import (
    AuthenticationError, ConfigurationError, DownloadLimitExceeded,
    ProviderError, ServiceUnavailable, TooManyRequests, BadUsernameError
)
from resources.lib.cache import Cache
from resources.lib.utilities import log

API_URL = "https://api.opensubtitles.com/api/v1/"
API_LOGIN = "login"
API_SUBTITLES = "subtitles"
API_DOWNLOAD = "download"
CONTENT_TYPE = "application/json"
LOGIN_TIMEOUT = 10
SEARCH_TIMEOUT = 8
DOWNLOAD_TIMEOUT = 30
SEARCH_CACHE_TTL = 60 * 10

CLASS_LOOKUP = {
    "OpenSubtitlesSubtitlesRequest": OpenSubtitlesSubtitlesRequest,
    "OpenSubtitlesDownloadRequest": OpenSubtitlesDownloadRequest,
}


def _logging(msg):
    log(__name__, msg)


def _query_to_params(query, _type):
    if isinstance(query, dict):
        try:
            request = CLASS_LOOKUP[_type](**query)
        except ValueError as e:
            raise ValueError("Invalid request data: %s" % e)
    elif isinstance(query, CLASS_LOOKUP.get(_type, type(None))):
        request = query
    else:
        raise ValueError("Invalid request type")
    return request.request_params()


class OpenSubtitlesProvider:

    def __init__(self, api_key, username, password):
        if not api_key:
            raise ConfigurationError("API key must be specified")

        self.api_key = api_key
        self.username = username
        self.password = password

        self.request_headers = {
            "Api-Key": self.api_key,
            "User-Agent": "TitulkyDualSub Kodi plugin v1.0.0",
            "Content-Type": CONTENT_TYPE,
            "Accept": CONTENT_TYPE,
        }
        self.session = Session()
        self.session.headers = self.request_headers
        self.cache = Cache(key_prefix="tds_os")

    def login(self):
        login_url = API_URL + API_LOGIN
        login_body = {"username": self.username, "password": self.password}
        _logging("Login to OpenSubtitles.com")
        try:
            r = self.session.post(login_url, json=login_body, allow_redirects=False,
                                  timeout=LOGIN_TIMEOUT)
            r.raise_for_status()
        except (ConnectionError, Timeout, ReadTimeout) as e:
            raise ServiceUnavailable("Connection error: %s" % e)
        except HTTPError as e:
            status_code = e.response.status_code
            if status_code == 401:
                raise AuthenticationError("Login failed: %s" % e)
            elif status_code == 400:
                raise BadUsernameError("Bad username (use username, not email): %s" % e)
            elif status_code == 429:
                raise TooManyRequests()
            else:
                raise ProviderError("Login error %d" % status_code)
        try:
            self.user_token = r.json()["token"]
        except (ValueError, KeyError) as e:
            raise ProviderError("Invalid login response: %s" % e)

    @property
    def user_token(self):
        return self.cache.get(key="user_token")

    @user_token.setter
    def user_token(self, value):
        self.cache.set(key="user_token", value=value)

    def search_subtitles(self, query):
        params = _query_to_params(query, "OpenSubtitlesSubtitlesRequest")
        if not params:
            raise ValueError("Empty search params")

        cache_key = "search:%s" % json.dumps(
            params, ensure_ascii=True, sort_keys=True, separators=(",", ":")
        )
        cached = self.cache.get(key=cache_key)
        if cached is not None:
            _logging("OS search cache hit")
            return cached or None

        subtitles_url = API_URL + API_SUBTITLES
        _logging("OS search: %s" % params)
        try:
            r = self.session.get(subtitles_url, params=params, timeout=SEARCH_TIMEOUT)
            r.raise_for_status()
        except (ConnectionError, Timeout, ReadTimeout) as e:
            raise ServiceUnavailable("Connection error: %s" % e)
        except HTTPError as e:
            status_code = e.response.status_code
            if status_code == 429:
                raise TooManyRequests()
            elif status_code == 503:
                raise ServiceUnavailable("Service unavailable")
            else:
                raise ProviderError("Search error %d" % status_code)
        try:
            result = r.json()
            if "data" not in result:
                raise ValueError("No data in response")
        except ValueError as e:
            raise ProviderError("Invalid JSON: %s" % e)

        _logging("OS found %d subtitles" % len(result["data"]))
        data = result["data"] if result["data"] else []
        self.cache.set(key=cache_key, value=data, expires=SEARCH_CACHE_TTL)
        return data or None

    def download_subtitle(self, query):
        # Auto-login if needed
        if self.user_token is None and self.username and self.password:
            try:
                self.login()
            except (AuthenticationError, BadUsernameError):
                raise
            except Exception as e:
                raise ProviderError("Cannot obtain auth token: %s" % e)

        params = _query_to_params(query, "OpenSubtitlesDownloadRequest")
        _logging("OS download file_id: %s" % params.get("file_id"))

        download_url = API_URL + API_DOWNLOAD
        download_headers = {}
        if self.user_token:
            download_headers = {"Authorization": "Bearer " + self.user_token}

        download_params = {
            "file_id": params["file_id"],
            "sub_format": params.get("sub_format", "srt")
        }
        try:
            r = self.session.post(download_url, headers=download_headers,
                                  json=download_params, timeout=DOWNLOAD_TIMEOUT)
            r.raise_for_status()
        except (ConnectionError, Timeout, ReadTimeout) as e:
            raise ServiceUnavailable("Connection error: %s" % e)
        except HTTPError as e:
            status_code = e.response.status_code
            if status_code == 401:
                raise AuthenticationError("Auth failed")
            elif status_code == 406:
                raise DownloadLimitExceeded("Daily download limit reached")
            elif status_code == 429:
                raise TooManyRequests()
            else:
                raise ProviderError("Download error %d" % status_code)

        try:
            subtitle = r.json()
            download_link = subtitle["link"]
        except (ValueError, KeyError) as e:
            raise ProviderError("Invalid download response: %s" % e)

        res = self.session.get(download_link, timeout=DOWNLOAD_TIMEOUT)
        subtitle["content"] = res.content
        return subtitle
