# -*- coding: utf-8 -*-
import sys
import os
import unicodedata

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from struct import Struct
from io import BytesIO
import gzip

__addon__ = xbmcaddon.Addon()
__language__ = __addon__.getLocalizedString


# ── Logging ──────────────────────────────────────────────────────────────────

def log(module, msg):
    xbmc.log(u"### [%s] - %s" % (str(module), str(msg)), level=xbmc.LOGDEBUG)


def error(module, msg_id, exception=None):
    log(module, "Error %s: %s" % (msg_id, exception))
    try:
        msg = __language__(msg_id)
    except Exception:
        msg = str(msg_id)
    xbmcgui.Dialog().ok(__addon__.getAddonInfo("name"), msg)


# ── URL params ────────────────────────────────────────────────────────────────

def get_params(string=None):
    try:
        from urllib.parse import parse_qs, unquote_plus
        param_string = string if string else sys.argv[2]
        params_raw = parse_qs(param_string.lstrip("?"))
        params = {}
        for key, value in params_raw.items():
            params[key] = unquote_plus(value[0]) if value else ""
        return params
    except Exception:
        return {}


# ── String utils ──────────────────────────────────────────────────────────────

def normalize_string(str_input):
    return unicodedata.normalize("NFKD", str_input)


def is_remote_media_path(path):
    value = (path or "").strip().lower()
    if not value:
        return False

    local_prefixes = ("file://", "rar://", "zip://", "stack://", "special://")
    remote_prefixes = (
        "http://",
        "https://",
        "smb://",
        "nfs://",
        "ftp://",
        "ftps://",
        "dav://",
        "davs://",
        "upnp://",
        "plugin://",
    )

    if value.startswith(local_prefixes):
        return False
    if value.startswith(remote_prefixes):
        return True
    return "://" in value


# ── File size helpers (for titulky.com RAR support) ──────────────────────────

def get_file_size(filename, is_rar):
    try:
        if is_rar:
            file_size = _get_file_size_from_rar(filename)
            return -1 if file_size is None else file_size
        else:
            return xbmcvfs.Stat(filename).st_size()
    except Exception:
        return -1


def _get_file_size_from_rar(first_rar_filename):
    RAR_BLOCK_MAIN = 0x73
    RAR_BLOCK_FILE = 0x74
    RAR_FILE_LARGE = 0x0100

    S_BLK_HDR = Struct('<HBHH')
    S_FILE_HDR = Struct('<LLBLLBBHL')
    S_LONG = Struct('<L')

    try:
        fd = xbmcvfs.File(first_rar_filename)
        if fd.read(7) != b"Rar!\x1a\x07\x00":
            return None
        while True:
            buf = fd.read(S_BLK_HDR.size)
            if not buf:
                return None
            t = S_BLK_HDR.unpack_from(buf)
            header_crc, header_type, header_flags, header_size = t
            header_data = buf + fd.read(header_size - S_BLK_HDR.size) if header_size > S_BLK_HDR.size else buf
            if len(header_data) != header_size:
                return None
            if header_type == RAR_BLOCK_MAIN:
                continue
            elif header_type == RAR_BLOCK_FILE:
                file_size = S_FILE_HDR.unpack_from(header_data, S_BLK_HDR.size)[1]
                if header_flags & RAR_FILE_LARGE:
                    file_size |= S_LONG.unpack_from(header_data, S_BLK_HDR.size + S_FILE_HDR.size + 4)[0] << 32
                return file_size
            else:
                return None
    except Exception:
        return None


# ── HTTP response helper (for titulky.com) ────────────────────────────────────

def get_content_from_response(response):
    content = response.read()
    response.close()
    if response.getheader('Content-Encoding') == 'gzip':
        buf = BytesIO(content)
        f = gzip.GzipFile(fileobj=buf)
        content = f.read()
    content_type = response.getheader('Content-Type') or ''
    if content_type.startswith("text/"):
        content = content.decode("utf-8")
    return content
