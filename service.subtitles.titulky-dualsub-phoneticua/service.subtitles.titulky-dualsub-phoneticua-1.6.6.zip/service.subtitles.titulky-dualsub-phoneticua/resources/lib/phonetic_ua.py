# -*- coding: utf-8 -*-
import os
import re


SUPPORTED_EXTENSIONS = {".srt", ".vtt", ".ass", ".ssa", ".txt", ".sub"}
READ_ENCODINGS = (
    "utf-8-sig",
    "utf-16",
    "windows-1250",
    "iso-8859-2",
    "windows-1251",
    "iso-8859-5",
    "utf-8",
    "latin-1",
)

WORD_RE = re.compile(
    r"(?iu)[a-z"
    r"\u00e1\u00e4\u010d\u010f\u00e9\u011b\u00ed\u013a\u013e\u0148\u00f3\u00f4"
    r"\u0159\u0161\u0165\u00fa\u016f\u00fd\u017e]+"
)
PROTECTED_RE = re.compile(r"(\{[^}]*\}|<[^>]+>|\\[Nnh]|&[A-Za-z0-9#]+;)")
MICRODVD_RE = re.compile(r"^(\{[^}]*\}\{[^}]*\})(.*)$")

CS_MARKERS = ("\u011b", "\u0159", "\u016f", "ou")
SK_MARKERS = ("\u00e4", "\u013a", "\u013e", "\u0155", "\u00f4", "d\u017e", "dz", "ia", "ie", "iu")

_APOSTROPHE_LATIN = "bpvmfghkrzc\u010d\u0161\u017e"

CS_MULTI_REPLACEMENTS = (
    ("d\u017e", "\u0434\u0436"),
    ("dz", "\u0434\u0437"),
    ("ch", "\u0445"),
    ("b\u011b", "\u0431'\u0454"),
    ("p\u011b", "\u043f'\u0454"),
    ("v\u011b", "\u0432'\u0454"),
    ("f\u011b", "\u0444'\u0454"),
    ("m\u011b", "\u043c\u043d\u0454"),
    ("d\u011b", "\u0434\u0454"),
    ("t\u011b", "\u0442\u0454"),
    ("n\u011b", "\u043d\u0454"),
    ("j\u00e1", "\u044f"),
    ("ja", "\u044f"),
    ("j\u00e9", "\u0454"),
    ("je", "\u0454"),
    ("j\u00ed", "\u0457"),
    ("ji", "\u0457"),
    ("j\u00f3", "\u0439\u043e"),
    ("jo", "\u0439\u043e"),
    ("j\u00fa", "\u044e"),
    ("ju", "\u044e"),
    ("ou", "\u043e\u0443"),
    ("au", "\u0430\u0443"),
    ("eu", "\u0435\u0443"),
)

SK_MULTI_REPLACEMENTS = (
    ("d\u017e", "\u0434\u0436"),
    ("dz", "\u0434\u0437"),
    ("ch", "\u0445"),
    ("\u010fa", "\u0434\u044f"),
    ("\u010f\u00e1", "\u0434\u044f"),
    ("\u010fe", "\u0434\u0454"),
    ("\u010f\u00e9", "\u0434\u0454"),
    ("\u010fi", "\u0434\u0456"),
    ("\u010f\u00ed", "\u0434\u0456"),
    ("\u0165a", "\u0442\u044f"),
    ("\u0165\u00e1", "\u0442\u044f"),
    ("\u0165e", "\u0442\u0454"),
    ("\u0165\u00e9", "\u0442\u0454"),
    ("\u0165i", "\u0442\u0456"),
    ("\u0165\u00ed", "\u0442\u0456"),
    ("\u0148a", "\u043d\u044f"),
    ("\u0148\u00e1", "\u043d\u044f"),
    ("\u0148e", "\u043d\u0454"),
    ("\u0148\u00e9", "\u043d\u0454"),
    ("\u0148i", "\u043d\u0456"),
    ("\u0148\u00ed", "\u043d\u0456"),
    ("\u013ea", "\u043b\u044f"),
    ("\u013e\u00e1", "\u043b\u044f"),
    ("\u013ee", "\u043b\u0454"),
    ("\u013e\u00e9", "\u043b\u0454"),
    ("\u013ei", "\u043b\u0456"),
    ("\u013e\u00ed", "\u043b\u0456"),
    ("dia", "\u0434\u044f"),
    ("die", "\u0434\u0454"),
    ("diu", "\u0434\u044e"),
    ("tia", "\u0442\u044f"),
    ("tie", "\u0442\u0454"),
    ("tiu", "\u0442\u044e"),
    ("nia", "\u043d\u044f"),
    ("nie", "\u043d\u0454"),
    ("niu", "\u043d\u044e"),
    ("lia", "\u043b\u044f"),
    ("lie", "\u043b\u0454"),
    ("liu", "\u043b\u044e"),
    ("j\u00e1", "\u044f"),
    ("ja", "\u044f"),
    ("j\u00e9", "\u0454"),
    ("je", "\u0454"),
    ("j\u00ed", "\u0457"),
    ("ji", "\u0457"),
    ("j\u00f3", "\u0439\u043e"),
    ("jo", "\u0439\u043e"),
    ("j\u00fa", "\u044e"),
    ("ju", "\u044e"),
    ("\u00f4", "\u0443\u043e"),
    ("au", "\u0430\u0443"),
    ("eu", "\u0435\u0443"),
)

SK_SIMPLE_MULTI_REPLACEMENTS = (
    ("d\u017e", "\u0434\u0436"),
    ("dz", "\u0434\u0437"),
    ("ch", "\u0445"),
    ("\u010fa", "\u0434\u044f"),
    ("\u010f\u00e1", "\u0434\u044f"),
    ("\u010fe", "\u0434\u0454"),
    ("\u010f\u00e9", "\u0434\u0454"),
    ("\u010fi", "\u0434\u0456"),
    ("\u010f\u00ed", "\u0434\u0456"),
    ("\u010fu", "\u0434\u044e"),
    ("\u010f\u00fa", "\u0434\u044e"),
    ("\u0165a", "\u0442\u044f"),
    ("\u0165\u00e1", "\u0442\u044f"),
    ("\u0165e", "\u0442\u0454"),
    ("\u0165\u00e9", "\u0442\u0454"),
    ("\u0165i", "\u0442\u0456"),
    ("\u0165\u00ed", "\u0442\u0456"),
    ("\u0165u", "\u0442\u044e"),
    ("\u0165\u00fa", "\u0442\u044e"),
    ("\u0148a", "\u043d\u044f"),
    ("\u0148\u00e1", "\u043d\u044f"),
    ("\u0148e", "\u043d\u0454"),
    ("\u0148\u00e9", "\u043d\u0454"),
    ("\u0148i", "\u043d\u0456"),
    ("\u0148\u00ed", "\u043d\u0456"),
    ("\u0148u", "\u043d\u044e"),
    ("\u0148\u00fa", "\u043d\u044e"),
    ("\u013ea", "\u043b\u044f"),
    ("\u013e\u00e1", "\u043b\u044f"),
    ("\u013ee", "\u043b\u0454"),
    ("\u013e\u00e9", "\u043b\u0454"),
    ("\u013ei", "\u043b\u0456"),
    ("\u013e\u00ed", "\u043b\u0456"),
    ("\u013eu", "\u043b\u044e"),
    ("\u013e\u00fa", "\u043b\u044e"),
    ("dia", "\u0434\u044f"),
    ("die", "\u0434\u0454"),
    ("diu", "\u0434\u044e"),
    ("tia", "\u0442\u044f"),
    ("tie", "\u0442\u0454"),
    ("tiu", "\u0442\u044e"),
    ("nia", "\u043d\u044f"),
    ("nie", "\u043d\u0454"),
    ("niu", "\u043d\u044e"),
    ("lia", "\u043b\u044f"),
    ("lie", "\u043b\u0454"),
    ("liu", "\u043b\u044e"),
    ("ria", "\u0440\u044f"),
    ("rie", "\u0440\u0454"),
    ("riu", "\u0440\u044e"),
    ("sia", "\u0441\u044f"),
    ("sie", "\u0441\u0454"),
    ("siu", "\u0441\u044e"),
    ("zia", "\u0437\u044f"),
    ("zie", "\u0437\u0454"),
    ("ziu", "\u0437\u044e"),
    ("cia", "\u0446\u044f"),
    ("cie", "\u0446\u0454"),
    ("ciu", "\u0446\u044e"),
    ("\u010dia", "\u0447\u044f"),
    ("\u010die", "\u0447\u0454"),
    ("\u010diu", "\u0447\u044e"),
    ("\u0161ia", "\u0448\u044f"),
    ("\u0161ie", "\u0448\u0454"),
    ("\u0161iu", "\u0448\u044e"),
    ("\u017eia", "\u0436\u044f"),
    ("\u017eie", "\u0436\u0454"),
    ("\u017eiu", "\u0436\u044e"),
    ("j\u00e1", "\u044f"),
    ("ja", "\u044f"),
    ("j\u00e9", "\u0454"),
    ("je", "\u0454"),
    ("j\u00ed", "\u0457"),
    ("ji", "\u0457"),
    ("j\u00f3", "\u0439\u043e"),
    ("jo", "\u0439\u043e"),
    ("j\u00fa", "\u044e"),
    ("ju", "\u044e"),
    ("\u00f4", "\u043e"),
    ("au", "\u0430\u0443"),
    ("eu", "\u0435\u0443"),
)

CS_CHAR_MAP = {
    "a": "\u0430",
    "\u00e1": "\u0430",
    "b": "\u0431",
    "c": "\u0446",
    "\u010d": "\u0447",
    "d": "\u0434",
    "\u010f": "\u0434\u044c",
    "e": "\u0435",
    "\u00e9": "\u0435",
    "\u011b": "\u0454",
    "f": "\u0444",
    "g": "\u0491",
    "h": "\u0433",
    "i": "\u0456",
    "\u00ed": "\u0456",
    "j": "\u0439",
    "k": "\u043a",
    "l": "\u043b",
    "m": "\u043c",
    "n": "\u043d",
    "\u0148": "\u043d\u044c",
    "o": "\u043e",
    "\u00f3": "\u043e",
    "p": "\u043f",
    "q": "\u043a\u0432",
    "r": "\u0440",
    "\u0159": "\u0440\u0436",
    "s": "\u0441",
    "\u0161": "\u0448",
    "t": "\u0442",
    "\u0165": "\u0442\u044c",
    "u": "\u0443",
    "\u00fa": "\u0443",
    "\u016f": "\u0443",
    "v": "\u0432",
    "w": "\u0432",
    "x": "\u043a\u0441",
    "y": "\u0438",
    "\u00fd": "\u0438",
    "z": "\u0437",
    "\u017e": "\u0436",
}

SK_CHAR_MAP = {
    "a": "\u0430",
    "\u00e1": "\u0430",
    "\u00e4": "\u0435",
    "b": "\u0431",
    "c": "\u0446",
    "\u010d": "\u0447",
    "d": "\u0434",
    "\u010f": "\u0434\u044c",
    "e": "\u0435",
    "\u00e9": "\u0435",
    "f": "\u0444",
    "g": "\u0491",
    "h": "\u0433",
    "i": "\u0456",
    "\u00ed": "\u0456",
    "j": "\u0439",
    "k": "\u043a",
    "l": "\u043b",
    "\u013a": "\u043b",
    "\u013e": "\u043b\u044c",
    "m": "\u043c",
    "n": "\u043d",
    "\u0148": "\u043d\u044c",
    "o": "\u043e",
    "\u00f3": "\u043e",
    "p": "\u043f",
    "q": "\u043a\u0432",
    "r": "\u0440",
    "\u0155": "\u0440",
    "s": "\u0441",
    "\u0161": "\u0448",
    "t": "\u0442",
    "\u0165": "\u0442\u044c",
    "u": "\u0443",
    "\u00fa": "\u0443",
    "v": "\u0432",
    "w": "\u0432",
    "x": "\u043a\u0441",
    "y": "\u0438",
    "\u00fd": "\u0438",
    "z": "\u0437",
    "\u017e": "\u0436",
}

SK_SIMPLE_CHAR_MAP = {
    "a": "\u0430",
    "\u00e1": "\u0430",
    "\u00e4": "\u0435",
    "b": "\u0431",
    "c": "\u0446",
    "\u010d": "\u0447",
    "d": "\u0434",
    "\u010f": "\u0434\u044c",
    "e": "\u0435",
    "\u00e9": "\u0435",
    "f": "\u0444",
    "g": "\u0491",
    "h": "\u0433",
    "i": "\u0456",
    "\u00ed": "\u0456",
    "j": "\u0439",
    "k": "\u043a",
    "l": "\u043b",
    "\u013a": "\u043b",
    "\u013e": "\u043b\u044c",
    "m": "\u043c",
    "n": "\u043d",
    "\u0148": "\u043d\u044c",
    "o": "\u043e",
    "\u00f3": "\u043e",
    "p": "\u043f",
    "q": "\u043a\u0432",
    "r": "\u0440",
    "\u0155": "\u0440",
    "s": "\u0441",
    "\u0161": "\u0448",
    "t": "\u0442",
    "\u0165": "\u0442\u044c",
    "u": "\u0443",
    "\u00fa": "\u0443",
    "v": "\u0432",
    "w": "\u0432",
    "x": "\u043a\u0441",
    "y": "\u0438",
    "\u00fd": "\u0438",
    "z": "\u0437",
    "\u017e": "\u0436",
}


def detect_language(text):
    sample = (text or "").lower()
    cs_score = sum(sample.count(marker) for marker in CS_MARKERS)
    sk_score = sum(sample.count(marker) for marker in SK_MARKERS)
    if sk_score > cs_score:
        return "sk"
    return "cs"


def _resolve_language(source_language, text=None):
    if source_language in ("cs", "sk"):
        return source_language
    return detect_language(text or "")


def _replace_iotated_diphthongs(word):
    for source, target in (("ia", "\u044f"), ("ie", "\u0454"), ("iu", "\u044e")):
        word = re.sub(
            r"([" + _APOSTROPHE_LATIN + r"])" + source,
            r"\1'" + target,
            word,
        )
        word = word.replace(source, target)
    return word


def _apply_multi_replacements(word, replacements):
    result = word
    for source, target in replacements:
        result = result.replace(source, target)
    return result


def _apply_char_map(word, mapping):
    return "".join(mapping.get(char, char) for char in word)


def _apply_czech_rules(word):
    result = _apply_multi_replacements(word, CS_MULTI_REPLACEMENTS)
    return _apply_char_map(result, CS_CHAR_MAP)


def _apply_slovak_rules(word):
    result = _replace_iotated_diphthongs(word)
    result = _apply_multi_replacements(result, SK_MULTI_REPLACEMENTS)
    return _apply_char_map(result, SK_CHAR_MAP)


def _apply_slovak_rules_simple(word):
    result = _apply_multi_replacements(word, SK_SIMPLE_MULTI_REPLACEMENTS)
    return _apply_char_map(result, SK_SIMPLE_CHAR_MAP)


def transliterate_word_czech(word):
    if not word:
        return word
    return _match_case(word, _apply_czech_rules(word.lower()))


def transliterate_word_slovak(word, style="simple"):
    if not word:
        return word
    lower = word.lower()
    if style == "precise":
        converted = _apply_slovak_rules(lower)
    else:
        converted = _apply_slovak_rules_simple(lower)
    return _match_case(word, converted)


def _match_case(source, target):
    if not target:
        return target
    if source.isupper():
        return target.upper()
    if len(source) > 1 and source[0].isupper() and source[1:].islower():
        return target[0].upper() + target[1:]
    return target


def transliterate_word(word, source_language="auto"):
    if not word:
        return word

    lang = _resolve_language(source_language, word)
    if lang == "sk":
        return transliterate_word_slovak(word)
    return transliterate_word_czech(word)


def transliterate_text(text, source_language="auto"):
    resolved_language = _resolve_language(source_language, text)
    parts = PROTECTED_RE.split(text)
    output = []
    for part in parts:
        if not part:
            continue
        if PROTECTED_RE.fullmatch(part):
            output.append(part)
        else:
            output.append(
                WORD_RE.sub(
                    lambda match: transliterate_word(match.group(0), resolved_language),
                    part,
                )
            )
    return "".join(output)


def transliterate_text_with_profile(text, source_language="auto", slovak_style="simple"):
    resolved_language = _resolve_language(source_language, text)
    parts = PROTECTED_RE.split(text)
    output = []
    for part in parts:
        if not part:
            continue
        if PROTECTED_RE.fullmatch(part):
            output.append(part)
        else:
            if resolved_language == "sk":
                output.append(
                    WORD_RE.sub(
                        lambda match: transliterate_word_slovak(match.group(0), slovak_style),
                        part,
                    )
                )
            else:
                output.append(
                    WORD_RE.sub(
                        lambda match: transliterate_word_czech(match.group(0)),
                        part,
                    )
                )
    return "".join(output)


def _read_text_file(path):
    with open(path, "rb") as handle:
        raw = handle.read()

    for encoding in READ_ENCODINGS:
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _guess_language_from_name(path):
    lowered = " %s " % os.path.basename(path).lower()
    if any(marker in lowered for marker in ("czech", ".cs.", "_cs_", "-cs-", " ces ", " cze ")):
        return "cs"
    if any(marker in lowered for marker in ("slovak", ".sk.", "_sk_", "-sk-", " slk ", " slo ")):
        return "sk"
    return None


def _is_srt_counter_line(line):
    return bool(re.fullmatch(r"\d+", line.strip()))


def _is_timestamp_line(line):
    return "-->" in line


def _transliterate_ass(content, source_language, slovak_style="simple"):
    output = []
    for line in content.splitlines(True):
        if not line.startswith("Dialogue:"):
            output.append(line)
            continue

        prefix, payload = line.split(":", 1)
        parts = payload.split(",", 9)
        if len(parts) < 10:
            output.append(line)
            continue

        parts[9] = transliterate_text_with_profile(parts[9], source_language, slovak_style)
        output.append("%s:%s" % (prefix, ",".join(parts)))
    return "".join(output)


def _transliterate_microdvd_line(line, source_language, slovak_style="simple"):
    match = MICRODVD_RE.match(line.rstrip("\r\n"))
    if not match:
        return transliterate_text_with_profile(line, source_language, slovak_style)
    newline = "\n" if line.endswith("\n") else ""
    return "%s%s%s" % (
        match.group(1),
        transliterate_text_with_profile(match.group(2), source_language, slovak_style),
        newline,
    )


def _transliterate_line_based(content, extension, source_language, slovak_style="simple"):
    output = []
    passthrough_block = False

    for line in content.splitlines(True):
        stripped = line.strip()

        if passthrough_block:
            output.append(line)
            if not stripped:
                passthrough_block = False
            continue

        if stripped.startswith(("WEBVTT", "STYLE", "REGION", "NOTE")):
            output.append(line)
            if stripped in ("STYLE", "REGION") or stripped.startswith("NOTE"):
                passthrough_block = True
            continue

        if not stripped or _is_srt_counter_line(line) or _is_timestamp_line(line):
            output.append(line)
            continue

        if extension == ".sub":
            output.append(_transliterate_microdvd_line(line, source_language, slovak_style))
        else:
            output.append(transliterate_text_with_profile(line, source_language, slovak_style))

    return "".join(output)


def generate_phonetic_subtitle(source_path, output_dir, source_language="auto", slovak_style="simple"):
    extension = os.path.splitext(source_path)[1].lower()
    if extension not in SUPPORTED_EXTENSIONS:
        raise ValueError("Unsupported subtitle format: %s" % extension)

    content = _read_text_file(source_path)
    detected_language = source_language
    if detected_language not in ("cs", "sk"):
        detected_language = _guess_language_from_name(source_path) or detect_language(content)

    if extension in (".ass", ".ssa"):
        transformed = _transliterate_ass(content, detected_language, slovak_style)
    else:
        transformed = _transliterate_line_based(content, extension, detected_language, slovak_style)

    os.makedirs(output_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(source_path))[0]
    target = os.path.join(output_dir, "%s.ukrphon%s" % (base, extension))
    with open(target, "w", encoding="utf-8-sig", newline="") as handle:
        handle.write(transformed)
    return target
