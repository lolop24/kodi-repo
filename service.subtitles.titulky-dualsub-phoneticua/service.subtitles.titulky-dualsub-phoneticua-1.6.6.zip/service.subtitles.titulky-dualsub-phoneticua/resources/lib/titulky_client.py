# -*- coding: utf-8 -*-
"""
HTTP client for Titulky.com subtitle service.
Adapted from beam-kodi-addons-repository/service.subtitles.titulky.com (GPL).
"""
import urllib.parse
import urllib.request
import http.cookiejar as cookielib
import re
import os
import html
import time
import calendar
import json

import xbmc
import xbmcvfs
import xbmcgui

from resources.lib.utilities import (
    get_content_from_response,
    get_file_size,
    is_remote_media_path,
    log,
)
from resources.lib.captcha import ask_for_captcha


class TitulkyClient(object):

    SERVER_URL = 'https://www.titulky.com'

    def __init__(self, addon, request_timeout=8):
        self.addon = addon
        self._t = addon.getLocalizedString
        self.cookies = {}
        self.request_timeout = self._normalize_timeout(request_timeout)

        opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(cookielib.LWPCookieJar())
        )
        opener.addheaders = []
        urllib.request.install_opener(opener)

    # ── Public API ────────────────────────────────────────────────────────────

    def login(self, username, password):
        log(__name__, 'Logging in to Titulky.com as %s' % username)
        if not username:
            return False
        login_postdata = urllib.parse.urlencode({
            'Login': username,
            'Password': password,
            'foreverlog': '0',
            'Detail2': ''
        }).encode('utf-8')
        request = urllib.request.Request(self.SERVER_URL + '/index.php', login_postdata)
        request.add_header('Origin', self.SERVER_URL)

        try:
            response = urllib.request.urlopen(request, timeout=self.request_timeout)
            content = get_content_from_response(response)
        except Exception as e:
            log(__name__, 'Login request failed: %s' % e)
            return False

        if content.find('BadLogin') > -1:
            log(__name__, 'Login failed: BadLogin')
            return False

        log(__name__, 'Storing cookies')
        self.cookies = {}
        try:
            set_cookie = response.getheader('Set-Cookie') or ''
            crc = re.search(r'CRC=(\S+?);', set_cookie, re.IGNORECASE)
            logon_login = re.search(r'LogonLogin=(\S+?);', set_cookie, re.IGNORECASE)
            logon_id = re.search(r'LogonId=(\S+?);', set_cookie, re.IGNORECASE)
            if crc:
                self.cookies['CRC'] = crc.group(1)
            if logon_login:
                self.cookies['LogonLogin'] = logon_login.group(1)
            if logon_id:
                self.cookies['LogonId'] = logon_id.group(1)
        except Exception as e:
            log(__name__, 'Cookie parsing error: %s' % e)

        return True

    def search(self, item):
        """Search for subtitles. item dict keys: mansearch, mansearchstr, tvshow,
        season, episode, title, year, 3let_language, file_original_path, rar"""
        if item.get('mansearch'):
            title = item.get('mansearchstr', '')
        elif item.get('tvshow'):
            title = "%s S%02dE%02d" % (
                self._normalize_title(item['tvshow']),
                int(item.get('season') or 0),
                int(item.get('episode') or 0)
            )
        else:
            raw_title = item.get('title', '') or ''
            if item.get('year'):
                title = self._normalize_title(raw_title)
            else:
                title = xbmc.getCleanMovieTitle(raw_title)[0]
                title = self._normalize_title(title)

        log(__name__, 'TK search pattern: %s' % title)

        found = self._search_subtitle(title)
        if not found:
            return []

        filtered = self._filter_by_language(item.get('3let_language', []), found)
        if not filtered:
            return []

        file_path = item.get('file_original_path', '')
        skip_remote_size = (
            self.addon.getSetting('fast_search_mode') == 'true' and
            self.addon.getSetting('skip_remote_hash') == 'true' and
            is_remote_media_path(file_path)
        )

        file_size = -1
        if not skip_remote_size:
            file_size = get_file_size(file_path, item.get('rar', False))
        if file_size != -1:
            file_size = round(float(file_size) / (1024 * 1024), 2)
        elif skip_remote_size:
            log(__name__, 'Skipping remote file size sync check for faster search')

        max_count = max((s.get('down_count', 0) for s in filtered), default=1)
        if max_count == 0:
            max_count = 1

        results = []
        for sub in filtered:
            display_name = sub.get('version') or sub.get('title') or ''
            if sub.get('author'):
                display_name += " by " + sub['author']
            results.append({
                'filename': html.unescape(display_name),
                'link_file': sub.get('link_file', ''),
                'id': sub.get('id', ''),
                'lang': sub.get('lang', ''),
                'rating': int(sub.get('down_count', 0) * 5 / max_count),
                'sync': (sub.get('size') == file_size and file_size > 0),
                'lang_flag': xbmc.convertLanguage(sub.get('lang', ''), xbmc.ISO_639_1),
            })

        log(__name__, 'TK results: %d' % len(results))
        return results

    def download(self, sub_id, link_file):
        """Download subtitle zip. Returns local zip file path or None."""
        dest_dir = os.path.join(
            xbmcvfs.translatePath(self.addon.getAddonInfo('profile')), 'temp'
        )
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, "titulky_download.zip")

        referer = "%s/%s.htm" % (self.SERVER_URL, link_file)
        content = self._get_download_page(sub_id, referer, None)
        if content is None:
            return None

        # Handle captcha
        control_img = self._get_control_image(content)
        if control_img is not None:
            log(__name__, 'Captcha required')
            captcha_data = self._get_file(control_img)
            captcha_file = os.path.join(dest_dir, "captcha_%d.img" % int(time.time()))
            with open(captcha_file, 'wb') as f:
                f.write(captcha_data)

            solution = ask_for_captcha(self.addon, captcha_file,
                                       self.addon.getLocalizedString(32013)
                                       if self._has_string(32013) else 'Enter captcha text')
            if solution:
                content = self._get_download_page(sub_id, None, solution)
                if content is None:
                    return None
                if self._get_control_image(content) is not None:
                    log(__name__, 'Invalid captcha solution')
                    xbmcgui.Dialog().notification(
                        self.addon.getAddonInfo('name'), 'Invalid captcha', time=3000
                    )
                    return None
            else:
                return None

        wait_time = self._get_wait_time(content)
        link = self._get_final_link(content)
        if not link:
            log(__name__, 'Could not find download link')
            return None

        log(__name__, 'Waiting %d seconds before download' % wait_time)
        for i in range(wait_time + 1):
            xbmcgui.Dialog().notification(
                self.addon.getAddonInfo('name'),
                'Downloading in %d s...' % (wait_time - i),
                time=1000
            )
            time.sleep(1)

        log(__name__, 'Downloading subtitle zip from %s' % link)
        data = self._get_file(link, referer="https://www.titulky.com/idown.php")
        if not data:
            return None

        with open(dest, 'wb') as f:
            f.write(data)
        log(__name__, 'Saved zip to %s' % dest)
        return dest

    # ── Private helpers ───────────────────────────────────────────────────────

    def _has_string(self, string_id):
        try:
            s = self.addon.getLocalizedString(string_id)
            return bool(s)
        except Exception:
            return False

    def _normalize_title(self, title):
        if self.addon.getSetting('TKsearch_title_in_brackets') == 'true':
            m = re.match(r'.+ \((.{3,})\)', title)
            if m and not re.search(r'^[\d]{4}$', m.group(1)):
                title = m.group(1)
        if re.search(r', The$', title, re.IGNORECASE):
            title = 'The ' + re.sub(r'(?i), The$', '', title)
        if self.addon.getSetting('TKtry_cleanup_title') == 'true':
            title = re.sub(r'(\[|\().+?(\]|\))', '', title)
        return title.strip()

    def _get_file(self, link, referer=None):
        req = urllib.request.Request(link)
        req = self._add_cookies(req)
        if referer:
            req.add_header('Referer', referer)
        response = urllib.request.urlopen(req, timeout=max(self.request_timeout, 20))
        # Update PHPSESSID if sent
        set_cookie = response.getheader('Set-Cookie') or ''
        m = re.search(r'PHPSESSID=(\S+?);', set_cookie, re.IGNORECASE)
        if m:
            self.cookies['PHPSESSID'] = m.group(1)
        data = response.read()
        response.close()
        return data

    def _get_download_page(self, subs_id, referer, code):
        if code is None:
            url = self.SERVER_URL + '/idown.php?' + urllib.parse.urlencode({
                'R': str(calendar.timegm(time.gmtime())),
                'titulky': subs_id,
                'histstamp': '',
                'zip': 'z'
            })
            req = urllib.request.Request(url)
        else:
            url = self.SERVER_URL + '/idown.php'
            post_data = urllib.parse.urlencode({
                'downkod': code,
                'titulky': subs_id,
                'zip': 'z',
                'securedown': '2',
                'histstamp': ''
            }).encode('utf-8')
            req = urllib.request.Request(url, post_data)

        req = self._add_cookies(req)
        if referer:
            req.add_header('Referer', referer)

        try:
            response = urllib.request.urlopen(req, timeout=max(self.request_timeout, 20))
            return get_content_from_response(response)
        except Exception as e:
            log(__name__, 'Download page error: %s' % e)
            return None

    def _get_wait_time(self, content):
        m = re.search(r'CountDown\((\d+)\)', content, re.IGNORECASE)
        return int(m.group(1)) if m else 0

    def _get_final_link(self, content):
        m = re.search(r'<a[^>]+id="downlink"[^>]+href="([^"]+)"', content, re.IGNORECASE | re.DOTALL)
        if m:
            return self.SERVER_URL + str(m.group(1))
        return None

    def _get_control_image(self, content):
        m = re.search(r'\.\/(captcha\/captcha\.php)', content, re.IGNORECASE)
        if m:
            return self.SERVER_URL + '/' + str(m.group(1))
        return None

    def _add_cookies(self, request):
        cookie_str = '; '.join('%s=%s' % (k, v) for k, v in self.cookies.items())
        if cookie_str:
            request.add_header('Cookie', cookie_str)
        return request

    def _search_subtitle(self, title):
        url = self.SERVER_URL + '/index.php?' + urllib.parse.urlencode({
            'Fulltext': title,
            'FindUser': ''
        })
        log(__name__, 'TK opening: %s' % url)
        try:
            req = urllib.request.Request(url)
            response = urllib.request.urlopen(req, timeout=self.request_timeout)
            content = get_content_from_response(response)
        except Exception as e:
            log(__name__, 'TK search request failed: %s' % e)
            return []

        subtitles = []
        for row in re.finditer(r'<tr class="r(.+?)</tr>', content, re.IGNORECASE | re.DOTALL):
            try:
                sub = {}
                sub['link_file'] = re.search(
                    r'[^<]+<td[^<]+<a href="(?P<data>\S+)\.htm"', row.group(1), re.IGNORECASE | re.DOTALL
                ).group('data')
                sub['id'] = re.search(
                    r'[^<]+<td[^<]+<a href="[\w-]+-(?P<data>\d+)\.htm"', row.group(1), re.IGNORECASE | re.DOTALL
                ).group('data')
                sub['title'] = re.search(
                    r'[^<]+<td[^<]+<a[^>]+>(<div[^>]+>)?(?P<data>[^<]+)', row.group(1), re.IGNORECASE | re.DOTALL
                ).group('data')
                try:
                    sub['version'] = re.search(
                        r'((.+?)</td>)[^>]+>[^<]*<a(.+?)title="(?P<data>[^"]+)', row.group(1),
                        re.IGNORECASE | re.DOTALL
                    ).group('data')
                except Exception:
                    sub['version'] = None
                sub['season_and_episode'] = re.search(
                    r'((.+?)</td>){2}[^>]+>(?P<data>[^<]+)', row.group(1), re.IGNORECASE | re.DOTALL
                ).group('data')
                if sub['season_and_episode'] == '&nbsp;':
                    sub['season_and_episode'] = None
                sub['year'] = re.search(
                    r'((.+?)</td>){3}[^>]+>(?P<data>[^<]+)', row.group(1), re.IGNORECASE | re.DOTALL
                ).group('data')
                if sub['year'] == '&nbsp;':
                    sub['year'] = None
                sub['down_count'] = int(re.search(
                    r'((.+?)</td>){4}[^>]+>(?P<data>[^<]+)', row.group(1), re.IGNORECASE | re.DOTALL
                ).group('data'))
                try:
                    sub['lang'] = re.search(
                        r'((.+?)</td>){5}[^>]+><img alt="(?P<data>\w{2})"', row.group(1),
                        re.IGNORECASE | re.DOTALL
                    ).group('data')
                except Exception:
                    continue
                if sub['lang'] == 'CZ':
                    sub['lang'] = 'Czech'
                if sub['lang'] == 'SK':
                    sub['lang'] = 'Slovak'
                try:
                    sub['size'] = float(re.search(
                        r'((.+?)</td>){7}[^>]+>(?P<data>[\d\.]+)', row.group(1),
                        re.IGNORECASE | re.DOTALL
                    ).group('data'))
                except Exception:
                    sub['size'] = None
                try:
                    sub['author'] = re.search(
                        r'((.+?)</td>){8}[^>]+>[^>]+<a href[^>]+>(?P<data>[^<]+)', row.group(1),
                        re.IGNORECASE | re.DOTALL | re.MULTILINE
                    ).group('data').strip()
                except Exception:
                    sub['author'] = None
                subtitles.append(sub)
            except Exception as e:
                log(__name__, 'TK row parse error: %s' % e)
                continue

        return subtitles

    def _filter_by_language(self, set_languages, subtitles_list):
        # Titulky.com is Czech/Slovak — always return all results
        # Language filtering for non-CZ/SK would remove useful results
        return subtitles_list

    def _normalize_timeout(self, value):
        try:
            timeout = int(value)
        except (TypeError, ValueError):
            timeout = 8
        return max(3, min(timeout, 30))
