# -*- coding: utf-8 -*-
import os
import re


SUPPORTED_EXTENSIONS = {".srt", ".vtt", ".ass", ".ssa", ".txt", ".sub"}
READ_ENCODINGS = (
    "utf-8-sig",
    "utf-16",
    "windows-1250",
    "iso-8859-2",
    "windows-1251",
    "iso-8859-5",
    "utf-8",
    "latin-1",
)

WORD_RE = re.compile(r"(?iu)[a-záäčďéěíĺľňóôŕšťúůýž]+")
PROTECTED_RE = re.compile(r"(\{[^}]*\}|<[^>]+>|\\[Nnh]|&[A-Za-z0-9#]+;)")
MICRODVD_RE = re.compile(r"^(\{[^}]*\}\{[^}]*\})(.*)$")

CS_SPECIAL_RULES = (
    ("dž", "дж"),
    ("dz", "дз"),
    ("ch", "х"),
    ("ja", "я"),
    ("je", "є"),
    ("ji", "ї"),
    ("jo", "йо"),
    ("ju", "ю"),
    ("dě", "дє"),
    ("tě", "тє"),
    ("ně", "нє"),
    ("mě", "мє"),
    ("bě", "бє"),
    ("pě", "пє"),
    ("vě", "вє"),
    ("fě", "фє"),
    ("ou", "оу"),
    ("au", "ау"),
    ("eu", "еу"),
)

SK_SPECIAL_RULES = (
    ("dž", "дж"),
    ("dz", "дз"),
    ("ch", "х"),
    ("ja", "я"),
    ("je", "є"),
    ("ji", "ї"),
    ("jo", "йо"),
    ("ju", "ю"),
    ("ia", "я"),
    ("ie", "є"),
    ("iu", "ю"),
    ("ô", "уо"),
    ("au", "ау"),
    ("eu", "еу"),
)

CS_CHAR_MAP = {
    "a": "а", "á": "а", "b": "б", "c": "ц", "č": "ч", "d": "д", "ď": "дь",
    "e": "е", "é": "е", "ě": "є", "f": "ф", "g": "ґ", "h": "г", "i": "і",
    "í": "і", "j": "й", "k": "к", "l": "л", "m": "м", "n": "н", "ň": "нь",
    "o": "о", "ó": "о", "p": "п", "q": "кв", "r": "р", "ř": "рж", "s": "с",
    "š": "ш", "t": "т", "ť": "ть", "u": "у", "ú": "у", "ů": "у", "v": "в",
    "w": "в", "x": "кс", "y": "и", "ý": "и", "z": "з", "ž": "ж",
}

SK_CHAR_MAP = {
    "a": "а", "á": "а", "ä": "е", "b": "б", "c": "ц", "č": "ч", "d": "д",
    "ď": "дь", "e": "е", "é": "е", "f": "ф", "g": "ґ", "h": "г", "i": "і",
    "í": "і", "j": "й", "k": "к", "l": "л", "ĺ": "л", "ľ": "ль", "m": "м",
    "n": "н", "ň": "нь", "o": "о", "ó": "о", "p": "п", "q": "кв", "r": "р",
    "ŕ": "р", "s": "с", "š": "ш", "t": "т", "ť": "ть", "u": "у", "ú": "у",
    "v": "в", "w": "в", "x": "кс", "y": "и", "ý": "и", "z": "з", "ž": "ж",
}

CS_MARKERS = ("ě", "ř", "ů")
SK_MARKERS = ("ä", "ĺ", "ľ", "ŕ", "ô", "dž", "dz")


def detect_language(text):
    sample = (text or "").lower()
    cs_score = sum(sample.count(marker) for marker in CS_MARKERS)
    sk_score = sum(sample.count(marker) for marker in SK_MARKERS)
    if sk_score > cs_score:
        return "sk"
    return "cs"


def _apply_special_rules(word, rules):
    result = word
    for source, target in rules:
        result = result.replace(source, target)
    return result


def _apply_char_map(word, mapping):
    return "".join(mapping.get(char, char) for char in word)


def _match_case(source, target):
    if not target:
        return target
    if source.isupper():
        return target.upper()
    if len(source) > 1 and source[0].isupper() and source[1:].islower():
        return target[0].upper() + target[1:]
    return target


def transliterate_word(word, source_language="auto"):
    if not word:
        return word

    lang = source_language if source_language in ("cs", "sk") else detect_language(word)
    lower = word.lower()

    if lang == "sk":
        lower = _apply_special_rules(lower, SK_SPECIAL_RULES)
        converted = _apply_char_map(lower, SK_CHAR_MAP)
    else:
        lower = _apply_special_rules(lower, CS_SPECIAL_RULES)
        converted = _apply_char_map(lower, CS_CHAR_MAP)

    return _match_case(word, converted)


def transliterate_text(text, source_language="auto"):
    parts = PROTECTED_RE.split(text)
    output = []
    for part in parts:
        if not part:
            continue
        if PROTECTED_RE.fullmatch(part):
            output.append(part)
        else:
            output.append(
                WORD_RE.sub(
                    lambda match: transliterate_word(match.group(0), source_language),
                    part,
                )
            )
    return "".join(output)


def _read_text_file(path):
    with open(path, "rb") as handle:
        raw = handle.read()

    for encoding in READ_ENCODINGS:
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _guess_language_from_name(path):
    lowered = " %s " % os.path.basename(path).lower()
    if any(marker in lowered for marker in ("czech", ".cs.", "_cs_", "-cs-", " ces ", " cze ")):
        return "cs"
    if any(marker in lowered for marker in ("slovak", ".sk.", "_sk_", "-sk-", " slk ", " slo ")):
        return "sk"
    return None


def _is_srt_counter_line(line):
    return bool(re.fullmatch(r"\d+", line.strip()))


def _is_timestamp_line(line):
    return "-->" in line


def _transliterate_ass(content, source_language):
    output = []
    for line in content.splitlines(True):
        if not line.startswith("Dialogue:"):
            output.append(line)
            continue

        prefix, payload = line.split(":", 1)
        parts = payload.split(",", 9)
        if len(parts) < 10:
            output.append(line)
            continue

        parts[9] = transliterate_text(parts[9], source_language)
        output.append("%s:%s" % (prefix, ",".join(parts)))
    return "".join(output)


def _transliterate_microdvd_line(line, source_language):
    match = MICRODVD_RE.match(line.rstrip("\r\n"))
    if not match:
        return transliterate_text(line, source_language)
    newline = "\n" if line.endswith("\n") else ""
    return "%s%s%s" % (
        match.group(1),
        transliterate_text(match.group(2), source_language),
        newline,
    )


def _transliterate_line_based(content, extension, source_language):
    output = []
    passthrough_block = False

    for line in content.splitlines(True):
        stripped = line.strip()

        if passthrough_block:
            output.append(line)
            if not stripped:
                passthrough_block = False
            continue

        if stripped.startswith(("WEBVTT", "STYLE", "REGION", "NOTE")):
            output.append(line)
            if stripped in ("STYLE", "REGION") or stripped.startswith("NOTE"):
                passthrough_block = True
            continue

        if not stripped or _is_srt_counter_line(line) or _is_timestamp_line(line):
            output.append(line)
            continue

        if extension == ".sub":
            output.append(_transliterate_microdvd_line(line, source_language))
        else:
            output.append(transliterate_text(line, source_language))

    return "".join(output)


def generate_phonetic_subtitle(source_path, output_dir, source_language="auto"):
    extension = os.path.splitext(source_path)[1].lower()
    if extension not in SUPPORTED_EXTENSIONS:
        raise ValueError("Unsupported subtitle format: %s" % extension)

    content = _read_text_file(source_path)
    detected_language = source_language
    if detected_language not in ("cs", "sk"):
        detected_language = _guess_language_from_name(source_path) or detect_language(content)

    if extension in (".ass", ".ssa"):
        transformed = _transliterate_ass(content, detected_language)
    else:
        transformed = _transliterate_line_based(content, extension, detected_language)

    os.makedirs(output_dir, exist_ok=True)
    base = os.path.splitext(os.path.basename(source_path))[0]
    target = os.path.join(output_dir, "%s.ukrphon%s" % (base, extension))
    with open(target, "w", encoding="utf-8-sig", newline="") as handle:
        handle.write(transformed)
    return target
