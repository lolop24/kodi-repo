# -*- coding: utf-8 -*-
"""
Subtitle downloader for OpenSubtitles.com + Titulky.com.
Downloads one selected Czech/Slovak subtitle, generates a Ukrainian phonetic
version locally, and merges both into a dual-position ASS file.
"""
import os
import re
import sys
import shutil
import time
import zipfile
import concurrent.futures

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from urllib.parse import unquote, quote

from resources.lib.data_collector import (
    get_language_data, get_media_data, get_file_path, get_3let_languages,
    convert_language, clean_feature_release_name, get_flag,
)
from resources.lib.exceptions import (
    AuthenticationError, ConfigurationError, DownloadLimitExceeded,
    ProviderError, ServiceUnavailable, TooManyRequests, BadUsernameError,
)
from resources.lib.file_operations import get_file_data
from resources.lib.os.provider import OpenSubtitlesProvider
from resources.lib.utilities import get_params, log, error
from resources.lib.titulky_client import TitulkyClient
from resources.lib.dualsubs import mergesubs
from resources.lib.phonetic_ua import generate_phonetic_subtitle

__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo("id")
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo("profile"))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, "temp", ""))
__msg_box__ = xbmcgui.Dialog()

if xbmcvfs.exists(__temp__):
    shutil.rmtree(__temp__)
xbmcvfs.mkdirs(__temp__)

_SUBDIR = xbmcvfs.translatePath("special://temp/tds/")
_PHONETIC_SUPPORTED_LANGS = {"cs", "sk"}
_DEFAULT_SEARCH_TIMEOUT = 8


def _ensure_subdir():
    if not xbmcvfs.exists(_SUBDIR):
        xbmcvfs.mkdir(_SUBDIR)


def _clean_subdir():
    if xbmcvfs.exists(_SUBDIR):
        try:
            dirs, files = xbmcvfs.listdir(_SUBDIR)
            for filename in files:
                xbmcvfs.delete(os.path.join(_SUBDIR, filename))
        except Exception as exc:
            log(__name__, "Clean subdir error: %s" % exc)


class CombinedSubtitleDownloader:

    def __init__(self):
        self.api_key = __addon__.getSetting("APIKey")
        self.os_username = __addon__.getSetting("OSuser")
        self.os_password = __addon__.getSetting("OSpass")
        self.tk_username = __addon__.getSetting("TKuser")
        self.tk_password = __addon__.getSetting("TKpass")
        self.fast_search_mode = self._get_bool_setting("fast_search_mode", True)
        self.skip_remote_hash = self._get_bool_setting("skip_remote_hash", True)
        self.search_timeout = self._get_int_setting("search_timeout", _DEFAULT_SEARCH_TIMEOUT)

        log(__name__, "argv: %s" % sys.argv)

        self.sub_format = "srt"
        self.handle = int(sys.argv[1])
        self.params = get_params()
        self.query = {}
        self.subtitles = []

        self.open_subtitles = None
        try:
            self.open_subtitles = OpenSubtitlesProvider(
                self.api_key, self.os_username, self.os_password, self.search_timeout
            )
        except ConfigurationError as exc:
            log(__name__, "OS provider config error: %s" % exc)

        self.titulky = TitulkyClient(__addon__, self.search_timeout)

    def handle_action(self):
        action = self.params.get("action", "")
        log(__name__, "action '%s' called" % action)

        if action == "manualsearch":
            self.search(self.params.get("searchstring", ""))
        elif action == "search":
            self.search()
        elif action == "downloadphonetic":
            self.download()
        elif action == "settings":
            __addon__.openSettings()
            __msg_box__.ok("", "Restart subtitle search to apply new settings.")

    def search(self, query=""):
        file_data = get_file_data(
            get_file_path(),
            skip_remote_hash=self.fast_search_mode and self.skip_remote_hash,
        )
        language_data = get_language_data(self.params)
        language_data["languages"] = "cs,sk"

        if query:
            media_data = {"query": query}
        else:
            media_data = get_media_data()
            if "basename" in file_data and not media_data.get("query"):
                media_data["query"] = file_data.get("basename", "")

        self.query = {**media_data, **file_data, **language_data}
        log(__name__, "Combined query: %s" % self.query)

        os_results = []
        tk_results = []

        executor = concurrent.futures.ThreadPoolExecutor(max_workers=2)
        futures = {}
        try:
            if self.open_subtitles:
                futures[executor.submit(self._search_os)] = "os"
            futures[executor.submit(self._search_tk)] = "tk"

            done, not_done = concurrent.futures.wait(
                list(futures.keys()),
                timeout=self.search_timeout + 1,
                return_when=concurrent.futures.ALL_COMPLETED,
            )

            for future in done:
                source = futures[future]
                try:
                    result = future.result()
                    if source == "os":
                        os_results = result or []
                    elif source == "tk":
                        tk_results = result or []
                except Exception as exc:
                    log(__name__, "Search error [%s]: %s" % (source, exc))

            for future in not_done:
                log(__name__, "Search timeout [%s] after %ss" % (futures[future], self.search_timeout))
        finally:
            executor.shutdown(wait=False)

        self.subtitles = []

        for sub in tk_results:
            lang = sub.get("lang", "")
            self.subtitles.append({
                "source": "TK",
                "id": "tk:%s:%s" % (sub.get("id", ""), sub.get("link_file", "")),
                "label": lang,
                "lang_code": self._normalize_lang_code(lang),
                "label2": "[TK] " + sub.get("filename", ""),
                "icon": str(sub.get("rating", 0)),
                "flag": sub.get("lang_flag", ""),
                "sync": bool(sub.get("sync")),
                "hearing_imp": False,
            })

        pref_langs = set(
            lang.strip() for lang in self.query.get("languages", "").split(",") if lang.strip()
        )

        def _os_sort_key(result):
            attrs = result.get("attributes", {})
            lang = attrs.get("language", "")
            return (
                not attrs.get("moviehash_match"),
                lang not in _PHONETIC_SUPPORTED_LANGS,
                lang not in pref_langs,
                -(attrs.get("ratings", 0) or 0),
            )

        for sub in sorted(os_results, key=_os_sort_key):
            attrs = sub.get("attributes", {})
            files = attrs.get("files", [{}])
            file_id = files[0].get("file_id", 0) if files else 0
            lang = attrs.get("language", "")
            rating = attrs.get("ratings", 0) or 0
            self.subtitles.append({
                "source": "OS",
                "id": "os:%d" % file_id,
                "label": convert_language(lang, True),
                "lang_code": self._normalize_lang_code(lang),
                "label2": "[OS] " + clean_feature_release_name(
                    attrs.get("feature_details", {}).get("title", ""),
                    attrs.get("release", ""),
                    attrs.get("feature_details", {}).get("movie_name", ""),
                ) + (" [HASH]" if attrs.get("moviehash_match") else ""),
                "icon": str(int(round(float(rating) / 2))),
                "flag": get_flag(lang),
                "sync": bool(attrs.get("moviehash_match")),
                "hearing_imp": bool(attrs.get("hearing_impaired")),
            })

        self.subtitles = [
            sub for sub in self.subtitles
            if self._normalize_lang_code(sub.get("lang_code", "")) in _PHONETIC_SUPPORTED_LANGS
        ]

        log(__name__, "Combined results: %d OS + %d TK = %d Czech/Slovak total" % (
            len(os_results), len(tk_results), len(self.subtitles)))

        if self.subtitles:
            self.list_subtitles()
        else:
            log(__name__, "No Czech/Slovak subtitles found from any source")

    def _search_os(self):
        all_results = []
        seen_file_ids = set()
        started = time.monotonic()

        def _add_results(results):
            for sub in (results or []):
                attrs = sub.get("attributes", {})
                files = attrs.get("files", [{}])
                file_id = files[0].get("file_id", 0) if files else 0
                if file_id and file_id not in seen_file_ids:
                    seen_file_ids.add(file_id)
                    all_results.append(sub)

        def _deadline_reached():
            return (time.monotonic() - started) >= self.search_timeout

        q = self.query
        base_params = {
            "languages": "cs,sk",
            "hearing_impaired": q.get("hearing_impaired", "include"),
            "foreign_parts_only": q.get("foreign_parts_only", "include"),
            "machine_translated": q.get("machine_translated", "exclude"),
            "ai_translated": q.get("ai_translated", "include"),
        }
        if q.get("type") in ("movie", "episode"):
            base_params["type"] = q.get("type")
        if q.get("type") == "episode":
            base_params["season_number"] = q.get("season_number")
            base_params["episode_number"] = q.get("episode_number")

        def _search_with_params(params, label):
            if _deadline_reached():
                log(__name__, "OS search deadline reached before %s" % label)
                return
            try:
                log(__name__, "OS search: %s" % label)
                _add_results(self.open_subtitles.search_subtitles(params))
            except Exception as exc:
                log(__name__, "OS %s search error: %s" % (label, exc))

        if q.get("moviehash"):
            params = dict(base_params, moviehash=q["moviehash"], moviehash_match="only")
            _search_with_params(params, "moviehash")

        if q.get("imdb_id") and not _deadline_reached() and not all_results:
            params = dict(base_params, imdb_id=q["imdb_id"])
            if q.get("type") == "episode" and q.get("parent_imdb_id"):
                params["parent_imdb_id"] = q["parent_imdb_id"]
            _search_with_params(params, "imdb_id=%s" % q["imdb_id"])

        if not all_results and not _deadline_reached():
            for query_text in self._build_os_text_queries():
                if _deadline_reached():
                    log(__name__, "OS search deadline reached before query fallback")
                    break
                params = dict(base_params, query=query_text)
                if q.get("year"):
                    params["year"] = q["year"]
                _search_with_params(params, "query='%s'" % query_text)
                if all_results:
                    break

        log(__name__, "OS total unique Czech/Slovak results: %d" % len(all_results))
        return all_results

    def _build_os_text_queries(self):
        queries = []
        seen = set()

        def _add(raw_value, include_raw=True):
            raw_value = (raw_value or "").strip()
            if not raw_value:
                return

            variants = []
            if include_raw:
                variants.append(raw_value)
            variants.extend(self._clean_os_query_variants(raw_value))

            for variant in variants:
                key = variant.lower()
                if key not in seen:
                    seen.add(key)
                    queries.append(variant)

        _add(self.query.get("query"), include_raw=True)
        _add(self.query.get("title"), include_raw=True)
        _add(self.query.get("basename"), include_raw=False)
        limit = 1 if self.fast_search_mode else 4
        return queries[:limit]

    def _clean_os_query_variants(self, raw_value):
        value = os.path.splitext(os.path.basename(raw_value))[0]
        value = re.sub(r"\[[^\]]*\]|\([^)]*\)", " ", value)
        value = re.sub(r"[._]+", " ", value)
        value = re.sub(
            r"\b(?:s\d{1,2}e\d{1,2}|\d{1,2}x\d{1,2})\b.*$",
            " ",
            value,
            flags=re.IGNORECASE,
        )

        year_prefix = None
        year_match = re.search(r"\b(?:19|20)\d{2}\b", value)
        if year_match:
            year_prefix = value[:year_match.end()]

        cleaned = year_prefix or value
        cleaned = re.sub(
            r"\b(?:2160p|1080p|720p|480p|x264|x265|h264|h265|hevc|hdr10plus|hdr10|hdr|dv|"
            r"bdrip|bluray|blu ray|webrip|web dl|web-dl|web|remux|dvdrip|proper|repack|"
            r"internal|atmos|truehd|dts|multi|subs?|dubbed|imax|yts|rarbg|amzn|nf|dsnp|"
            r"hmax|hulu|itunes)\b.*$",
            " ",
            cleaned,
            flags=re.IGNORECASE,
        )
        cleaned = re.sub(r"\s+", " ", cleaned).strip(" -._")

        title_only = re.sub(r"\b(?:19|20)\d{2}\b", " ", cleaned)
        title_only = re.sub(r"\s+", " ", title_only).strip(" -._")

        variants = []
        if cleaned:
            variants.append(cleaned)
        if title_only and title_only.lower() != cleaned.lower():
            variants.append(title_only)
        return [variant for variant in variants if len(variant) >= 2]

    def _search_tk(self):
        try:
            item = self._build_tk_item()
            return self.titulky.search(item) or []
        except Exception as exc:
            log(__name__, "TK search error: %s" % exc)
            return []

    def _build_tk_item(self):
        q = self.query
        is_manual = bool(q.get("query")) and not q.get("title") and not q.get("tvshow")
        three_let = [
            code for code in get_3let_languages(self.params)
            if code in ("ces", "cze", "slk", "slo", "csy", "sky")
        ]
        if not three_let:
            three_let = ["ces", "slk"]
        return {
            "mansearch": is_manual,
            "mansearchstr": q.get("query", ""),
            "tvshow": q.get("tvshow", ""),
            "season": int(q.get("season_number") or 0),
            "episode": int(q.get("episode_number") or 0),
            "title": q.get("title", "") or q.get("query", ""),
            "year": q.get("year", ""),
            "3let_language": three_let,
            "file_original_path": q.get("file_original_path", ""),
            "rar": bool(q.get("rar", False)),
        }

    def list_subtitles(self):
        if not self.subtitles:
            xbmcplugin.endOfDirectory(self.handle)
            return

        for subtitle in self.subtitles:
            item = xbmcgui.ListItem(label=subtitle["label"], label2=subtitle["label2"])
            item.setArt({"icon": subtitle["icon"], "thumb": subtitle["flag"]})
            item.setProperty("sync", "true" if subtitle["sync"] else "false")
            item.setProperty("hearing_imp", "true" if subtitle["hearing_imp"] else "false")

            url, item = self._build_single_selection_item(subtitle, item)
            xbmcplugin.addDirectoryItem(
                handle=self.handle, url=url, listitem=item, isFolder=False
            )

        xbmcplugin.endOfDirectory(self.handle)

    def download(self):
        single_id = unquote(self.params.get("id", ""))
        source_lang = self._normalize_lang_code(unquote(self.params.get("lang", "")))

        _clean_subdir()
        _ensure_subdir()

        original_path = self._download_by_id(single_id)
        if not original_path:
            return

        generated_path = self._generate_phonetic_variant(original_path, source_lang)
        if not generated_path:
            __msg_box__.ok(
                "Phonetic UA",
                "Could not generate Ukrainian phonetic subtitles from the selected file.",
            )
            return

        finalfile = mergesubs([original_path, generated_path])
        item = xbmcgui.ListItem(label=finalfile)
        xbmcplugin.addDirectoryItem(
            handle=self.handle, url=finalfile, listitem=item, isFolder=False
        )

    def _build_single_selection_item(self, subtitle, list_item=None):
        single_id = quote(subtitle["id"])
        lang_code = self._normalize_lang_code(subtitle.get("lang_code", ""))
        url = "plugin://%s/?action=downloadphonetic&id=%s&lang=%s" % (
            __scriptid__, single_id, quote(lang_code)
        )
        label = "[TOP] Ukrainian phonetic  +  [BOT] %s" % subtitle["label2"]
        item = list_item or xbmcgui.ListItem(label=subtitle["label"], label2=label)
        item.setLabel2(label)
        return url, item

    def _normalize_lang_code(self, language):
        value = (language or "").strip().lower()
        mapping = {
            "czech": "cs",
            "ces": "cs",
            "cze": "cs",
            "cs": "cs",
            "cz": "cs",
            "slovak": "sk",
            "slk": "sk",
            "slo": "sk",
            "sk": "sk",
            "sky": "sk",
        }
        return mapping.get(value, value)

    def _phonetic_source_language(self, fallback_lang):
        value = __addon__.getSetting("phonetic_ua_source_lang") or "0"
        try:
            idx = int(value)
        except (TypeError, ValueError):
            idx = 0
        mapping = {0: "auto", 1: "cs", 2: "sk"}
        configured = mapping.get(idx, "auto")
        if configured != "auto":
            return configured
        fallback = self._normalize_lang_code(fallback_lang)
        return fallback if fallback in _PHONETIC_SUPPORTED_LANGS else "auto"

    def _generate_phonetic_variant(self, subtitle_path, source_lang):
        try:
            generated = generate_phonetic_subtitle(
                subtitle_path,
                _SUBDIR,
                self._phonetic_source_language(source_lang),
            )
            log(__name__, "Generated phonetic subtitle: %s" % generated)
            return generated
        except Exception as exc:
            log(__name__, "Phonetic subtitle generation failed: %s" % exc)
            return None

    def _download_by_id(self, encoded_id):
        if not encoded_id:
            return None
        if encoded_id.startswith("os:"):
            return self._download_os(encoded_id[3:])
        if encoded_id.startswith("tk:"):
            rest = encoded_id[3:]
            parts = rest.split(":", 1)
            if len(parts) == 2:
                sub_id, link_file = parts
                return self._download_tk(sub_id, link_file)
            log(__name__, "Invalid TK id format: %s" % encoded_id)
        return None

    def _download_os(self, file_id_str):
        try:
            file_id = int(file_id_str)
        except (ValueError, TypeError):
            log(__name__, "Invalid OS file_id: %s" % file_id_str)
            return None

        try:
            file_data = self.open_subtitles.download_subtitle(
                {"file_id": file_id, "sub_format": self.sub_format}
            )
            content = file_data.get("content")
        except AuthenticationError as exc:
            error(__name__, "Authentication error: %s" % exc)
            return None
        except BadUsernameError as exc:
            error(__name__, "Bad username (use username, not email): %s" % exc)
            return None
        except DownloadLimitExceeded:
            msg = (
                "Download limit exceeded. Create a free account at opensubtitles.com for more downloads."
                if not self.os_username else
                "Daily download limit reached for your account."
            )
            error(__name__, msg)
            return None
        except (TooManyRequests, ServiceUnavailable, ProviderError, ValueError) as exc:
            error(__name__, "OpenSubtitles error: %s" % exc)
            return None

        if not content:
            log(__name__, "OS returned empty content for file_id %s" % file_id)
            return None

        subtitle_path = os.path.join(_SUBDIR, "OS_%s.%s" % (file_id, self.sub_format))
        with open(subtitle_path, "wb") as handle:
            handle.write(content)
        log(__name__, "OS subtitle saved to %s" % subtitle_path)
        return subtitle_path

    def _download_tk(self, sub_id, link_file):
        if not self.titulky.login(self.tk_username, self.tk_password):
            __msg_box__.ok(
                "Titulky.com",
                "Login failed. Check your Titulky.com username and password in addon settings.",
            )
            return None

        zip_path = self.titulky.download(sub_id, link_file)
        if not zip_path:
            log(__name__, "TK download returned no zip")
            return None

        subtitle_exts = {".srt", ".sub", ".ass", ".ssa", ".txt"}
        subtitle_path = None
        try:
            with zipfile.ZipFile(zip_path, "r") as archive:
                for name in archive.namelist():
                    if os.path.splitext(name)[1].lower() in subtitle_exts:
                        basename = os.path.basename(name) or ("TK_%s.srt" % sub_id)
                        extract_path = os.path.join(_SUBDIR, basename)
                        with open(extract_path, "wb") as handle:
                            handle.write(archive.read(name))
                        subtitle_path = extract_path
                        log(__name__, "TK subtitle extracted to %s" % subtitle_path)
                        break
        except zipfile.BadZipFile as exc:
            log(__name__, "TK zip extraction error: %s" % exc)
            if os.path.exists(zip_path):
                subtitle_path = zip_path
        except Exception as exc:
            log(__name__, "TK extraction error: %s" % exc)

        return subtitle_path

    def _get_bool_setting(self, key, default=False):
        value = __addon__.getSetting(key)
        if value == "":
            return default
        return value.lower() == "true"

    def _get_int_setting(self, key, default):
        value = __addon__.getSetting(key)
        try:
            parsed = int(float(value))
        except (TypeError, ValueError):
            parsed = default
        return max(3, min(parsed, 30))
