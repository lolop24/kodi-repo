# -*- coding: utf-8 -*-
import os
import re


SUPPORTED_EXTENSIONS = (".srt", ".vtt", ".ass", ".ssa")
READ_ENCODINGS = (
    "utf-8-sig",
    "utf-16",
    "windows-1250",
    "iso-8859-2",
    "windows-1251",
    "iso-8859-5",
    "utf-8",
    "latin-1",
)


LANGUAGE_NAME_HINTS = {
    "cs": ("czech", "ces", "cze", ".cs.", "_cs_", "-cs-", " cz "),
    "sk": ("slovak", "slk", "slo", ".sk.", "_sk_", "-sk-", " sk "),
}


CS_MARKERS = ("\u011b", "\u0159", "\u016f")
SK_MARKERS = ("\u00e4", "\u013a", "\u013e", "\u0155", "\u00f4", "d\u017e", "dz")
PROTECTED_RE = re.compile(r"(\{[^}]*\}|<[^>]+>|\\[Nnh]|&[A-Za-z0-9#]+;)")


def guess_language_from_name(name):
    lowered = " %s " % (name or "").lower()
    for code, hints in LANGUAGE_NAME_HINTS.items():
        if any(hint in lowered for hint in hints):
            return code
    return None


def detect_language(text):
    sample = (text or "").lower()
    cs_score = sum(sample.count(marker) for marker in CS_MARKERS)
    sk_score = sum(sample.count(marker) for marker in SK_MARKERS)
    if sk_score > cs_score:
        return "sk"
    return "cs"


def safe_stem(path):
    stem = os.path.splitext(os.path.basename(path))[0]
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._-")
    return stem or "subtitle"


def read_text_file(path):
    with open(path, "rb") as handle:
        raw = handle.read()
    for encoding in READ_ENCODINGS:
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _is_srt_counter_line(line):
    return bool(re.fullmatch(r"\d+", line.strip()))


def _is_timestamp_line(line):
    return "-->" in line


def _has_translatable_text(text):
    return any(char.isalpha() for char in text or "")


def _split_padding(text):
    match = re.match(r"^(\s*)(.*?)(\s*)$", text, re.S)
    if not match:
        return "", text, ""
    return match.group(1), match.group(2), match.group(3)


def _split_line_ending(text):
    if text.endswith("\r\n"):
        return text[:-2], "\r\n"
    if text.endswith("\n") or text.endswith("\r"):
        return text[:-1], text[-1]
    return text, ""


def _queue_protected_translation(text, jobs, source_language):
    parts = PROTECTED_RE.split(text)
    plan = []
    for part in parts:
        if not part:
            continue
        if PROTECTED_RE.fullmatch(part):
            plan.append(("literal", part))
            continue

        prefix, core, suffix = _split_padding(part)
        if prefix:
            plan.append(("literal", prefix))
        if core and _has_translatable_text(core):
            jobs.append({"text": core})
            plan.append(("job", len(jobs) - 1))
        elif core:
            plan.append(("literal", core))
        if suffix:
            plan.append(("literal", suffix))
    return plan


def _render_plan(plan, jobs):
    out = []
    for kind, value in plan:
        if kind == "literal":
            out.append(value)
        else:
            out.append(jobs[value]["translated"])
    return "".join(out)


def _translate_jobs(jobs, translate_batch, source_language):
    if not jobs:
        return
    translated = translate_batch([job["text"] for job in jobs], source_language)
    if len(translated) != len(jobs):
        raise ValueError("DeepL returned an unexpected translation count")
    for job, value in zip(jobs, translated):
        job["translated"] = value


def _translate_line_based(content, translate_batch, source_language):
    jobs = []
    plans = []
    current_block = []
    passthrough_block = False

    def flush_current_block():
        if current_block:
            plans.append(("bilingual_block", list(current_block)))
            current_block[:] = []

    for line in content.splitlines(True):
        stripped = line.strip()

        if passthrough_block:
            flush_current_block()
            plans.append(("literal", line))
            if not stripped:
                passthrough_block = False
            continue

        if stripped.startswith(("WEBVTT", "STYLE", "REGION", "NOTE")):
            flush_current_block()
            plans.append(("literal", line))
            if stripped in ("STYLE", "REGION") or stripped.startswith("NOTE"):
                passthrough_block = True
            continue

        if not stripped or _is_srt_counter_line(line) or _is_timestamp_line(line):
            flush_current_block()
            plans.append(("literal", line))
            continue

        current_block.append((line, _queue_protected_translation(line, jobs, source_language)))

    flush_current_block()

    _translate_jobs(jobs, translate_batch, source_language)

    out = []
    for kind, value in plans:
        if kind == "literal":
            out.append(value)
        else:
            for original_line, plan in value:
                out.append(original_line)

            _, last_ending = _split_line_ending(value[-1][0])
            if not last_ending:
                out.append("\n")

            for _, plan in value:
                out.append(_render_plan(plan, jobs))
    return "".join(out)


def _split_ass_dialogue(line):
    prefix, payload = line.split(":", 1)
    parts = payload.split(",", 9)
    if len(parts) < 10:
        return None
    return prefix, parts


def _translate_ass(content, translate_batch, source_language):
    jobs = []
    rows = []
    for line in content.splitlines(True):
        if not line.startswith("Dialogue:"):
            rows.append(("literal", line))
            continue

        parsed = _split_ass_dialogue(line)
        if not parsed:
            rows.append(("literal", line))
            continue

        prefix, parts = parsed
        plan = _queue_protected_translation(parts[9], jobs, source_language)
        rows.append(("dialogue", prefix, parts, plan))

    _translate_jobs(jobs, translate_batch, source_language)

    out = []
    for row in rows:
        if row[0] == "literal":
            out.append(row[1])
            continue

        _, prefix, parts, plan = row
        parts = list(parts)
        original_payload, line_ending = _split_line_ending(parts[9])
        translated_payload, _ = _split_line_ending(_render_plan(plan, jobs))
        if translated_payload:
            parts[9] = "%s\\N%s%s" % (original_payload, translated_payload, line_ending)
        else:
            parts[9] = "%s%s" % (original_payload, line_ending)
        out.append("%s:%s" % (prefix, ",".join(parts)))
    return "".join(out)


def translate_subtitle_text(content, extension, translate_batch, source_language="auto"):
    if extension in (".ass", ".ssa"):
        return _translate_ass(content, translate_batch, source_language)
    return _translate_line_based(content, translate_batch, source_language)


def detect_language_for_file(path, content, forced_language):
    if forced_language in ("cs", "sk"):
        return forced_language
    name_guess = guess_language_from_name(os.path.basename(path))
    if name_guess:
        return name_guess
    return detect_language(content)


def generate_translated_subtitle(
    source_path,
    output_dir,
    translator,
    source_language="auto",
    target_language="UK",
    source_name_hint=None,
    output_name_hint=None,
    output_path=None,
):
    extension = os.path.splitext(source_path)[1].lower()
    if extension not in SUPPORTED_EXTENSIONS:
        raise ValueError("Unsupported subtitle format: %s" % extension)

    content = read_text_file(source_path)
    detected_language = detect_language_for_file(source_name_hint or source_path, content, source_language)
    translated = translate_subtitle_text(
        content,
        extension,
        lambda texts, lang: translator.translate_texts(
            texts,
            source_lang=lang.upper() if lang else None,
            target_lang=target_language,
        ),
        detected_language,
    )

    os.makedirs(output_dir, exist_ok=True)
    target_path = output_path
    if not target_path:
        target_name = "%s.uk.deepl%s" % (safe_stem(output_name_hint or source_path), extension)
        target_path = os.path.join(output_dir, target_name)
    with open(target_path, "w", encoding="utf-8", newline="") as handle:
        handle.write(translated)

    return {
        "path": target_path,
        "detected_language": detected_language,
        "extension": extension,
    }
