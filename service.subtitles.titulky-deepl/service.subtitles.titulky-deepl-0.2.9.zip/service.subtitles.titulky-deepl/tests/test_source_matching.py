import os
import sys
import unittest


ADDON_ROOT = os.path.dirname(os.path.dirname(__file__))
if ADDON_ROOT not in sys.path:
    sys.path.insert(0, ADDON_ROOT)


from resources.lib.source_matching import build_source_score, looks_like_related_subtitle  # noqa: E402


class SourceMatchingTests(unittest.TestCase):
    def test_related_subtitle_name_matches_video_prefix(self):
        self.assertTrue(looks_like_related_subtitle("Movie.2024.cs.srt", "Movie.2024.mkv"))

    def test_current_stream_name_boosts_weird_download_name(self):
        score = build_source_score(
            "provider_release_12345.srt",
            "Movie.2024.mkv",
            ["provider release 12345"],
        )
        self.assertEqual(score[0], 1)

    def test_unrelated_name_has_lower_score(self):
        score = build_source_score("random_subtitle.srt", "Movie.2024.mkv", [])
        self.assertEqual(score[0], 0)
        self.assertEqual(score[1], 0)


if __name__ == "__main__":
    unittest.main()
