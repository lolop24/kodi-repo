import os
import sys
import tempfile
import unittest


ADDON_ROOT = os.path.dirname(os.path.dirname(__file__))
if ADDON_ROOT not in sys.path:
    sys.path.insert(0, ADDON_ROOT)


from resources.lib.generator import (  # noqa: E402
    detect_language_for_file,
    generate_translated_subtitle,
    translate_subtitle_text,
)


class GeneratorTests(unittest.TestCase):
    def test_detect_language_prefers_filename_hint(self):
        content = "Ahoj, jak se mas?"
        self.assertEqual(detect_language_for_file("movie.sk.srt", content, "auto"), "sk")

    def test_srt_structure_is_preserved(self):
        source = "1\n00:00:01,000 --> 00:00:03,000\nAhoj, jak se mas?\n"

        def fake_translate(texts, source_language):
            self.assertEqual(source_language, "cs")
            self.assertEqual(texts, ["Ahoj, jak se mas?"])
            return ["Privit, yak spravy?"]

        expected = "1\n00:00:01,000 --> 00:00:03,000\nAhoj, jak se mas?\nPrivit, yak spravy?\n"
        self.assertEqual(translate_subtitle_text(source, ".srt", fake_translate, "cs"), expected)

    def test_ass_dialogue_only_translates_text_field(self):
        source = (
            "[Events]\n"
            "Dialogue: 0,0:00:01.00,0:00:03.00,Default,,0,0,0,,<i>Ahoj</i>\\Njak se mas?\n"
        )

        def fake_translate(texts, source_language):
            self.assertEqual(source_language, "cs")
            self.assertEqual(texts, ["Ahoj", "jak se mas?"])
            return ["Pryvit", "yak spravy?"]

        expected = (
            "[Events]\n"
            "Dialogue: 0,0:00:01.00,0:00:03.00,Default,,0,0,0,,<i>Ahoj</i>\\Njak se mas?\\N<i>Pryvit</i>\\Nyak spravy?\n"
        )
        self.assertEqual(translate_subtitle_text(source, ".ass", fake_translate, "cs"), expected)

    def test_vtt_note_block_is_preserved(self):
        source = (
            "WEBVTT\n\n"
            "NOTE translator hint\n"
            "do not touch\n\n"
            "00:00:01.000 --> 00:00:02.000\n"
            "Ahoj\n"
        )

        def fake_translate(texts, source_language):
            self.assertEqual(texts, ["Ahoj"])
            return ["Pryvit"]

        expected = (
            "WEBVTT\n\n"
            "NOTE translator hint\n"
            "do not touch\n\n"
            "00:00:01.000 --> 00:00:02.000\n"
            "Ahoj\n"
            "Pryvit\n"
        )
        self.assertEqual(translate_subtitle_text(source, ".vtt", fake_translate, "cs"), expected)

    def test_multiline_block_keeps_original_then_translation_block(self):
        source = (
            "1\n"
            "00:00:01,000 --> 00:00:03,000\n"
            "Ahoj\n"
            "Jak se mas?\n\n"
        )

        def fake_translate(texts, source_language):
            self.assertEqual(texts, ["Ahoj", "Jak se mas?"])
            return ["Pryvit", "Yak spravy?"]

        expected = (
            "1\n"
            "00:00:01,000 --> 00:00:03,000\n"
            "Ahoj\n"
            "Jak se mas?\n"
            "Pryvit\n"
            "Yak spravy?\n\n"
        )
        self.assertEqual(translate_subtitle_text(source, ".srt", fake_translate, "cs"), expected)

    def test_generate_translated_subtitle_uses_original_name_hint_for_language(self):
        class FakeTranslator(object):
            def __init__(self):
                self.calls = []

            def translate_texts(self, texts, source_lang=None, target_lang=None):
                self.calls.append((texts, source_lang, target_lang))
                return ["Ahoj"]

        translator = FakeTranslator()
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = os.path.join(temp_dir, "src_random.srt")
            with open(source_path, "w", encoding="utf-8") as handle:
                handle.write("1\n00:00:01,000 --> 00:00:02,000\nAhoj\n")

            output_path = os.path.join(temp_dir, "movie.sk.uk.deepl.srt")
            info = generate_translated_subtitle(
                source_path,
                temp_dir,
                translator,
                source_language="auto",
                source_name_hint="movie.sk.srt",
                output_name_hint="movie.sk.srt",
                output_path=output_path,
            )

            self.assertEqual(info["detected_language"], "sk")
            self.assertEqual(info["path"], output_path)
            self.assertEqual(translator.calls[0][1], "SK")


if __name__ == "__main__":
    unittest.main()
