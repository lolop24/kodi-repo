# DeepL Ukrainian Bilingual Subtitles

Kodi subtitle add-on that keeps Czech or Slovak subtitle lines and adds Ukrainian translations under them via the DeepL API.

## What it does

- Integrates through Kodi's subtitle search flow (`xbmc.subtitle.module`).
- Checks Kodi's configured subtitle folder first, then nearby subtitle files next to the playing video.
- Checks temp subtitle files created by the installed `OpenSubtitles` and `Titulky.com` add-ons.
- Can also browse for a subtitle file manually.
- Supports `.srt`, `.vtt`, `.ass`, and `.ssa`.
- Preserves subtitle timing and keeps both languages in the same subtitle file.
- Lists source subtitle candidates quickly and only calls DeepL after you pick one item.
- Falls back to recently cached subtitle files in Kodi's temp area when the active subtitle came from another add-on with a non-matching filename.

## Current scope

- This MVP works with external text subtitle files and Kodi's local subtitle cache.
- It does not extract or rewrite embedded subtitle streams from inside video containers in real time.
- You need your own DeepL API key in the add-on settings.
- The default API base URL is the DeepL Free host. Change it to `https://api.deepl.com` if you use DeepL Pro.

## Install

1. Zip the `service.subtitles.titulky-deepl` folder.
2. In Kodi, install the zip as an add-on.
3. Open the add-on settings and enter your DeepL API key.
4. Set it as the subtitle add-on in the skin/video OSD if needed.
5. During playback, open `Download subtitles`, pick the source subtitle you want, and the add-on will generate the bilingual result after selection.

## Extend next

- Add DeepL glossary support for recurring names.
- Add a setting for custom target language instead of fixed Ukrainian output.
- Add auto-apply via a separate Kodi service add-on if you want it to switch subtitles without opening subtitle search.
