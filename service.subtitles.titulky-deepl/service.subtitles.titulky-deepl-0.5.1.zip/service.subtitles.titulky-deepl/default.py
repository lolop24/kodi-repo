# -*- coding: utf-8 -*-
import json
import os
import shutil
import sys
import time
import uuid
import zipfile
import hashlib

from urllib.parse import parse_qsl, quote, unquote

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.deepl import DeepLError, DeepLTranslator
from resources.lib.generator import (
    SUPPORTED_EXTENSIONS,
    generate_translated_subtitle,
    guess_language_from_name,
    safe_stem,
)
from resources.lib.source_matching import build_source_score, normalize_name


try:
    translatePath = xbmcvfs.translatePath
except AttributeError:
    translatePath = xbmc.translatePath


__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo("id")
__scriptname__ = __addon__.getAddonInfo("name")
__profile__ = translatePath(__addon__.getAddonInfo("profile"))
__workdir__ = os.path.join(__profile__, "generated")
__dialog__ = xbmcgui.Dialog()
KNOWN_SUBTITLE_ADDON_TEMP_DIRS = (
    ("TitulkyDualSub", "special://temp/tds/"),
    ("TitulkyDualSub", "special://profile/addon_data/service.subtitles.titulky-dualsub/temp"),
    ("OpenSubtitles", "special://profile/addon_data/service.subtitles.opensubtitles/temp"),
    ("Titulky.com", "special://profile/addon_data/service.subtitles.titulky.com/temp"),
    ("Edna.cz", "special://profile/addon_data/service.subtitles.edna.cz/temp"),
)


def log(message, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (__scriptid__, message), level)


def get_setting(name, default=""):
    try:
        value = __addon__.getSettingString(name)
    except AttributeError:
        value = __addon__.getSetting(name)
    return value if value != "" else default


_SOURCE_LANG_MAP = {"0": "auto", "1": "cs", "2": "sk"}


def get_source_language():
    raw = get_setting("source_language", "0")
    return _SOURCE_LANG_MAP.get(raw, raw)


def get_setting_bool(name, default=False):
    try:
        return __addon__.getSettingBool(name)
    except AttributeError:
        value = __addon__.getSetting(name)
        if value == "":
            return default
        return value.lower() == "true"


def ensure_workdir(clear=False):
    if clear and os.path.isdir(__workdir__):
        shutil.rmtree(__workdir__, ignore_errors=True)
    os.makedirs(__workdir__, exist_ok=True)


def cleanup_workdir(max_age_seconds=48 * 60 * 60):
    if not os.path.isdir(__workdir__):
        return
    cutoff = time.time() - max_age_seconds
    for name in os.listdir(__workdir__):
        path = os.path.join(__workdir__, name)
        if not os.path.isfile(path):
            continue
        try:
            if os.path.getmtime(path) < cutoff:
                os.remove(path)
        except OSError:
            continue


def get_translator():
    api_key = get_setting("deepl_api_key").strip()
    base_url = get_setting("deepl_api_base_url", "").strip()
    if not api_key:
        raise DeepLError(__addon__.getLocalizedString(32033))
    if not base_url:
        # Auto-detect: :fx suffix = Free API, otherwise Pro API
        if api_key.endswith(":fx"):
            base_url = "https://api-free.deepl.com"
        else:
            base_url = "https://api.deepl.com"
    return DeepLTranslator(auth_key=api_key, base_url=base_url)


def params():
    if len(sys.argv) < 3:
        return {}
    query = sys.argv[2].lstrip("?")
    return dict(parse_qsl(query))


def end_directory():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def add_action_item(label, action, source_label="Action"):
    url = "plugin://%s/?action=%s" % (__scriptid__, action)
    list_item = xbmcgui.ListItem(label=source_label, label2=label)
    list_item.setProperty("sync", "false")
    list_item.setProperty("hearing_imp", "false")
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=url,
        listitem=list_item,
        isFolder=False,
    )


def add_download_item(label, source_path, source_label):
    url = "plugin://%s/?action=download&source=%s" % (
        __scriptid__,
        quote(source_path, safe=""),
    )
    list_item = xbmcgui.ListItem(label=source_label, label2=label)
    list_item.setProperty("sync", "false")
    list_item.setProperty("hearing_imp", "false")
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=url,
        listitem=list_item,
        isFolder=False,
    )


def download(path):
    list_item = xbmcgui.ListItem(label=os.path.basename(path))
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=path,
        listitem=list_item,
        isFolder=False,
    )


def split_kodi_path(path):
    path = path.rstrip("/\\")
    if not path:
        return "", ""
    idx = max(path.rfind("/"), path.rfind("\\"))
    if idx < 0:
        return "", path
    return path[:idx], path[idx + 1:]


def jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    try:
        raw = xbmc.executeJSONRPC(json.dumps(payload))
        parsed = json.loads(raw)
    except Exception as exc:
        log("JSON-RPC %s failed: %s" % (method, exc), xbmc.LOGWARNING)
        return {}
    if parsed.get("error"):
        log("JSON-RPC %s error: %s" % (method, parsed.get("error")), xbmc.LOGWARNING)
        return {}
    return parsed.get("result") or {}


def current_subtitle_context():
    names = []
    languages = []

    try:
        current_name = xbmc.Player().getSubtitles()
    except Exception:
        current_name = ""
    if current_name:
        names.append(current_name)

    current_lang = xbmc.getInfoLabel("VideoPlayer.SubtitlesLanguage")
    if current_lang:
        languages.append(current_lang)

    active_players = jsonrpc("Player.GetActivePlayers")
    if isinstance(active_players, dict):
        active_players = active_players.get("result", [])
    if not isinstance(active_players, list):
        active_players = []
    player_id = None
    for player in active_players:
        if player.get("type") == "video":
            player_id = player.get("playerid")
            break

    if player_id is not None:
        props = jsonrpc(
            "Player.GetProperties",
            {"playerid": player_id, "properties": ["currentsubtitle", "subtitleenabled"]},
        )
        current = props.get("currentsubtitle") or {}
        for key in ("name", "label"):
            value = current.get(key)
            if value:
                names.append(value)
        if current.get("language"):
            languages.append(current["language"])

    deduped_names = []
    for value in names:
        if value and value not in deduped_names:
            deduped_names.append(value)

    deduped_languages = []
    for value in languages:
        if value and value not in deduped_languages:
            deduped_languages.append(value)

    return {"names": deduped_names, "languages": deduped_languages}


def file_mtime(path):
    try:
        translated = translatePath(path) if path.startswith("special://") else path
        return os.path.getmtime(translated)
    except Exception:
        try:
            return os.path.getmtime(path)
        except Exception:
            return 0


def sorted_sources(candidates, video_name, subtitle_context):
    ordered = []
    for source in candidates:
        _, name = split_kodi_path(source["path"])
        score = build_source_score(name, video_name, subtitle_context.get("names"))
        source = dict(source)
        source["_score"] = score
        source["_mtime"] = file_mtime(source["path"])
        ordered.append(source)
    ordered.sort(
        key=lambda item: (
            item["_score"][0],
            item["_score"][1],
            item["_score"][2],
            item["_mtime"],
            item["label"].lower(),
        ),
        reverse=True,
    )
    for source in ordered:
        source.pop("_score", None)
        source.pop("_mtime", None)
    return ordered


def local_copy(source_path):
    _, name = split_kodi_path(source_path)
    ext = os.path.splitext(name)[1].lower()
    local_path = os.path.join(__workdir__, "src_%s%s" % (uuid.uuid4().hex, ext))
    if not xbmcvfs.copy(source_path, local_path):
        raise IOError("Failed to copy %s" % source_path)
    return local_path


def extract_first_supported_from_zip(zip_path):
    local_zip = local_copy(zip_path)
    with zipfile.ZipFile(local_zip) as archive:
        for member in archive.namelist():
            ext = os.path.splitext(member)[1].lower()
            if ext not in SUPPORTED_EXTENSIONS:
                continue
            target = os.path.join(__workdir__, "zip_%s%s" % (uuid.uuid4().hex, ext))
            with archive.open(member) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
            return {"path": target, "name": os.path.basename(member)}
    raise IOError("No supported subtitle file found in ZIP")


def custom_subtitle_folder_sources(video_name, subtitle_context):
    subtitle_dir = translatePath("special://subtitles")
    results = []
    if not subtitle_dir or not xbmcvfs.exists(subtitle_dir):
        return results
    try:
        _, files = xbmcvfs.listdir(subtitle_dir)
    except Exception as exc:
        log("Failed to list current subtitle cache: %s" % exc, xbmc.LOGWARNING)
        return results
    for name in sorted(files):
        ext = os.path.splitext(name)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            continue
        path = os.path.join(subtitle_dir, name)
        label = "Custom subtitle folder: %s" % name
        results.append({"path": path, "label": label, "source_label": "Custom"})
    return sorted_sources(results, video_name, subtitle_context)


def sibling_sources(video_name, subtitle_context):
    video_path = xbmc.Player().getPlayingFile() or xbmc.getInfoLabel("Player.Filenameandpath")
    results = []
    if not video_path:
        return results

    directory, _ = split_kodi_path(video_path)
    if not directory:
        return results

    try:
        _, files = xbmcvfs.listdir(directory)
    except Exception as exc:
        log("Failed to list sibling subtitles for %s: %s" % (video_path, exc), xbmc.LOGWARNING)
        return results

    for name in sorted(files):
        ext = os.path.splitext(name)[1].lower()
        if ext not in SUPPORTED_EXTENSIONS:
            continue
        path = directory.rstrip("/\\") + "/" + name
        lang = guess_language_from_name(name) or "auto"
        label = "Nearby subtitle: %s" % name
        results.append({"path": path, "label": label, "source_label": lang.upper()})
    return sorted_sources(results, video_name, subtitle_context)


def temp_sources(video_name, subtitle_context, limit=20):
    temp_dir = translatePath("special://temp")
    results = []
    if not temp_dir or not os.path.isdir(temp_dir):
        return results

    current_names = subtitle_context.get("names") or []
    recent_cutoff = time.time() - (24 * 60 * 60)
    scanned = 0
    for root, _, files in os.walk(temp_dir):
        scanned += 1
        if scanned > 200:
            break
        for name in files:
            ext = os.path.splitext(name)[1].lower()
            if ext not in SUPPORTED_EXTENSIONS:
                continue
            path = os.path.join(root, name)
            mtime = file_mtime(path)
            if mtime and mtime < recent_cutoff:
                continue
            score = build_source_score(name, video_name, current_names)
            if not any(score[:3]) and "subtitle" not in normalize_name(root):
                continue
            lang = guess_language_from_name(name) or "auto"
            results.append(
                {
                    "path": path,
                    "label": "Kodi temp subtitle: %s" % name,
                    "source_label": lang.upper(),
                }
            )
    return sorted_sources(results, video_name, subtitle_context)[:limit]


def known_subtitle_addon_temp_sources(video_name, subtitle_context):
    results = []
    for provider_name, special_path in KNOWN_SUBTITLE_ADDON_TEMP_DIRS:
        base_dir = translatePath(special_path)
        if not base_dir or not os.path.isdir(base_dir):
            continue

        try:
            names = sorted(os.listdir(base_dir))
        except Exception as exc:
            log("Failed to list %s temp subtitles: %s" % (provider_name, exc), xbmc.LOGWARNING)
            continue

        for name in names:
            ext = os.path.splitext(name)[1].lower()
            if ext not in SUPPORTED_EXTENSIONS:
                continue
            path = os.path.join(base_dir, name)
            lang = guess_language_from_name(name) or "auto"
            results.append(
                {
                    "path": path,
                    "label": "%s temp subtitle: %s" % (provider_name, name),
                    "source_label": lang.upper(),
                }
            )
    return sorted_sources(results, video_name, subtitle_context)


def _is_already_translated(path):
    """Skip files that are already Ukrainian or DeepL-generated."""
    _, name = split_kodi_path(path)
    lower = name.lower()
    if ".deepl." in lower:
        return True
    lang = guess_language_from_name(name)
    return lang == "uk"


def unique_sources():
    video_path = xbmc.Player().getPlayingFile() or xbmc.getInfoLabel("Player.Filenameandpath")
    _, video_name = split_kodi_path(video_path)
    subtitle_context = current_subtitle_context()
    sources = []
    seen = set()
    if get_setting_bool("offer_current_cache_first", True):
        sources.extend(custom_subtitle_folder_sources(video_name, subtitle_context))
    sources.extend(known_subtitle_addon_temp_sources(video_name, subtitle_context))
    sources.extend(sibling_sources(video_name, subtitle_context))
    if not sources:
        sources.extend(temp_sources(video_name, subtitle_context))
    deduped = []
    for source in sources:
        path = source["path"]
        if path in seen:
            continue
        seen.add(path)
        if _is_already_translated(path):
            continue
        deduped.append(source)
    return deduped


def build_source_items():
    items = []
    for source in unique_sources():
        label = "%s -> %s" % (
            source["label"],
            __addon__.getLocalizedString(32034),
        )
        items.append(
            {
                "label": label,
                "source_path": source["path"],
                "source_label": source["source_label"],
            }
        )
    return items


def source_cache_path(source_path, source_language, output_name_hint=None):
    _, name = split_kodi_path(output_name_hint or source_path)
    name = name or output_name_hint or source_path
    extension = os.path.splitext(name)[1].lower()
    if extension not in SUPPORTED_EXTENSIONS:
        raise ValueError("Unsupported subtitle format: %s" % extension)
    cache_basis = "%s|%s|%s|dualass" % (source_path, file_mtime(source_path), source_language)
    cache_key = hashlib.sha1(cache_basis.encode("utf-8")).hexdigest()[:12]
    target_name = "%s.%s.uk.deepl.ass" % (safe_stem(name), cache_key)
    return os.path.join(__workdir__, target_name)


def generate_or_load_translated_subtitle(source_path):
    ensure_workdir()
    cleanup_workdir()

    source_language = get_source_language()
    output_path = source_cache_path(source_path, source_language)
    if os.path.exists(output_path):
        return output_path

    translator = get_translator()
    _, source_name = split_kodi_path(source_path)
    local_source = local_copy(source_path)
    info = generate_translated_subtitle(
        local_source,
        __workdir__,
        translator,
        source_language,
        source_name_hint=source_name or source_path,
        output_name_hint=source_name or source_path,
        output_path=output_path,
    )
    return info["path"]


def browse_and_generate():
    mask = ".zip|" + "|".join(SUPPORTED_EXTENSIONS)
    default_path = translatePath("special://subtitles")
    source = __dialog__.browse(
        1,
        __addon__.getLocalizedString(32020),
        "video",
        mask,
        False,
        False,
        default_path,
        False,
    )
    if not source or source == default_path:
        return None

    source_language = get_source_language()
    try:
        translator = get_translator()
        if source.lower().endswith(".zip"):
            prepared = extract_first_supported_from_zip(source)
            prepared_path = prepared["path"]
            prepared_name = prepared["name"]
        else:
            prepared_path = local_copy(source)
            _, prepared_name = split_kodi_path(source)
        return generate_translated_subtitle(
            prepared_path,
            __workdir__,
            translator,
            source_language,
            source_name_hint=prepared_name or source,
            output_name_hint=prepared_name or source,
        )
    except Exception as exc:
        __dialog__.ok(__scriptname__, "%s\n%s" % (__addon__.getLocalizedString(32030), exc))
        return None


def search():
    ensure_workdir()
    cleanup_workdir()
    if not get_setting("deepl_api_key").strip():
        add_action_item(__addon__.getLocalizedString(32033), "settings", "Setup")
        add_action_item(__addon__.getLocalizedString(32022), "settings", "Settings")
        return

    items = build_source_items()
    if items:
        for item in items:
            add_download_item(item["label"], item["source_path"], item["source_label"])
    else:
        add_action_item(__addon__.getLocalizedString(32031), "noop", "Info")

    add_action_item(__addon__.getLocalizedString(32021), "browse", "Browse")
    add_action_item(__addon__.getLocalizedString(32022), "settings", "Settings")


def handle_action():
    action = params().get("action", "search")
    if action in ("search", "manualsearch"):
        search()
    elif action == "browse":
        ensure_workdir()
        info = browse_and_generate()
        if info:
            download(info["path"])
    elif action == "download":
        source_path = unquote(params().get("source", ""))
        if source_path:
            progress = xbmcgui.DialogProgress()
            progress.create(__scriptname__, __addon__.getLocalizedString(32035))
            try:
                download(generate_or_load_translated_subtitle(source_path))
            except DeepLError as exc:
                __dialog__.ok(__scriptname__, str(exc))
            except Exception as exc:
                __dialog__.ok(__scriptname__, "%s\n%s" % (__addon__.getLocalizedString(32030), exc))
            finally:
                progress.close()
    elif action == "settings":
        __addon__.openSettings()
        add_action_item(__addon__.getLocalizedString(32032), "search", "Info")
    elif action == "noop":
        pass
    else:
        log("Unknown action: %s" % action, xbmc.LOGWARNING)


handle_action()
end_directory()
