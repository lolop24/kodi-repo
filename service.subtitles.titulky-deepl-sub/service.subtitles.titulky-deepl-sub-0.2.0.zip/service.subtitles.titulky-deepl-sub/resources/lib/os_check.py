# -*- coding: utf-8 -*-
"""Check OpenSubtitles.com for existing Ukrainian subtitles before translating."""

import json

try:
    from urllib.error import HTTPError, URLError
    from urllib.parse import quote, urlencode
    from urllib.request import Request, urlopen
except ImportError:
    from urllib2 import HTTPError, URLError, Request, urlopen
    from urllib import quote, urlencode

API_URL = "https://api.opensubtitles.com/api/v1/"
API_KEY = "qo2wQs1PXwIHJsXvIiWXu1ZbVjaboPh6"
USER_AGENT = "TitulkyDeepLSub v0.1.0"
TIMEOUT = 8


def _api_get(endpoint, params=None):
    """Make a GET request to OpenSubtitles REST API."""
    url = API_URL + endpoint
    if params:
        filtered = {k: v for k, v in params.items() if v}
        url = "%s?%s" % (url, urlencode(filtered))

    request = Request(url)
    request.add_header("Api-Key", API_KEY)
    request.add_header("User-Agent", USER_AGENT)
    request.add_header("Accept", "application/json")

    try:
        response = urlopen(request, timeout=TIMEOUT)
        return json.loads(response.read().decode("utf-8"))
    except (HTTPError, URLError, ValueError):
        return None


def check_ukrainian_subtitles(imdb_id="", title="", year="", season="", episode=""):
    """Search OpenSubtitles for existing Ukrainian subtitles.

    Returns:
        list of dicts with keys: id, file_id, release, uploader, downloads, rating
        Empty list if none found.
    """
    results = []

    # Strategy 1: Search by IMDB ID (most precise)
    if imdb_id:
        clean_imdb = imdb_id.replace("tt", "")
        data = _api_get("subtitles", {
            "imdb_id": clean_imdb,
            "languages": "uk",
            "type": "movie" if not season else "episode",
            "season_number": season,
            "episode_number": episode,
        })
        if data and data.get("data"):
            results = data["data"]

    # Strategy 2: Search by title + year (fallback)
    if not results and title:
        data = _api_get("subtitles", {
            "query": title,
            "languages": "uk",
            "year": year,
            "season_number": season,
            "episode_number": episode,
        })
        if data and data.get("data"):
            results = data["data"]

    # Parse results into simplified format
    found = []
    for item in results:
        attrs = item.get("attributes", {})
        files = attrs.get("files", [])
        uploader = attrs.get("uploader", {})

        for f in files:
            found.append({
                "subtitle_id": item.get("id", ""),
                "file_id": f.get("file_id", ""),
                "file_name": f.get("file_name", ""),
                "release": attrs.get("release", ""),
                "uploader_name": uploader.get("name", "anonymous"),
                "uploader_id": uploader.get("uploader_id", ""),
                "downloads": attrs.get("download_count", 0),
                "rating": attrs.get("ratings", 0),
                "machine_translated": attrs.get("machine_translated", False),
                "ai_translated": attrs.get("ai_translated", False),
                "language": attrs.get("language", "uk"),
            })

    return found


def check_user_uploads(imdb_id="", uploader_id=""):
    """Check if a specific user already uploaded Ukrainian subtitles for this movie.

    Returns True if found, False otherwise.
    """
    if not imdb_id or not uploader_id:
        return False

    clean_imdb = imdb_id.replace("tt", "")
    data = _api_get("subtitles", {
        "imdb_id": clean_imdb,
        "languages": "uk",
        "uploader_id": str(uploader_id),
    })

    if data and data.get("data"):
        return True
    return False


def format_check_results(found):
    """Format found subtitles for display."""
    if not found:
        return "No Ukrainian subtitles found on OpenSubtitles."

    lines = ["Ukrainian subtitles already on OpenSubtitles:"]
    for i, item in enumerate(found[:5], 1):
        mt = " [MT]" if item.get("machine_translated") else ""
        ai = " [AI]" if item.get("ai_translated") else ""
        lines.append(
            "  %d. %s by %s (%d downloads)%s%s"
            % (
                i,
                item.get("release") or item.get("file_name") or "unknown",
                item.get("uploader_name", "anonymous"),
                item.get("downloads", 0),
                mt,
                ai,
            )
        )
    return "\n".join(lines)
